# OpenRouter Message Flow Diagram

## Complete Transformation Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. TOOL EXECUTION (MxfAgent.ts:730-752)                         │
│                                                                  │
│   Tool executes → Result returned from MCP tool                 │
│                                                                  │
│   toolResultMessage = {                                         │
│     id: "tool-result-12345-abc",                                │
│     role: "tool",                                               │
│     content: "File contents: Hello World",                      │
│     timestamp: 1699123456789,                                   │
│     metadata: {                                                 │
│       tool_call_id: "call_xyz789",  ← CRITICAL                  │
│       toolName: "read_file",                                    │
│       fromAgentId: "agent-1",                                   │
│       isToolResult: true                                        │
│     }                                                            │
│   }                                                              │
│                                                                  │
│   ✅ tool_call_id stored in metadata                            │
│   ✅ Content is plain string                                    │
│   ✅ Role is 'tool'                                             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ 2. STORAGE (MxfMemoryManager.ts:249-286)                       │
│                                                                  │
│   memoryManager.addConversationMessage(toolResultMessage)       │
│                                                                  │
│   → Generates new ID: uuid()                                    │
│   → Generates new timestamp: Date.now()                         │
│   → Preserves metadata (including tool_call_id)                 │
│   → Adds to conversationHistory array                           │
│                                                                  │
│   conversationHistory = [                                       │
│     { role: "system", content: "You are..." },                  │
│     { role: "user", content: "Read the file" },                 │
│     { role: "assistant", content: "",                           │
│       tool_calls: [{ id: "call_xyz789", ... }] },               │
│     { role: "tool", content: "File contents...",                │
│       metadata: { tool_call_id: "call_xyz789" } }  ← STORED     │
│   ]                                                              │
│                                                                  │
│   ✅ All 14 messages stored correctly                           │
│   ✅ metadata.tool_call_id preserved                            │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ 3. CONTEXT FILTERING (OpenRouterMcpClient.ts:652-692)          │
│                                                                  │
│   const dialogueMessages = context.conversationHistory.filter( │
│     msg => {                                                    │
│       // INCLUDE tool messages                                  │
│       if (msg.role === 'tool') return true;  ✅                 │
│                                                                  │
│       // INCLUDE conversation layer                             │
│       if (layer === 'conversation') return true;                │
│                                                                  │
│       // SKIP system/identity/task/action                       │
│       if (layer === 'system') return false;                     │
│                                                                  │
│       return false;                                             │
│     }                                                            │
│   );                                                             │
│                                                                  │
│   📊 INPUT: 20 messages total                                   │
│   📊 OUTPUT: 14 dialogue messages (includes all tool results)   │
│                                                                  │
│   ✅ Tool results NOT filtered out                              │
│   ✅ All 14 messages passed to next stage                       │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ 4. MCP CONVERSION (OpenRouterMcpClient.ts:720-766)             │
│                                                                  │
│   const mcpMessages = dialogueMessages.map(msg =>               │
│     convertConversationToMcp(msg)                               │
│   );                                                             │
│                                                                  │
│   BEFORE (ConversationMessage):                                 │
│   {                                                              │
│     role: "tool",                                               │
│     content: "File contents: Hello World",  ← Plain string      │
│     metadata: { tool_call_id: "call_xyz789" }                   │
│   }                                                              │
│                                                                  │
│   AFTER (McpMessage):                                           │
│   {                                                              │
│     role: McpRole.TOOL,                                         │
│     content: {                                                  │
│       type: McpContentType.TEXT,  ← Wrapped in object           │
│       text: "File contents: Hello World"                        │
│     },                                                           │
│     tool_call_id: "call_xyz789"  ← Promoted to top level! ✅    │
│   }                                                              │
│                                                                  │
│   📊 INPUT: 14 ConversationMessages                             │
│   📊 OUTPUT: 14 McpMessages                                     │
│                                                                  │
│   ✅ tool_call_id extracted from metadata                       │
│   ✅ Content restructured to MCP format                         │
│   ✅ All messages preserved                                     │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ 5. REORDERING (OpenRouterMcpClient.ts:261-311)                 │
│                                                                  │
│   const reordered = reorderMessagesForOpenRouter(mcpMessages);  │
│                                                                  │
│   ⚠️ ⚠️ ⚠️  CRITICAL BUG HERE  ⚠️ ⚠️ ⚠️                         │
│                                                                  │
│   PASS 1: Build toolResultsMap                                  │
│   ┌─────────────────────────────────────────┐                   │
│   │ for (msg of messages) {                 │                   │
│   │   if (msg.role === TOOL) {              │                   │
│   │     toolCallId = msg.tool_call_id;      │                   │
│   │     if (toolCallId) {                   │                   │
│   │       map.set(toolCallId, msg);  ✅     │                   │
│   │     }                                    │                   │
│   │     // ❌ NO ELSE - msg silently lost!  │                   │
│   │   }                                      │                   │
│   │ }                                        │                   │
│   └─────────────────────────────────────────┘                   │
│                                                                  │
│   Result:                                                        │
│   - 10 tool results have tool_call_id → Added to map ✅         │
│   - 4 tool results missing tool_call_id → LOST FOREVER ❌       │
│                                                                  │
│   PASS 2: Build reordered list                                  │
│   ┌─────────────────────────────────────────┐                   │
│   │ for (msg of messages) {                 │                   │
│   │   if (msg.role === TOOL) {              │                   │
│   │     continue;  // Skip ALL tool msgs    │                   │
│   │   }                                      │                   │
│   │   reordered.push(msg);                  │                   │
│   │                                          │                   │
│   │   if (msg.role === ASSISTANT) {         │                   │
│   │     for (toolCall of msg.tool_calls) {  │                   │
│   │       results = map.get(toolCall.id);   │                   │
│   │       if (results) {                    │                   │
│   │         reordered.push(...results);  ✅ │                   │
│   │       }                                  │                   │
│   │     }                                    │                   │
│   │   }                                      │                   │
│   │ }                                        │                   │
│   └─────────────────────────────────────────┘                   │
│                                                                  │
│   Result:                                                        │
│   - System, user, assistant messages added ✅                   │
│   - 10 matched tool results added after tool_calls ✅           │
│   - 4 unmatched tool results NEVER ADDED ❌                     │
│                                                                  │
│   PASS 3: Add orphaned results                                  │
│   ┌─────────────────────────────────────────┐                   │
│   │ for ([id, results] of map.entries()) {  │                   │
│   │   // Only results STILL in map          │                   │
│   │   reordered.push(...results);           │                   │
│   │ }                                        │                   │
│   └─────────────────────────────────────────┘                   │
│                                                                  │
│   Result:                                                        │
│   - 0 results in map (all were matched and deleted)             │
│   - 4 tool results that never made it to map are GONE           │
│                                                                  │
│   📊 INPUT: 14 McpMessages                                      │
│   📊 OUTPUT: 4 McpMessages  ← 10 MESSAGES LOST! 💥              │
│                                                                  │
│   ❌ 10 tool result messages silently dropped                   │
│   ❌ No error, no warning, no trace                             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ 6. OPENROUTER CONVERSION (OpenRouterMcpClient.ts:319-415)      │
│                                                                  │
│   const openRouterMessages =                                    │
│     convertToOpenRouterMessages(reorderedMessages);             │
│                                                                  │
│   📊 INPUT: 4 McpMessages (already lost 10)                     │
│                                                                  │
│   McpMessage → OpenRouterMessage:                               │
│   {                                                              │
│     role: McpRole.TOOL,                                         │
│     content: { type: TEXT, text: "..." },                       │
│     tool_call_id: "call_xyz789"                                 │
│   }                                                              │
│   →                                                              │
│   {                                                              │
│     role: "tool",                                               │
│     content: "...",  ← Extracted from content.text              │
│     tool_call_id: "call_xyz789"                                 │
│   }                                                              │
│                                                                  │
│   📊 OUTPUT: 4 OpenRouterMessages                               │
│                                                                  │
│   ⚠️ This conversion works fine, but it's too late              │
│   ⚠️ Messages already lost in reordering step                   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ 7. FINAL PAYLOAD (OpenRouterMcpClient.ts:876-1059)             │
│                                                                  │
│   requestBody = {                                               │
│     model: "openai/gpt-4-turbo",                                │
│     messages: [  ← Only 4 messages                              │
│       { role: "system", content: "..." },                       │
│       { role: "user", content: "..." },                         │
│       { role: "assistant", content: "",                         │
│         tool_calls: [...] },                                    │
│       // ❌ Tool results missing!                               │
│     ],                                                           │
│     tools: [...],                                               │
│     temperature: 0.7,                                           │
│     max_tokens: 4096                                            │
│   };                                                             │
│                                                                  │
│   console.log(JSON.stringify(requestBody));                     │
│   // Shows: "4 messages" instead of expected "14 messages"      │
│                                                                  │
│   fetch(openRouterUrl, {                                        │
│     body: JSON.stringify(requestBody)                           │
│   });                                                            │
│                                                                  │
│   📊 SENT TO API: 4 messages (missing 10 tool results)          │
│                                                                  │
│   ❌ OpenRouter receives incomplete conversation                │
│   ❌ Tool results lost, breaking context continuity             │
└─────────────────────────────────────────────────────────────────┘
```

## The Bug in Detail

### What Should Happen

```
14 messages → Filter → 14 messages → Convert → 14 MCP → Reorder → 14 MCP → Convert → 14 OpenRouter
```

### What Actually Happens

```
14 messages → Filter → 14 messages → Convert → 14 MCP → Reorder → 4 MCP → Convert → 4 OpenRouter
                                                            ↑
                                                    BUG: 10 messages lost here
```

## Why Messages Are Lost

The reordering logic has three passes:

1. **Pass 1**: Collect tool results by tool_call_id
   - If `tool_call_id` is undefined → Message NOT added to map
   - Message is effectively abandoned

2. **Pass 2**: Build reordered list
   - ALL tool messages skipped (`continue`)
   - Only messages from map are re-added
   - Messages not in map (from Pass 1) are gone forever

3. **Pass 3**: Add remaining from map
   - Only helps if message WAS in map
   - Can't recover messages that never made it to map

## The Fix

### Current Code (BUGGY)
```typescript
// Pass 1
for (const message of messages) {
    if (message.role === McpRole.TOOL) {
        const toolCallId = extractToolCallId(message);
        if (toolCallId) {
            toolResultsMap.set(toolCallId, message);
        }
        // ❌ NO ELSE - message lost if no tool_call_id
    }
}
```

### Fixed Code (PRESERVES ALL)
```typescript
// Pass 1
const orphanedToolResults: McpMessage[] = [];

for (const message of messages) {
    if (message.role === McpRole.TOOL) {
        const toolCallId = extractToolCallId(message);
        if (toolCallId) {
            toolResultsMap.set(toolCallId, message);
        } else {
            // ✅ NEW: Preserve orphaned results
            orphanedToolResults.push(message);
        }
    }
}

// Pass 3 (append orphaned at end)
if (orphanedToolResults.length > 0) {
    reorderedMessages.push(...orphanedToolResults);
}
```

## Message Count Tracking

| Stage | Count | Notes |
|-------|-------|-------|
| Tool execution | 1 | Tool result created |
| Conversation history | 14 | Stored with other messages |
| Context filtering | 14 | All tool messages included |
| MCP conversion | 14 | All converted successfully |
| **Reordering** | **4** | **10 LOST HERE** ⚠️ |
| OpenRouter conversion | 4 | Converts remaining messages |
| API request | 4 | Only 4 messages sent |

## Metadata Journey

```
Creation:
metadata: { tool_call_id: "call_xyz789" }
                    ↓
Storage:
metadata: { tool_call_id: "call_xyz789" }  ← Preserved
                    ↓
MCP Conversion:
tool_call_id: "call_xyz789"  ← Promoted to top level
                    ↓
Reordering:
extractToolCallId(message) → "call_xyz789"  ← Retrieved
                    ↓
OpenRouter Conversion:
tool_call_id: "call_xyz789"  ← Preserved
```

## Why tool_call_id Might Be Undefined

Even though metadata is preserved, `tool_call_id` could be undefined if:

1. **Creation bug**: Tool result created without `tool_use_id`
2. **Synthetic results**: Error results may not have proper IDs (lines 769-785)
3. **Legacy format**: Old tool results from before metadata structure
4. **Race condition**: Async timing issues during message creation
5. **Conversion bug**: Metadata access fails (`msg.metadata?.tool_call_id`)

The reordering logic MUST handle these cases gracefully by preserving messages, not dropping them.
