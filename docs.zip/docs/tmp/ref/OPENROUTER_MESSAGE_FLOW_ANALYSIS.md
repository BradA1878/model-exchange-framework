# OpenRouter Message Flow Architecture Analysis

**Date**: 2025-11-14
**Analysis Scope**: Complete message transformation pipeline from tool execution to OpenRouter API
**Critical Issue**: 14 messages structured → 4 messages sent (10 messages lost)

---

## EXECUTIVE SUMMARY

### The Problem
- **Symptom**: Logs show "14 messages structured" but only "4 messages sent" to OpenRouter
- **Root Cause**: `reorderMessagesForOpenRouter()` is DROPPING tool result messages when they don't match a tool_call_id
- **Impact**: Tool results are being silently discarded, breaking conversation continuity and OpenRouter's tool call/result pairing requirements

### The Solution
The reordering logic has a **fundamental architectural flaw**: it assumes all tool results MUST match a tool_call from an assistant message. However, the conversion chain from `ConversationMessage` → `McpMessage` → `OpenRouterMessage` loses critical metadata that makes this matching impossible.

---

## COMPLETE MESSAGE FLOW TRACE

### 1. TOOL RESULT CREATION (MxfAgent.ts:730-752)

**Location**: `/Users/bradanderson/Development/model-exchange-framework/src/sdk/MxfAgent.ts` Lines 730-752

**What Happens**:
```typescript
const toolResultMessage: ConversationMessage = {
    id: `tool-result-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    role: 'tool',                          // ✅ Proper role
    content: content,                      // ✅ Tool result text
    timestamp: Date.now(),
    metadata: {
        tool_call_id: toolResult.tool_use_id,  // ✅ CRITICAL: tool_call_id stored in metadata
        toolName: toolName,
        fromAgentId: this.agentId,
        isToolResult: true
    }
};

this.memoryManager.addConversationMessage(toolResultMessage);
```

**Key Points**:
- Tool results created with `role: 'tool'`
- `tool_call_id` stored in `metadata.tool_call_id` (NOT at top level)
- Content is plain text string
- Immediately added to conversation history via MemoryManager

### 2. STORAGE IN CONVERSATION HISTORY (MxfMemoryManager.ts:249-286)

**Location**: `/Users/bradanderson/Development/model-exchange-framework/src/sdk/managers/MxfMemoryManager.ts` Lines 249-286

**What Happens**:
```typescript
public addConversationMessage(message: {
    role: string;
    content: string;
    metadata?: Record<string, any>;
    tool_calls?: any[]
}): void {
    const conversationMessage: ConversationMessage = {
        id: uuidv4(),                          // ⚠️ NEW ID generated (original ID lost)
        role: message.role as 'user' | 'assistant' | 'system',
        content: message.content,
        timestamp: Date.now(),                 // ⚠️ NEW timestamp (original lost)
        metadata: message.metadata,            // ✅ Metadata preserved (includes tool_call_id)
        tool_calls: message.tool_calls         // ✅ Preserved for assistant messages
    };

    this.conversationHistory.push(conversationMessage);
    this.trimConversationHistory();

    // Index to Meilisearch (async)
    if (this.meilisearchService) {
        this.indexConversationToMeilisearch(conversationMessage);
    }

    // Save to MongoDB (async)
    this.saveAgentMemory();
}
```

**Key Points**:
- Message stored in `conversationHistory` array
- Metadata preserved (including `tool_call_id`)
- New ID and timestamp generated
- Tool results stored alongside regular messages

### 3. CONTEXT STRUCTURING (OpenRouterMcpClient.ts:625-715)

**Location**: `/Users/bradanderson/Development/model-exchange-framework/src/shared/protocols/mcp/providers/OpenRouterMcpClient.ts` Lines 625-715

**What Happens**:
```typescript
private structureMessagesFromContext(context: AgentContext): any[] {
    const messages: any[] = [];

    // 1. System message (combined framework rules + agent identity)
    messages.push({
        role: 'system',
        content: systemContent
    });

    // 2. Task message (if present)
    if (context.currentTask) {
        messages.push({
            role: 'user',
            content: `## Current Task\n${context.currentTask.description}`
        });
    }

    // 3. Conversation history - CRITICAL FILTERING
    const dialogueMessages = context.conversationHistory.filter(msg => {
        const layer = msg.metadata?.contextLayer;

        // INCLUDE: Messages with conversation or tool-result layer
        if (layer === 'conversation' || layer === 'tool-result') {
            return true;
        }

        // INCLUDE: Tool role messages (always part of tool execution flow)
        if (msg.role === 'tool') {
            return true;  // ✅ Tool results ARE included in filter
        }

        // SKIP: system/identity/task/action layers
        if (layer === 'system' || layer === 'identity' || layer === 'task' || layer === 'action') {
            return false;
        }

        // INCLUDE: Messages without contextLayer (legacy or direct additions)
        if (!layer && msg.role !== 'system') {
            return true;
        }

        return false;
    });

    this.logger.info(`🔍 OPENROUTER CONTEXT: Filtered ${dialogueMessages.length} dialogue messages from ${context.conversationHistory.length} total`);

    // DEBUG: Count tool messages
    const toolMessagesInDialogue = dialogueMessages.filter(m => m.role === 'tool');
    this.logger.info(`🔧 TOOL MESSAGES IN DIALOGUE: ${toolMessagesInDialogue.length} tool result messages`);

    // Convert to MCP format and apply OpenRouter's reordering
    const mcpMessages = dialogueMessages.map(msg => this.convertConversationToMcp(msg));
    const reorderedMessages = this.reorderMessagesForOpenRouter(mcpMessages);  // ⚠️ CRITICAL POINT

    // Convert to OpenRouter format
    const openRouterDialogue = this.convertToOpenRouterMessages(reorderedMessages);
    messages.push(...openRouterDialogue);

    // 4. Recent actions
    if (context.recentActions.length > 0) {
        messages.push({
            role: 'user',
            content: actionsContent
        });
    }

    return messages;
}
```

**Key Points**:
- Filtering DOES include tool messages (`msg.role === 'tool'`)
- Logs show "14 dialogue messages" including tool results
- Messages converted to MCP format before reordering
- **CRITICAL**: Reordering happens BEFORE final conversion

### 4. CONVERSION TO MCP FORMAT (OpenRouterMcpClient.ts:720-766)

**Location**: `/Users/bradanderson/Development/model-exchange-framework/src/shared/protocols/mcp/providers/OpenRouterMcpClient.ts` Lines 720-766

**What Happens**:
```typescript
private convertConversationToMcp(msg: ConversationMessage): McpMessage {
    let role: McpRole;
    switch (msg.role) {
        case 'system': role = McpRole.SYSTEM; break;
        case 'assistant': role = McpRole.ASSISTANT; break;
        case 'tool': role = McpRole.TOOL; break;        // ✅ Tool role preserved
        default: role = McpRole.USER; break;
    }

    // Agent attribution handling...
    let content = msg.content;
    if (role === McpRole.USER && msg.metadata?.fromAgentId) {
        content = `[${msg.metadata.fromAgentId}]: ${content}`;
    }

    const mcpMessage: any = {
        role,
        content: {
            type: McpContentType.TEXT,           // ⚠️ Content becomes TEXT type object
            text: content                        // ⚠️ Content string moved to .text property
        }
    };

    // Preserve tool_calls for assistant messages
    if (msg.role === 'assistant' && msg.tool_calls) {
        mcpMessage.tool_calls = msg.tool_calls;  // ✅ tool_calls preserved
    }

    // Preserve tool_call_id for tool messages
    if (msg.role === 'tool' && msg.metadata?.tool_call_id) {
        mcpMessage.tool_call_id = msg.metadata.tool_call_id;  // ✅ tool_call_id extracted from metadata
    }

    return mcpMessage;
}
```

**Key Points**:
- `role: 'tool'` → `role: McpRole.TOOL` ✅
- `content: string` → `content: { type: TEXT, text: string }` ⚠️ Structure change
- `metadata.tool_call_id` → `tool_call_id` ✅ Promoted to top level
- Assistant `tool_calls` preserved ✅

**Output Format**:
```typescript
{
    role: McpRole.TOOL,
    content: {
        type: McpContentType.TEXT,
        text: "Tool result text here"
    },
    tool_call_id: "call_abc123"  // ✅ At top level now
}
```

### 5. REORDERING LOGIC (OpenRouterMcpClient.ts:261-311)

**Location**: `/Users/bradanderson/Development/model-exchange-framework/src/shared/protocols/mcp/providers/OpenRouterMcpClient.ts` Lines 261-311

**THE CRITICAL FAILURE POINT**:

```typescript
private reorderMessagesForOpenRouter(messages: McpMessage[]): McpMessage[] {
    const reorderedMessages: McpMessage[] = [];
    const toolResultsMap = new Map<string, McpMessage[]>();

    // PASS 1: Collect tool results by their tool_call_id
    for (const message of messages) {
        if (message.role === McpRole.TOOL) {
            const toolCallId = extractToolCallId(message);  // ✅ Gets tool_call_id from message
            if (toolCallId) {
                if (!toolResultsMap.has(toolCallId)) {
                    toolResultsMap.set(toolCallId, []);
                }
                toolResultsMap.get(toolCallId)!.push(message);
            }
            // ⚠️ PROBLEM: If toolCallId is undefined, message is silently skipped
            // Tool result with no tool_call_id is NOT added to toolResultsMap
            // Tool result IS NOT added to reorderedMessages
            // = TOOL RESULT IS LOST FOREVER
        }
    }

    // PASS 2: Build reordered message list
    for (const message of messages) {
        // Skip tool results in this pass (we'll add them after their tool calls)
        if (message.role === McpRole.TOOL) {
            continue;  // ⚠️ ALL tool results skipped here
        }

        // Add the message
        reorderedMessages.push(message);

        // If this is an assistant message with tool calls, add the corresponding tool results immediately after
        if (message.role === McpRole.ASSISTANT) {
            const toolCalls = extractToolCalls(message);
            if (toolCalls) {
                for (const toolCall of toolCalls) {
                    const toolCallId = toolCall.id;
                    const toolResults = toolResultsMap.get(toolCallId);
                    if (toolResults) {
                        reorderedMessages.push(...toolResults);
                        toolResultsMap.delete(toolCallId);  // Remove so we don't add it twice
                    }
                    // ⚠️ If no matching tool result found, nothing is added
                    // This is expected behavior for tool calls without results yet
                }
            }
        }
    }

    // PASS 3: Add any remaining tool results that didn't match a tool call
    for (const [toolCallId, toolResults] of toolResultsMap.entries()) {
        this.logger.warn(`⚠️ Tool result(s) for ${toolCallId} had no matching tool call`);
        reorderedMessages.push(...toolResults);
    }

    return reorderedMessages;
}
```

**THE BUG - Why Messages Are Lost**:

1. **Pass 1** collects tool results into `toolResultsMap` using `tool_call_id` as key
   - If `extractToolCallId(message)` returns `undefined`, the tool result is NOT added to the map
   - These orphaned tool results are LOST

2. **Pass 2** skips ALL tool messages (`if (message.role === McpRole.TOOL) continue;`)
   - Relies entirely on `toolResultsMap` from Pass 1
   - If a tool result wasn't added to map (no tool_call_id), it's permanently lost

3. **Pass 3** only adds tool results that ARE in `toolResultsMap`
   - Orphaned tool results (not in map) are never recovered

**Why tool_call_id Might Be Undefined**:

Looking at `convertConversationToMcp()` (lines 760-763):
```typescript
if (msg.role === 'tool' && msg.metadata?.tool_call_id) {
    mcpMessage.tool_call_id = msg.metadata.tool_call_id;
}
```

This only adds `tool_call_id` if:
- `msg.role === 'tool'` ✅ (always true for tool results)
- `msg.metadata` exists ✅ (should always exist)
- `msg.metadata.tool_call_id` exists ⚠️ **MIGHT BE UNDEFINED**

**Potential Reasons for Missing tool_call_id**:
1. Tool result created without metadata.tool_call_id
2. Metadata lost during message transformations
3. Legacy tool results from old format
4. Synthetic error results (lines 769-785 in MxfAgent.ts)

### 6. CONVERSION TO OPENROUTER FORMAT (OpenRouterMcpClient.ts:319-415)

**Location**: `/Users/bradanderson/Development/model-exchange-framework/src/shared/protocols/mcp/providers/OpenRouterMcpClient.ts` Lines 319-415

**What Happens**:
```typescript
private convertToOpenRouterMessages(messages: McpMessage[]): OpenRouterMessage[] {
    // CRITICAL: Reorder messages for OpenRouter's strict requirements
    const reorderedMessages = this.reorderMessagesForOpenRouter(messages);  // ⚠️ Already lost messages here

    const convertedMessages = reorderedMessages.map(message => {
        let content: any = '';

        if (Array.isArray(message.content)) {
            // Handle array of content items
            content = message.content.map(item => {
                switch (item.type) {
                    case McpContentType.TEXT:
                        return { type: 'text', text: item.text };
                    case McpContentType.TOOL_RESULT:
                        const resultText = extractToolResultText(item);
                        return {
                            type: 'tool_result',
                            tool_call_id: item.tool_use_id,
                            text: resultText
                        };
                    // ... other types
                }
            });
        } else {
            // Handle single content item
            const singleContent = message.content as McpContent;

            switch (singleContent.type) {
                case McpContentType.TEXT:
                    content = singleContent.text;  // ✅ Extract text from TEXT content
                    break;
                case McpContentType.TOOL_RESULT:
                    const resultText = extractToolResultText(singleContent);
                    content = resultText;
                    return {
                        role: this.mapRoleToOpenRouter(message.role),
                        content: resultText,
                        tool_call_id: singleContent.tool_use_id
                    };
                default:
                    content = JSON.stringify(singleContent);
                    break;
            }
        }

        const role = this.mapRoleToOpenRouter(message.role);
        const openRouterMsg: any = { role, content };

        // Include tool_calls for assistant messages
        if (message.role === McpRole.ASSISTANT) {
            const toolCalls = extractToolCalls(message);
            if (toolCalls) {
                openRouterMsg.tool_calls = toolCalls;
            }
        }

        // Include tool_call_id for tool result messages
        if (message.role === McpRole.TOOL) {
            const toolCallId = extractToolCallId(message);  // ✅ Extracts from message.tool_call_id
            if (toolCallId) {
                openRouterMsg.tool_call_id = toolCallId;
            }
        }

        return openRouterMsg;
    });

    return convertedMessages;
}
```

**Key Points**:
- Called AFTER reordering (messages already lost)
- Expects `message.content` to be either:
  - Single `McpContent` object with `type` property
  - Array of `McpContent` objects
- For tool results with `role: 'tool'`:
  - Content should be `{ type: TEXT, text: "..." }`
  - Extracts text via `singleContent.text`
  - Adds `tool_call_id` from `message.tool_call_id`

### 7. FINAL API REQUEST (OpenRouterMcpClient.ts:876-1059)

**Location**: `/Users/bradanderson/Development/model-exchange-framework/src/shared/protocols/mcp/providers/OpenRouterMcpClient.ts` Lines 876-1059

**What Happens**:
```typescript
private async executeOpenRouterRequestCore(
    openRouterMessages: any[],
    openRouterTools?: any[],
    options?: Record<string, any>
): Promise<McpApiResponse> {
    const requestBody: Record<string, any> = {
        model,
        messages: openRouterMessages,  // ⚠️ Already missing tool results at this point
        temperature,
        max_tokens: maxTokens,
        verbosity: "low"
    };

    if (openRouterTools && openRouterTools.length > 0) {
        requestBody.tools = openRouterTools;
        requestBody.tool_choice = 'auto';
    }

    this.logger.debug(`🚀 STARTING OpenRouter request: ${requestBody.model}, ${requestBody.messages.length} messages, ${requestBody.tools?.length || 0} tools`);

    console.log(JSON.stringify(requestBody));  // ⚠️ This is where you see "4 messages" instead of 14

    const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers,
        body: JSON.stringify(requestBody)
    });

    // ... response handling
}
```

**Key Points**:
- Receives already-filtered messages from conversion chain
- Logs message count: `${requestBody.messages.length} messages`
- This is where you see "4 messages" instead of expected 14

---

## ROOT CAUSE ANALYSIS

### The Complete Bug Chain

1. **Tool results created correctly** in MxfAgent.ts with `metadata.tool_call_id`
2. **Stored correctly** in conversation history via MemoryManager
3. **Filtered correctly** in `structureMessagesFromContext()` - all 14 messages included
4. **Converted correctly** to MCP format with `tool_call_id` promoted to top level
5. **LOST in reordering** - `reorderMessagesForOpenRouter()` drops tool results without matching tool calls
6. **Missing from final payload** - only 4 messages (system, task, user, assistant) remain

### Why Reordering Fails

The reordering logic assumes:
- Every tool result has a `tool_call_id`
- Every `tool_call_id` matches an assistant message's `tool_calls` array
- Tool results should ONLY appear immediately after their tool calls

**What Actually Happens**:
- Some tool results may have `undefined` tool_call_id after conversion
- Some tool_call_ids don't match because of ID mismatches or timing issues
- Tool results without matching tool calls are silently dropped

### The Architectural Flaw

The reordering logic is trying to enforce OpenRouter's strict requirement that:
```
Assistant message with tool_calls
↓ (immediately followed by)
Tool result message(s) with matching tool_call_id
```

**BUT**: The current implementation:
1. Silently drops non-matching tool results instead of preserving them
2. Doesn't validate that tool_call_ids actually exist before reordering
3. Doesn't handle edge cases (synthetic results, legacy formats, missing metadata)

---

## ASSESSMENT OF REORDERING LOGIC

### Purpose (from comments lines 251-260)

```
OpenRouter strictly requires:
1. Assistant message with tool_calls
2. Tool result messages immediately after
3. No intermediate messages between tool_calls and results

This reordering ensures OpenRouter compliance and prevents errors like:
"tool_use ids were found without tool_result blocks immediately after"
```

### Is It Still Necessary?

**YES**, but with critical fixes:

OpenRouter (and other providers like Claude) DO require tool results to follow tool calls. However, the current implementation is too aggressive:

**Current Behavior**: Drop non-matching tool results (WRONG)
**Correct Behavior**: Preserve all messages, reorder matches, append non-matches at end

### What Breaks If We Remove It?

Without reordering:
```
User: "Read the file"
Assistant: [tool_calls: read_file]
User: "Also check the other file"  ← Intermediate message breaks OpenRouter
Assistant: [tool_calls: read_other_file]
Tool: [result for read_file]
Tool: [result for read_other_file]
```

OpenRouter rejects this with: `"tool_use ids were found without tool_result blocks immediately after"`

With reordering:
```
User: "Read the file"
Assistant: [tool_calls: read_file]
Tool: [result for read_file]  ← Immediately after
User: "Also check the other file"
Assistant: [tool_calls: read_other_file]
Tool: [result for read_other_file]  ← Immediately after
```

**Conclusion**: Reordering IS necessary, but MUST NOT drop messages.

---

## RECOMMENDED SOLUTION

### Option 1: Fix Reordering Logic (RECOMMENDED)

Modify `reorderMessagesForOpenRouter()` to preserve ALL messages:

```typescript
private reorderMessagesForOpenRouter(messages: McpMessage[]): McpMessage[] {
    const reorderedMessages: McpMessage[] = [];
    const toolResultsMap = new Map<string, McpMessage[]>();
    const orphanedToolResults: McpMessage[] = [];  // NEW: Track unmatched results

    // PASS 1: Collect tool results
    for (const message of messages) {
        if (message.role === McpRole.TOOL) {
            const toolCallId = extractToolCallId(message);
            if (toolCallId) {
                // Has tool_call_id - add to map
                if (!toolResultsMap.has(toolCallId)) {
                    toolResultsMap.set(toolCallId, []);
                }
                toolResultsMap.get(toolCallId)!.push(message);
            } else {
                // NO tool_call_id - preserve as orphaned
                this.logger.warn(`⚠️ Tool result without tool_call_id - preserving as orphaned`);
                orphanedToolResults.push(message);
            }
        }
    }

    // PASS 2: Build reordered list
    for (const message of messages) {
        if (message.role === McpRole.TOOL) {
            continue;  // Skip, we'll add these via map or orphaned list
        }

        reorderedMessages.push(message);

        // Add matching tool results after assistant messages
        if (message.role === McpRole.ASSISTANT) {
            const toolCalls = extractToolCalls(message);
            if (toolCalls) {
                for (const toolCall of toolCalls) {
                    const toolCallId = toolCall.id;
                    const toolResults = toolResultsMap.get(toolCallId);
                    if (toolResults) {
                        reorderedMessages.push(...toolResults);
                        toolResultsMap.delete(toolCallId);
                    }
                }
            }
        }
    }

    // PASS 3: Add remaining tool results (both unmatched and orphaned)
    for (const [toolCallId, toolResults] of toolResultsMap.entries()) {
        this.logger.warn(`⚠️ Tool result(s) for ${toolCallId} had no matching tool call - appending to end`);
        reorderedMessages.push(...toolResults);
    }

    // NEW: Add orphaned tool results (no tool_call_id)
    if (orphanedToolResults.length > 0) {
        this.logger.warn(`⚠️ ${orphanedToolResults.length} tool results without tool_call_id - appending to end`);
        reorderedMessages.push(...orphanedToolResults);
    }

    return reorderedMessages;
}
```

**Benefits**:
- Preserves ALL messages (14 messages in → 14 messages out)
- Still reorders matched tool results to follow tool calls
- Orphaned tool results appended at end (better than dropped)
- Detailed logging for debugging

### Option 2: Simplify Reordering (ALTERNATIVE)

If matching is unreliable, use simpler approach:

```typescript
private reorderMessagesForOpenRouter(messages: McpMessage[]): McpMessage[] {
    // Don't drop anything - just ensure tool results don't interrupt tool calls
    const result: McpMessage[] = [];
    const pendingToolResults: McpMessage[] = [];

    for (const message of messages) {
        if (message.role === McpRole.TOOL) {
            // Buffer tool results
            pendingToolResults.push(message);
        } else {
            // Flush buffered tool results before non-tool message
            if (pendingToolResults.length > 0) {
                result.push(...pendingToolResults);
                pendingToolResults.length = 0;
            }
            result.push(message);
        }
    }

    // Flush any remaining tool results
    if (pendingToolResults.length > 0) {
        result.push(...pendingToolResults);
    }

    return result;
}
```

**Benefits**:
- Simpler logic, less failure modes
- Preserves ALL messages
- Groups tool results together
- No dependency on tool_call_id matching

**Drawbacks**:
- Doesn't enforce strict tool_call → tool_result adjacency
- May not satisfy OpenRouter's strictest requirements

### Option 3: Remove Reordering (NOT RECOMMENDED)

Only viable if:
- Conversation history already maintains correct order
- No intermediate messages ever inserted between tool calls and results
- All providers accept any message ordering

**Assessment**: Too risky, OpenRouter explicitly requires adjacent tool results.

---

## IMMEDIATE ACTION ITEMS

1. **Add Detailed Logging**:
   ```typescript
   // In convertConversationToMcp:
   if (msg.role === 'tool') {
       this.logger.debug(`Converting tool result: tool_call_id=${msg.metadata?.tool_call_id}, content length=${msg.content?.length}`);
   }

   // In reorderMessagesForOpenRouter:
   this.logger.info(`REORDER INPUT: ${messages.length} messages (${messages.filter(m => m.role === McpRole.TOOL).length} tool results)`);
   this.logger.info(`REORDER OUTPUT: ${reorderedMessages.length} messages (${reorderedMessages.filter(m => m.role === McpRole.TOOL).length} tool results)`);
   ```

2. **Implement Option 1** (preserve orphaned tool results)

3. **Add Validation**:
   ```typescript
   // After reordering:
   const inputToolCount = messages.filter(m => m.role === McpRole.TOOL).length;
   const outputToolCount = reorderedMessages.filter(m => m.role === McpRole.TOOL).length;
   if (inputToolCount !== outputToolCount) {
       this.logger.error(`⚠️ CRITICAL: Reordering lost ${inputToolCount - outputToolCount} tool results!`);
   }
   ```

4. **Test Scenarios**:
   - Tool result with valid tool_call_id
   - Tool result with undefined tool_call_id
   - Tool result with non-matching tool_call_id
   - Multiple tool results for same tool_call
   - Assistant message with no tool results yet

---

## METADATA PRESERVATION CHAIN

### Complete Trace of tool_call_id

1. **Creation** (MxfAgent.ts:736):
   ```typescript
   metadata: { tool_call_id: toolResult.tool_use_id }
   ```

2. **Storage** (MxfMemoryManager.ts:265):
   ```typescript
   metadata: message.metadata  // Preserved
   ```

3. **Filtering** (OpenRouterMcpClient.ts:652):
   ```typescript
   // Tool messages included in filter
   if (msg.role === 'tool') return true;
   ```

4. **MCP Conversion** (OpenRouterMcpClient.ts:761):
   ```typescript
   if (msg.role === 'tool' && msg.metadata?.tool_call_id) {
       mcpMessage.tool_call_id = msg.metadata.tool_call_id;
   }
   ```

5. **Reordering** (OpenRouterMcpClient.ts:268):
   ```typescript
   const toolCallId = extractToolCallId(message);  // Returns message.tool_call_id
   ```

6. **OpenRouter Conversion** (OpenRouterMcpClient.ts:405):
   ```typescript
   if (message.role === McpRole.TOOL) {
       const toolCallId = extractToolCallId(message);
       if (toolCallId) {
           openRouterMsg.tool_call_id = toolCallId;
       }
   }
   ```

**Conclusion**: Metadata preservation works correctly through all transformations. The loss happens purely in reordering logic.

---

## ADDITIONAL FINDINGS

### Why Logs Show "14 messages structured" but "4 messages sent"

**"14 messages structured"** (line 594):
```typescript
this.logger.info(`✅ OPENROUTER: Structured ${openRouterMessages.length} messages from context`);
```
This logs BEFORE reordering/conversion, showing the filtered conversation history count.

**"4 messages sent"** (line 962):
```typescript
this.logger.debug(`🚀 STARTING OpenRouter request: ${requestBody.model}, ${requestBody.messages.length} messages, ${requestBody.tools?.length || 0} tools`);
```
This logs AFTER all transformations, showing final payload to API.

**The 10 lost messages**:
- Lost during `reorderMessagesForOpenRouter()` call
- Tool results without matching tool_call_ids dropped silently
- No error logged, no warning, just vanished

### Tool Result Content Structure

Tool results use `TEXT` content type after conversion:
```typescript
// After convertConversationToMcp:
{
    role: McpRole.TOOL,
    content: {
        type: McpContentType.TEXT,
        text: "Tool result content..."
    },
    tool_call_id: "call_abc123"
}
```

This is CORRECT - tool results are simple text, not `TOOL_RESULT` content type.

The `TOOL_RESULT` content type is for tool results INSIDE message content arrays, not for tool role messages.

---

## CONCLUSION

The message loss is entirely due to `reorderMessagesForOpenRouter()` silently dropping tool results that don't match assistant message tool_calls. This is a critical bug that breaks conversation continuity and violates OpenRouter's requirements (which expect ALL tool results to be present).

The fix is straightforward: preserve ALL messages during reordering, including orphaned tool results. The reordering logic itself is necessary (OpenRouter requires adjacency), but it must be defensive and preserve unmatched messages rather than dropping them.

**Recommended Implementation**: Option 1 (add orphaned tool results tracking)
**Priority**: CRITICAL - breaks tool execution feedback loop
**Complexity**: Low - ~15 lines of code
**Risk**: Low - makes system more robust, doesn't change happy path

---

## FILE REFERENCES

- **MxfAgent.ts**: `/Users/bradanderson/Development/model-exchange-framework/src/sdk/MxfAgent.ts`
- **MxfMemoryManager.ts**: `/Users/bradanderson/Development/model-exchange-framework/src/sdk/managers/MxfMemoryManager.ts`
- **OpenRouterMcpClient.ts**: `/Users/bradanderson/Development/model-exchange-framework/src/shared/protocols/mcp/providers/OpenRouterMcpClient.ts`
- **MessageConverters.ts**: `/Users/bradanderson/Development/model-exchange-framework/src/shared/protocols/mcp/utils/MessageConverters.ts`
