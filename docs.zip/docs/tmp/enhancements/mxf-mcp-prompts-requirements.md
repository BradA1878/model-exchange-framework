# MXF MCP Prompts Integration

## Requirements Specification v1.0

**Status:** Draft  
**Author:** Brad Anderson  
**Date:** December 2025  
**MXF Version Target:** 2.x  

---

## Executive Summary

This document specifies the integration of Model Context Protocol (MCP) Prompts into the MXF multi-agent orchestration framework. MCP Prompts provide server-defined prompt templates that clients can discover and invoke with arguments. Within MXF, this capability enables dynamic agent persona configuration, reusable task decomposition patterns, and standardized inter-agent communication contracts—all orchestrated autonomously without human intervention.

The integration positions MCP Prompts as a **contract layer** between MXF's orchestration logic and its MCP tool servers, while MXP 2.0 continues to handle high-frequency agent coordination and token optimization underneath.

---

## 1. Problem Statement

### Current State
- Agent personas and system prompts are statically defined at deployment time
- Task decomposition patterns are embedded in orchestrator logic
- No standardized mechanism for agents to advertise behavioral capabilities
- MCP servers expose tools but lack structured prompt templates for complex interactions

### Desired State
- Dynamic, hot-swappable agent configurations without redeployment
- Reusable reasoning patterns exposed as discoverable prompt templates
- Agents can query and compose prompts from multiple MCP servers
- Clear separation between prompt contracts (MCP) and transport optimization (MXP)

---

## 2. Architecture Overview

### 2.1 Layer Model

```
┌─────────────────────────────────────────────────────────────────┐
│                    EXTERNAL SYSTEMS / API                       │
│   Inbound Tasks │ Webhooks │ Scheduled Jobs │ Event Streams     │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    MXF ORCHESTRATION LAYER                      │
│   ORAPR Control Loops │ SystemLLM │ Task Routing                │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │              MCP PROMPTS MANAGER                        │   │
│   │   • Prompt Discovery & Caching                          │   │
│   │   • Argument Resolution                                 │   │
│   │   • Template Composition                                │   │
│   └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    MXP 2.0 PROTOCOL LAYER                       │
│   Token Optimization │ Binary Encoding │ Message Aggregation    │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                     MCP SERVER LAYER                            │
│   ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
│   │ Tool Srvr│  │ Memory   │  │ External │  │ Custom   │       │
│   │ (81+)    │  │ Server   │  │ APIs     │  │ Prompts  │       │
│   └──────────┘  └──────────┘  └──────────┘  └──────────┘       │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Integration Points

| Component | Role | Integration Method |
|-----------|------|-------------------|
| `MxfMcpClientManager` | Existing MCP client connections | Extend with prompts/list, prompts/get |
| `MxfConfigManager` | Feature toggles | Add `prompts.enabled`, `prompts.cacheStrategy` |
| `SystemLLM` | Natural language interpretation | Use prompts for structured intent mapping |
| `MxfMemoryManager` | Context storage | Store prompt resolution history |
| Channels | Agent coordination | Prompt-based message templates |

---

## 3. Functional Requirements

### 3.1 Prompt Discovery

**FR-001**: The system SHALL discover available prompts from all connected MCP servers on initialization.

**FR-002**: The system SHALL cache prompt metadata (name, title, description, arguments) with configurable TTL.

**FR-003**: The system SHALL support pagination when listing prompts from servers with large prompt catalogs.

**FR-004**: The system SHALL listen for `notifications/prompts/list_changed` and invalidate affected caches.

### 3.2 Prompt Resolution

**FR-005**: The system SHALL resolve prompt arguments from multiple sources:
- Task context (current task parameters, constraints)
- Agent context (role, specialization, conversation history)
- SystemLLM inference
- Default values from prompt definition
- Upstream orchestrator directives

**FR-006**: The system SHALL validate required arguments before sending `prompts/get` requests.

**FR-007**: The system SHALL support argument auto-completion via the MCP completion API.

### 3.3 Content Type Handling

**FR-008**: The system SHALL process all MCP content types in prompt messages:
- `text` — Native string handling
- `image` — Base64 decode, store in memory manager, reference by URI
- `audio` — Base64 decode, forward to audio processing pipeline
- `resource` — Resolve embedded resource URIs against connected servers

**FR-009**: The system SHALL preserve content annotations (audience, priority, modification time) through the resolution pipeline.

### 3.4 Agent Integration

**FR-010**: Agents SHALL be able to request prompts by name with argument bindings.

**FR-011**: The orchestrator SHALL inject resolved prompt messages into agent context according to role specifications.

**FR-012**: The system SHALL support prompt composition—chaining multiple prompts into a single agent context.

### 3.5 MXP 2.0 Compatibility

**FR-013**: Resolved prompts SHALL flow through MXP 2.0 token optimization before LLM invocation.

**FR-014**: The system SHALL track prompt-related token usage separately in analytics.

**FR-015**: Large embedded resources SHALL be eligible for MXP compression and caching.

---

## 4. Non-Functional Requirements

### 4.1 Performance

**NFR-001**: Prompt discovery SHALL complete within 500ms for up to 100 connected MCP servers.

**NFR-002**: Prompt resolution (including argument binding) SHALL complete within 200ms for prompts without embedded resources.

**NFR-003**: Cache hit rate for prompt metadata SHALL exceed 90% during normal operation.

### 4.2 Reliability

**NFR-004**: Prompt resolution failures SHALL NOT block agent execution; fallback to static prompts or graceful degradation.

**NFR-005**: The system SHALL retry transient MCP server failures with exponential backoff (max 3 attempts).

### 4.3 Security

**NFR-006**: All prompt inputs and outputs SHALL be validated against injection attacks.

**NFR-007**: Resource URIs in embedded content SHALL be validated against allowlisted servers.

**NFR-008**: Prompt argument values SHALL be sanitized before interpolation.

### 4.4 Observability

**NFR-009**: The system SHALL emit structured logs for prompt discovery, resolution, and errors.

**NFR-010**: The system SHALL expose Prometheus metrics: `mxf_prompts_resolved_total`, `mxf_prompts_cache_hits`, `mxf_prompts_resolution_duration_seconds`.

---

## 5. Technical Specification

### 5.1 New Interfaces

```typescript
interface MxfPromptsManager {
  // Discovery
  listPrompts(serverId?: string): Promise<PromptDefinition[]>;
  getPrompt(name: string, args?: Record<string, unknown>): Promise<ResolvedPrompt>;
  
  // Cache management
  invalidateCache(serverId?: string): void;
  getCacheStats(): PromptCacheStats;
  
  // Composition
  composePrompts(names: string[], sharedArgs?: Record<string, unknown>): Promise<ResolvedPrompt>;
  
  // Events
  on(event: 'promptsChanged', handler: (serverId: string) => void): void;
}

interface PromptDefinition {
  name: string;
  title?: string;
  description?: string;
  arguments?: PromptArgument[];
  serverId: string;  // MXF extension: track source server
}

interface PromptArgument {
  name: string;
  description?: string;
  required?: boolean;
  defaultValue?: unknown;  // MXF extension
}

interface ResolvedPrompt {
  description?: string;
  messages: PromptMessage[];
  metadata: {
    resolvedAt: Date;
    serverId: string;
    tokenEstimate: number;  // MXP integration
    argumentsUsed: Record<string, unknown>;
  };
}

interface PromptMessage {
  role: 'user' | 'assistant';
  content: PromptContent;
}

type PromptContent = 
  | { type: 'text'; text: string }
  | { type: 'image'; data: string; mimeType: string }
  | { type: 'audio'; data: string; mimeType: string }
  | { type: 'resource'; resource: EmbeddedResource };

interface EmbeddedResource {
  uri: string;
  mimeType: string;
  text?: string;
  blob?: string;  // base64
}
```

### 5.2 Configuration Schema

```typescript
interface MxfPromptsConfig {
  enabled: boolean;
  cache: {
    strategy: 'memory' | 'redis' | 'none';
    ttlSeconds: number;  // default: 300
    maxEntries: number;  // default: 1000
  };
  discovery: {
    refreshIntervalSeconds: number;  // default: 60
    timeoutMs: number;  // default: 5000
  };
  resolution: {
    maxEmbeddedResourceSize: number;  // bytes, default: 1MB
    allowedResourceSchemes: string[];  // default: ['resource://', 'file://']
  };
  mxpIntegration: {
    compressEmbeddedResources: boolean;  // default: true
    trackTokenUsage: boolean;  // default: true
  };
}
```

### 5.3 MCP Protocol Messages

**Listing Prompts (paginated)**
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "prompts/list",
  "params": { "cursor": null }
}
```

**Getting a Prompt**
```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "prompts/get",
  "params": {
    "name": "code_review",
    "arguments": {
      "code": "function hello() { return 'world'; }",
      "language": "typescript"
    }
  }
}
```

---

## 6. Use Cases

### 6.1 Dynamic Agent Persona Loading

**Actor**: Orchestrator  
**Trigger**: Agent joins channel or task assigned  
**Flow**:
1. Orchestrator queries `prompts/list` for persona-type prompts
2. Selects prompt matching agent role (e.g., `persona:code_reviewer`)
3. Resolves with agent-specific arguments (name, specialization, constraints)
4. Injects resolved messages as system context
5. Agent operates with dynamically loaded persona

**Benefit**: Hot-swap agent behaviors without redeployment; A/B test persona variations.

### 6.2 Task Decomposition Templates

**Actor**: SystemLLM  
**Trigger**: Complex task received requiring multi-step reasoning  
**Flow**:
1. SystemLLM identifies task type (research, code generation, analysis)
2. Fetches corresponding decomposition prompt (e.g., `task:research_synthesis`)
3. Resolves with task context and constraints
4. Uses resolved template to structure subtask generation
5. Subtasks flow to appropriate agents via ORAPR

**Benefit**: Consistent reasoning patterns; easier debugging and iteration.

### 6.3 External API Integration Contracts

**Actor**: MCP Tool Server  
**Trigger**: Tool server exposes complex API requiring structured input  
**Flow**:
1. Tool server registers prompts describing expected input formats
2. Agent queries prompt to understand required structure
3. Uses prompt template to format API request
4. Tool server validates request matches prompt contract

**Benefit**: Self-documenting APIs; reduced integration errors.

### 6.4 Multi-Modal Context Injection

**Actor**: Memory Manager  
**Trigger**: Task requires visual or audio context  
**Flow**:
1. Agent requests prompt with embedded resource references
2. Prompts manager resolves resource URIs against memory store
3. Binary content (images, audio) included in resolved messages
4. MXP 2.0 compresses large payloads before LLM invocation

**Benefit**: Seamless multi-modal workflows; efficient resource handling.

---

## 7. Migration & Rollout

### Phase 1: Foundation (Week 1-2)
- [ ] Implement `MxfPromptsManager` core interface
- [ ] Extend `MxfMcpClientManager` with prompts protocol support
- [ ] Add configuration schema to `MxfConfigManager`
- [ ] Unit tests for discovery and resolution

### Phase 2: Integration (Week 3-4)
- [ ] Integrate with SystemLLM for argument inference
- [ ] Connect to MXP 2.0 token tracking
- [ ] Implement cache layer with Redis option
- [ ] Integration tests with mock MCP servers

### Phase 3: Agent Enablement (Week 5-6)
- [ ] Add prompt request methods to agent SDK
- [ ] Implement prompt composition API
- [ ] Build persona loading use case end-to-end
- [ ] Documentation and examples

### Phase 4: Production Hardening (Week 7-8)
- [ ] Performance optimization and benchmarking
- [ ] Security audit for injection vulnerabilities
- [ ] Observability instrumentation
- [ ] Load testing with 50+ concurrent agents

---

## 8. Open Questions

1. **Prompt Versioning**: Should MXF track prompt versions for reproducibility? MCP spec doesn't include versioning.

2. **Cross-Server Composition**: Can prompts reference resources from different MCP servers? Security implications?

3. **SystemLLM Fallback**: When argument inference fails, should we escalate to orchestrator or use heuristics?

4. **Prompt Marketplace**: Future consideration—shared prompt library across MXF deployments?

---

## 9. References

- [MCP Prompts Specification (2025-06-18)](https://modelcontextprotocol.io/specification/2025-06-18/server/prompts)
- MXF System Architecture v2.0
- MXP 2.0 Protocol Specification
- MxfMcpClientManager API Documentation

---

*Document Version: 1.0 | Last Updated: December 2025*
