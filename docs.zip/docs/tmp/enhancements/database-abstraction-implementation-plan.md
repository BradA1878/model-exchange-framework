# MXF Database Abstraction Layer Implementation Plan

## Enabling Plug-and-Play Database Support

**Author:** Architecture Analysis
**Version:** 1.0
**Date:** December 2025
**Status:** Implementation Ready
**Estimated Effort:** 4-6 weeks (MVP) / 9-15 weeks (Full)

---

## Executive Summary

This document provides a detailed implementation plan for introducing a database abstraction layer to the Model Exchange Framework (MXF). The goal is to enable "plug-and-play" database support, allowing users to bring their own database (PostgreSQL, MySQL, SQLite, etc.) instead of the current MongoDB-only implementation.

**Current State:** MXF is tightly coupled to MongoDB via Mongoose with 20+ models and direct database access in ~15 service files.

**Target State:** A clean Repository pattern implementation where database-specific code is isolated in adapters, and all business logic operates through database-agnostic interfaces.

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Phase 1: Repository Interfaces](#2-phase-1-repository-interfaces)
3. [Phase 2: MongoDB Adapter Implementation](#3-phase-2-mongodb-adapter-implementation)
4. [Phase 3: Service Layer Refactoring](#4-phase-3-service-layer-refactoring)
5. [Phase 4: Query Builder Abstraction](#5-phase-4-query-builder-abstraction)
6. [Phase 5: Alternative Database Adapters](#6-phase-5-alternative-database-adapters)
7. [Testing Strategy](#7-testing-strategy)
8. [File Inventory](#8-file-inventory)
9. [Task Breakdown for Agents](#9-task-breakdown-for-agents)

---

## 1. Architecture Overview

### 1.1 Target Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      Service Layer                               │
│  (AgentService, ChannelService, TaskService, etc.)              │
│  - Contains business logic                                       │
│  - Database agnostic                                             │
│  - Depends only on Repository interfaces                         │
└─────────────────────────┬───────────────────────────────────────┘
                          │ Injects
┌─────────────────────────▼───────────────────────────────────────┐
│                   Repository Interfaces                          │
│  (IAgentRepository, IChannelRepository, ITaskRepository, etc.)  │
│  - Define data access contracts                                  │
│  - Return domain types (not DB-specific types)                   │
└─────────────────────────┬───────────────────────────────────────┘
                          │ Implements
┌─────────────────────────▼───────────────────────────────────────┐
│                    Database Adapters                             │
├──────────────────┬──────────────────┬───────────────────────────┤
│  MongoAdapter    │  PostgresAdapter │  SQLiteAdapter            │
│  (Current impl)  │  (Future)        │  (Future)                 │
└──────────────────┴──────────────────┴───────────────────────────┘
```

### 1.2 Key Design Principles

1. **Interface Segregation**: Small, focused repository interfaces
2. **Dependency Inversion**: Services depend on abstractions, not implementations
3. **Single Responsibility**: Each repository handles one domain entity
4. **Adapter Pattern**: Database-specific code isolated in adapters
5. **Factory Pattern**: DatabaseAdapterFactory creates appropriate adapters based on config

### 1.3 Directory Structure (New)

```
src/
├── shared/
│   ├── repositories/
│   │   ├── interfaces/
│   │   │   ├── IAgentRepository.ts
│   │   │   ├── IChannelRepository.ts
│   │   │   ├── ITaskRepository.ts
│   │   │   ├── IMemoryRepository.ts
│   │   │   ├── IUserRepository.ts
│   │   │   ├── IToolRepository.ts
│   │   │   ├── IAuditRepository.ts
│   │   │   ├── IPatternRepository.ts
│   │   │   ├── IAnalyticsRepository.ts
│   │   │   └── index.ts
│   │   ├── types/
│   │   │   ├── QueryTypes.ts
│   │   │   ├── FilterTypes.ts
│   │   │   └── PaginationTypes.ts
│   │   └── index.ts
│   └── database/
│       ├── adapters/
│       │   ├── mongodb/
│       │   │   ├── MongoAgentRepository.ts
│       │   │   ├── MongoChannelRepository.ts
│       │   │   ├── MongoTaskRepository.ts
│       │   │   ├── MongoMemoryRepository.ts
│       │   │   ├── MongoUserRepository.ts
│       │   │   ├── MongoToolRepository.ts
│       │   │   ├── MongoAuditRepository.ts
│       │   │   ├── MongoPatternRepository.ts
│       │   │   ├── MongoAnalyticsRepository.ts
│       │   │   └── index.ts
│       │   ├── postgresql/
│       │   │   └── (future implementation)
│       │   └── sqlite/
│       │       └── (future implementation)
│       ├── DatabaseAdapterFactory.ts
│       ├── DatabaseConnection.ts
│       └── index.ts
```

---

## 2. Phase 1: Repository Interfaces

### 2.1 Overview

Create database-agnostic interfaces that define the contract for all data operations. These interfaces use domain types from `src/shared/types/` and return Promises (not Mongoose documents).

### 2.2 Interface Definitions

#### 2.2.1 Base Repository Interface

**File:** `src/shared/repositories/interfaces/IBaseRepository.ts`

```typescript
import { PaginationOptions, PaginatedResult } from '../types/PaginationTypes';
import { FilterOptions } from '../types/FilterTypes';

/**
 * Base repository interface that all domain repositories extend.
 * Provides common CRUD operations.
 *
 * @typeParam T - The domain entity type
 * @typeParam CreateDTO - The type for creating new entities
 * @typeParam UpdateDTO - The type for updating entities
 */
export interface IBaseRepository<T, CreateDTO = Partial<T>, UpdateDTO = Partial<T>> {
    /**
     * Find a single entity by its unique identifier
     */
    findById(id: string): Promise<T | null>;

    /**
     * Find multiple entities matching the filter criteria
     */
    findMany(filter?: FilterOptions<T>, pagination?: PaginationOptions): Promise<PaginatedResult<T>>;

    /**
     * Find a single entity matching the filter criteria
     */
    findOne(filter: FilterOptions<T>): Promise<T | null>;

    /**
     * Create a new entity
     */
    create(data: CreateDTO): Promise<T>;

    /**
     * Update an existing entity by ID
     */
    update(id: string, data: UpdateDTO): Promise<T | null>;

    /**
     * Delete an entity by ID
     */
    delete(id: string): Promise<boolean>;

    /**
     * Count entities matching the filter
     */
    count(filter?: FilterOptions<T>): Promise<number>;

    /**
     * Check if an entity exists
     */
    exists(filter: FilterOptions<T>): Promise<boolean>;
}
```

#### 2.2.2 Agent Repository Interface

**File:** `src/shared/repositories/interfaces/IAgentRepository.ts`

```typescript
import { IAgent, AgentStatus } from '../../types/agentTypes';
import { IBaseRepository } from './IBaseRepository';

/**
 * Repository interface for Agent entities.
 * Extends base CRUD with agent-specific operations.
 */
export interface IAgentRepository extends IBaseRepository<IAgent> {
    /**
     * Find agent by its unique agentId (not MongoDB _id)
     */
    findByAgentId(agentId: string): Promise<IAgent | null>;

    /**
     * Find agent by API key identifier
     */
    findByKeyId(keyId: string): Promise<IAgent | null>;

    /**
     * Find agents by their service types
     * @param types - Array of service type strings to match
     * @param matchAll - If true, agent must have ALL types; if false, ANY type
     */
    findByServiceTypes(types: string[], matchAll?: boolean): Promise<IAgent[]>;

    /**
     * Find agents by status
     */
    findByStatus(status: AgentStatus): Promise<IAgent[]>;

    /**
     * Find agents currently in a specific channel
     */
    findByChannel(channelId: string): Promise<IAgent[]>;

    /**
     * Update agent's online status
     */
    updateStatus(agentId: string, status: AgentStatus): Promise<IAgent | null>;

    /**
     * Update agent's last active timestamp
     */
    updateLastActive(agentId: string, timestamp?: Date): Promise<void>;

    /**
     * Add a channel to agent's channel list
     */
    addChannel(agentId: string, channelId: string): Promise<IAgent | null>;

    /**
     * Remove a channel from agent's channel list
     */
    removeChannel(agentId: string, channelId: string): Promise<IAgent | null>;

    /**
     * Find agents with stale heartbeats (for cleanup)
     * @param thresholdMs - Milliseconds since last heartbeat to consider stale
     */
    findStaleAgents(thresholdMs: number): Promise<IAgent[]>;

    /**
     * Bulk update status for multiple agents
     */
    bulkUpdateStatus(agentIds: string[], status: AgentStatus): Promise<number>;
}
```

#### 2.2.3 Channel Repository Interface

**File:** `src/shared/repositories/interfaces/IChannelRepository.ts`

```typescript
import { IChannel, ChannelType } from '../../types/channelTypes';
import { IBaseRepository } from './IBaseRepository';

/**
 * Repository interface for Channel entities.
 */
export interface IChannelRepository extends IBaseRepository<IChannel> {
    /**
     * Find channel by its unique channelId
     */
    findByChannelId(channelId: string): Promise<IChannel | null>;

    /**
     * Find channels by type
     */
    findByType(type: ChannelType): Promise<IChannel[]>;

    /**
     * Find channels that an agent is a participant of
     */
    findByParticipant(agentId: string): Promise<IChannel[]>;

    /**
     * Find channels created by a specific user/agent
     */
    findByCreator(creatorId: string): Promise<IChannel[]>;

    /**
     * Add a participant to a channel
     * Ensures no duplicates are added
     */
    addParticipant(channelId: string, participantId: string): Promise<IChannel | null>;

    /**
     * Remove a participant from a channel
     */
    removeParticipant(channelId: string, participantId: string): Promise<IChannel | null>;

    /**
     * Get all participants of a channel
     */
    getParticipants(channelId: string): Promise<string[]>;

    /**
     * Check if an agent is a participant in a channel
     */
    isParticipant(channelId: string, agentId: string): Promise<boolean>;

    /**
     * Update channel's last active timestamp
     */
    updateLastActive(channelId: string, timestamp?: Date): Promise<void>;

    /**
     * Search channels by name (partial match)
     */
    searchByName(query: string): Promise<IChannel[]>;

    /**
     * Get channel statistics (participant count, message count, etc.)
     */
    getStatistics(channelId: string): Promise<ChannelStatistics>;
}

export interface ChannelStatistics {
    participantCount: number;
    messageCount: number;
    taskCount: number;
    lastActiveAt: Date | null;
    createdAt: Date;
}
```

#### 2.2.4 Task Repository Interface

**File:** `src/shared/repositories/interfaces/ITaskRepository.ts`

```typescript
import { ITask, TaskStatus, TaskPriority } from '../../types/taskTypes';
import { IBaseRepository } from './IBaseRepository';
import { DateRange } from '../types/FilterTypes';

/**
 * Repository interface for Task entities.
 */
export interface ITaskRepository extends IBaseRepository<ITask> {
    /**
     * Find task by its unique taskId
     */
    findByTaskId(taskId: string): Promise<ITask | null>;

    /**
     * Find tasks belonging to a channel
     */
    findByChannel(channelId: string, filters?: TaskFilters): Promise<ITask[]>;

    /**
     * Find tasks assigned to an agent
     */
    findByAssignee(agentId: string, filters?: TaskFilters): Promise<ITask[]>;

    /**
     * Find tasks created by an agent
     */
    findByCreator(agentId: string, filters?: TaskFilters): Promise<ITask[]>;

    /**
     * Find tasks by status
     */
    findByStatus(status: TaskStatus | TaskStatus[]): Promise<ITask[]>;

    /**
     * Find tasks by priority
     */
    findByPriority(priority: TaskPriority): Promise<ITask[]>;

    /**
     * Find overdue tasks (deadline passed, not completed)
     */
    findOverdue(): Promise<ITask[]>;

    /**
     * Find tasks due within a time range
     */
    findByDeadlineRange(range: DateRange): Promise<ITask[]>;

    /**
     * Update task status
     */
    updateStatus(taskId: string, status: TaskStatus, metadata?: Record<string, any>): Promise<ITask | null>;

    /**
     * Assign task to an agent
     */
    assignTo(taskId: string, agentId: string): Promise<ITask | null>;

    /**
     * Unassign task from current assignee
     */
    unassign(taskId: string): Promise<ITask | null>;

    /**
     * Add a subtask to a parent task
     */
    addSubtask(parentTaskId: string, subtaskId: string): Promise<ITask | null>;

    /**
     * Get task hierarchy (parent and all subtasks)
     */
    getTaskHierarchy(taskId: string): Promise<TaskHierarchy>;

    /**
     * Get task statistics for a channel
     */
    getChannelStatistics(channelId: string): Promise<TaskStatistics>;

    /**
     * Get task statistics for an agent
     */
    getAgentStatistics(agentId: string): Promise<TaskStatistics>;

    /**
     * Full-text search on task title and description
     * Note: Implementation may vary by database
     */
    search(query: string, filters?: TaskFilters): Promise<ITask[]>;
}

export interface TaskFilters {
    status?: TaskStatus | TaskStatus[];
    priority?: TaskPriority;
    assigneeId?: string;
    createdRange?: DateRange;
    deadlineRange?: DateRange;
}

export interface TaskHierarchy {
    task: ITask;
    parent: ITask | null;
    subtasks: ITask[];
}

export interface TaskStatistics {
    total: number;
    byStatus: Record<TaskStatus, number>;
    byPriority: Record<TaskPriority, number>;
    overdueCount: number;
    averageCompletionTime?: number;
}
```

#### 2.2.5 Memory Repository Interface

**File:** `src/shared/repositories/interfaces/IMemoryRepository.ts`

```typescript
import {
    IAgentMemory,
    IChannelMemory,
    IRelationshipMemory,
    MemoryScope
} from '../../types/memoryTypes';
import { IBaseRepository } from './IBaseRepository';

/**
 * Repository interface for Memory entities.
 * Handles agent, channel, and relationship memory.
 */
export interface IMemoryRepository {
    // Agent Memory Operations
    /**
     * Get memory for a specific agent
     */
    getAgentMemory(agentId: string): Promise<IAgentMemory | null>;

    /**
     * Save or update agent memory
     */
    saveAgentMemory(memory: IAgentMemory): Promise<IAgentMemory>;

    /**
     * Update specific fields in agent memory
     */
    updateAgentMemory(agentId: string, updates: Partial<IAgentMemory>): Promise<IAgentMemory | null>;

    /**
     * Delete agent memory
     */
    deleteAgentMemory(agentId: string): Promise<boolean>;

    // Channel Memory Operations
    /**
     * Get memory for a specific channel
     */
    getChannelMemory(channelId: string): Promise<IChannelMemory | null>;

    /**
     * Save or update channel memory
     */
    saveChannelMemory(memory: IChannelMemory): Promise<IChannelMemory>;

    /**
     * Update specific fields in channel memory
     */
    updateChannelMemory(channelId: string, updates: Partial<IChannelMemory>): Promise<IChannelMemory | null>;

    /**
     * Delete channel memory
     */
    deleteChannelMemory(channelId: string): Promise<boolean>;

    // Relationship Memory Operations
    /**
     * Get memory for a relationship between two agents
     */
    getRelationshipMemory(agentId1: string, agentId2: string): Promise<IRelationshipMemory | null>;

    /**
     * Save or update relationship memory
     */
    saveRelationshipMemory(memory: IRelationshipMemory): Promise<IRelationshipMemory>;

    /**
     * Get all relationships for an agent
     */
    getAgentRelationships(agentId: string): Promise<IRelationshipMemory[]>;

    /**
     * Delete relationship memory
     */
    deleteRelationshipMemory(agentId1: string, agentId2: string): Promise<boolean>;

    // Bulk Operations
    /**
     * Delete all memory for a scope and ID
     */
    deleteByScope(scope: MemoryScope, id: string): Promise<boolean>;

    /**
     * Get memory statistics
     */
    getStatistics(): Promise<MemoryStatistics>;
}

export interface MemoryStatistics {
    agentMemoryCount: number;
    channelMemoryCount: number;
    relationshipMemoryCount: number;
    totalSizeBytes?: number;
}
```

#### 2.2.6 Analytics Repository Interface

**File:** `src/shared/repositories/interfaces/IAnalyticsRepository.ts`

```typescript
import { DateRange, TimeGranularity } from '../types/FilterTypes';

/**
 * Repository interface for Analytics operations.
 * These operations are inherently more complex and may have
 * different implementations across databases.
 */
export interface IAnalyticsRepository {
    // Agent Analytics
    /**
     * Get agent status distribution
     */
    getAgentStatusDistribution(): Promise<StatusDistribution[]>;

    /**
     * Get agent activity over time
     */
    getAgentActivityTimeline(
        range: DateRange,
        granularity: TimeGranularity
    ): Promise<TimelineDataPoint[]>;

    /**
     * Get agent capability distribution
     */
    getAgentCapabilityDistribution(): Promise<CapabilityDistribution[]>;

    // Channel Analytics
    /**
     * Get channel activity distribution
     */
    getChannelActivityDistribution(): Promise<ActivityDistribution[]>;

    /**
     * Get channel participant distribution
     */
    getChannelParticipantDistribution(): Promise<ParticipantDistribution[]>;

    // Task Analytics
    /**
     * Get task status counts
     */
    getTaskStatusCounts(): Promise<StatusCount[]>;

    /**
     * Get task completion rate over time
     */
    getTaskCompletionTimeline(
        range: DateRange,
        granularity: TimeGranularity
    ): Promise<TimelineDataPoint[]>;

    /**
     * Get average task completion time by priority
     */
    getAverageCompletionTimeByPriority(): Promise<CompletionTimeByPriority[]>;

    // Audit Analytics
    /**
     * Get audit event distribution by type
     */
    getAuditEventDistribution(range?: DateRange): Promise<EventDistribution[]>;

    /**
     * Get audit activity timeline
     */
    getAuditActivityTimeline(
        range: DateRange,
        granularity: TimeGranularity
    ): Promise<TimelineDataPoint[]>;

    // Tool Analytics
    /**
     * Get most used tools
     */
    getMostUsedTools(limit?: number): Promise<ToolUsage[]>;

    /**
     * Get tool success rates
     */
    getToolSuccessRates(): Promise<ToolSuccessRate[]>;
}

// Analytics Types
export interface StatusDistribution {
    status: string;
    count: number;
    percentage: number;
}

export interface TimelineDataPoint {
    timestamp: string; // ISO date string or formatted date
    value: number;
    label?: string;
}

export interface CapabilityDistribution {
    capability: string;
    agentCount: number;
}

export interface ActivityDistribution {
    channelId: string;
    channelName: string;
    activityScore: number;
    messageCount: number;
    taskCount: number;
}

export interface ParticipantDistribution {
    range: string; // e.g., "1-5", "6-10", "11+"
    channelCount: number;
}

export interface StatusCount {
    status: string;
    count: number;
}

export interface CompletionTimeByPriority {
    priority: string;
    averageTimeMs: number;
    taskCount: number;
}

export interface EventDistribution {
    eventType: string;
    count: number;
}

export interface ToolUsage {
    toolName: string;
    useCount: number;
    lastUsed: Date;
}

export interface ToolSuccessRate {
    toolName: string;
    totalCalls: number;
    successCount: number;
    failureCount: number;
    successRate: number;
}
```

### 2.3 Supporting Types

#### 2.3.1 Filter Types

**File:** `src/shared/repositories/types/FilterTypes.ts`

```typescript
/**
 * Generic filter options for repository queries.
 * Database adapters translate these to native query syntax.
 */
export interface FilterOptions<T> {
    /** Field equality filters */
    where?: Partial<Record<keyof T, any>>;

    /** Comparison filters */
    comparisons?: ComparisonFilter<T>[];

    /** Array containment filters */
    arrayContains?: ArrayContainsFilter<T>[];

    /** Text search (if supported) */
    textSearch?: string;

    /** Logical OR of multiple filter sets */
    or?: FilterOptions<T>[];

    /** Logical AND of multiple filter sets */
    and?: FilterOptions<T>[];
}

export interface ComparisonFilter<T> {
    field: keyof T;
    operator: ComparisonOperator;
    value: any;
}

export type ComparisonOperator =
    | 'eq'      // equals
    | 'ne'      // not equals
    | 'gt'      // greater than
    | 'gte'     // greater than or equal
    | 'lt'      // less than
    | 'lte'     // less than or equal
    | 'in'      // in array
    | 'nin'     // not in array
    | 'like'    // pattern match (SQL LIKE)
    | 'regex';  // regex match

export interface ArrayContainsFilter<T> {
    field: keyof T;
    value: any;
    mode: 'any' | 'all'; // contains any of values, or all values
}

export interface DateRange {
    start?: Date;
    end?: Date;
}

export type TimeGranularity = 'hour' | 'day' | 'week' | 'month' | 'year';
```

#### 2.3.2 Pagination Types

**File:** `src/shared/repositories/types/PaginationTypes.ts`

```typescript
/**
 * Pagination options for list queries.
 */
export interface PaginationOptions {
    /** Number of items to return (default: 20) */
    limit?: number;

    /** Number of items to skip (default: 0) */
    offset?: number;

    /** Sort field */
    sortBy?: string;

    /** Sort direction */
    sortOrder?: 'asc' | 'desc';

    /** Cursor for cursor-based pagination (alternative to offset) */
    cursor?: string;
}

/**
 * Paginated result wrapper.
 */
export interface PaginatedResult<T> {
    /** The items for this page */
    items: T[];

    /** Total count of items (if countable) */
    total: number;

    /** Whether there are more items */
    hasMore: boolean;

    /** Cursor for next page (if using cursor pagination) */
    nextCursor?: string;

    /** Current page info */
    pagination: {
        limit: number;
        offset: number;
        page: number;
        totalPages: number;
    };
}
```

---

## 3. Phase 2: MongoDB Adapter Implementation

### 3.1 Overview

Implement the repository interfaces using Mongoose. This phase refactors existing code into the new structure without changing functionality.

### 3.2 Base MongoDB Repository

**File:** `src/shared/database/adapters/mongodb/MongoBaseRepository.ts`

```typescript
import { Model, Document, FilterQuery, UpdateQuery } from 'mongoose';
import { IBaseRepository } from '../../../repositories/interfaces/IBaseRepository';
import { FilterOptions } from '../../../repositories/types/FilterTypes';
import { PaginationOptions, PaginatedResult } from '../../../repositories/types/PaginationTypes';

/**
 * Base MongoDB repository implementation.
 * Provides common CRUD operations using Mongoose.
 */
export abstract class MongoBaseRepository<T, D extends Document, CreateDTO = Partial<T>, UpdateDTO = Partial<T>>
    implements IBaseRepository<T, CreateDTO, UpdateDTO> {

    constructor(protected readonly model: Model<D>) {}

    async findById(id: string): Promise<T | null> {
        const doc = await this.model.findById(id).lean();
        return doc ? this.toEntity(doc) : null;
    }

    async findOne(filter: FilterOptions<T>): Promise<T | null> {
        const mongoFilter = this.buildMongoFilter(filter);
        const doc = await this.model.findOne(mongoFilter).lean();
        return doc ? this.toEntity(doc) : null;
    }

    async findMany(
        filter?: FilterOptions<T>,
        pagination?: PaginationOptions
    ): Promise<PaginatedResult<T>> {
        const mongoFilter = filter ? this.buildMongoFilter(filter) : {};
        const { limit = 20, offset = 0, sortBy, sortOrder = 'desc' } = pagination || {};

        const [docs, total] = await Promise.all([
            this.model
                .find(mongoFilter)
                .sort(sortBy ? { [sortBy]: sortOrder === 'asc' ? 1 : -1 } : { createdAt: -1 })
                .skip(offset)
                .limit(limit)
                .lean(),
            this.model.countDocuments(mongoFilter)
        ]);

        return {
            items: docs.map(doc => this.toEntity(doc)),
            total,
            hasMore: offset + docs.length < total,
            pagination: {
                limit,
                offset,
                page: Math.floor(offset / limit) + 1,
                totalPages: Math.ceil(total / limit)
            }
        };
    }

    async create(data: CreateDTO): Promise<T> {
        const doc = await this.model.create(data);
        return this.toEntity(doc.toObject());
    }

    async update(id: string, data: UpdateDTO): Promise<T | null> {
        const doc = await this.model.findByIdAndUpdate(
            id,
            { $set: data } as UpdateQuery<D>,
            { new: true }
        ).lean();
        return doc ? this.toEntity(doc) : null;
    }

    async delete(id: string): Promise<boolean> {
        const result = await this.model.deleteOne({ _id: id });
        return result.deletedCount > 0;
    }

    async count(filter?: FilterOptions<T>): Promise<number> {
        const mongoFilter = filter ? this.buildMongoFilter(filter) : {};
        return this.model.countDocuments(mongoFilter);
    }

    async exists(filter: FilterOptions<T>): Promise<boolean> {
        const mongoFilter = this.buildMongoFilter(filter);
        const doc = await this.model.findOne(mongoFilter).select('_id').lean();
        return doc !== null;
    }

    /**
     * Convert Mongoose document to domain entity.
     * Override in subclasses for custom mapping.
     */
    protected abstract toEntity(doc: any): T;

    /**
     * Build MongoDB filter from generic FilterOptions.
     */
    protected buildMongoFilter(filter: FilterOptions<T>): FilterQuery<D> {
        const mongoFilter: any = {};

        // Direct equality filters
        if (filter.where) {
            Object.assign(mongoFilter, filter.where);
        }

        // Comparison filters
        if (filter.comparisons) {
            for (const comp of filter.comparisons) {
                const mongoOp = this.mapComparisonOperator(comp.operator);
                mongoFilter[comp.field] = { [mongoOp]: comp.value };
            }
        }

        // Array contains filters
        if (filter.arrayContains) {
            for (const arr of filter.arrayContains) {
                if (arr.mode === 'any') {
                    mongoFilter[arr.field] = { $in: Array.isArray(arr.value) ? arr.value : [arr.value] };
                } else {
                    mongoFilter[arr.field] = { $all: Array.isArray(arr.value) ? arr.value : [arr.value] };
                }
            }
        }

        // Text search
        if (filter.textSearch) {
            mongoFilter.$text = { $search: filter.textSearch };
        }

        // OR conditions
        if (filter.or && filter.or.length > 0) {
            mongoFilter.$or = filter.or.map(f => this.buildMongoFilter(f));
        }

        // AND conditions
        if (filter.and && filter.and.length > 0) {
            mongoFilter.$and = filter.and.map(f => this.buildMongoFilter(f));
        }

        return mongoFilter as FilterQuery<D>;
    }

    private mapComparisonOperator(op: string): string {
        const mapping: Record<string, string> = {
            'eq': '$eq',
            'ne': '$ne',
            'gt': '$gt',
            'gte': '$gte',
            'lt': '$lt',
            'lte': '$lte',
            'in': '$in',
            'nin': '$nin',
            'regex': '$regex'
        };
        return mapping[op] || '$eq';
    }
}
```

### 3.3 MongoDB Agent Repository

**File:** `src/shared/database/adapters/mongodb/MongoAgentRepository.ts`

```typescript
import { Agent, IAgentDocument } from '../../../models/agent';
import { IAgent, AgentStatus } from '../../../types/agentTypes';
import { IAgentRepository } from '../../../repositories/interfaces/IAgentRepository';
import { MongoBaseRepository } from './MongoBaseRepository';

export class MongoAgentRepository
    extends MongoBaseRepository<IAgent, IAgentDocument>
    implements IAgentRepository {

    constructor() {
        super(Agent);
    }

    protected toEntity(doc: any): IAgent {
        return {
            agentId: doc.agentId,
            name: doc.name,
            description: doc.description,
            serviceTypes: doc.serviceTypes || [],
            capabilities: doc.capabilities || [],
            status: doc.status,
            currentChannels: doc.currentChannels || [],
            allowedTools: doc.allowedTools,
            metadata: doc.metadata,
            lastHeartbeat: doc.lastHeartbeat,
            createdAt: doc.createdAt,
            updatedAt: doc.updatedAt
        };
    }

    async findByAgentId(agentId: string): Promise<IAgent | null> {
        const doc = await this.model.findOne({ agentId }).lean();
        return doc ? this.toEntity(doc) : null;
    }

    async findByKeyId(keyId: string): Promise<IAgent | null> {
        const doc = await this.model.findOne({ keyId }).lean();
        return doc ? this.toEntity(doc) : null;
    }

    async findByServiceTypes(types: string[], matchAll = false): Promise<IAgent[]> {
        const query = matchAll
            ? { serviceTypes: { $all: types } }
            : { serviceTypes: { $in: types } };
        const docs = await this.model.find(query).lean();
        return docs.map(doc => this.toEntity(doc));
    }

    async findByStatus(status: AgentStatus): Promise<IAgent[]> {
        const docs = await this.model.find({ status }).lean();
        return docs.map(doc => this.toEntity(doc));
    }

    async findByChannel(channelId: string): Promise<IAgent[]> {
        const docs = await this.model.find({ currentChannels: channelId }).lean();
        return docs.map(doc => this.toEntity(doc));
    }

    async updateStatus(agentId: string, status: AgentStatus): Promise<IAgent | null> {
        const doc = await this.model.findOneAndUpdate(
            { agentId },
            { $set: { status, lastHeartbeat: new Date() } },
            { new: true }
        ).lean();
        return doc ? this.toEntity(doc) : null;
    }

    async updateLastActive(agentId: string, timestamp = new Date()): Promise<void> {
        await this.model.updateOne(
            { agentId },
            { $set: { lastHeartbeat: timestamp } }
        );
    }

    async addChannel(agentId: string, channelId: string): Promise<IAgent | null> {
        const doc = await this.model.findOneAndUpdate(
            { agentId },
            { $addToSet: { currentChannels: channelId } },
            { new: true }
        ).lean();
        return doc ? this.toEntity(doc) : null;
    }

    async removeChannel(agentId: string, channelId: string): Promise<IAgent | null> {
        const doc = await this.model.findOneAndUpdate(
            { agentId },
            { $pull: { currentChannels: channelId } },
            { new: true }
        ).lean();
        return doc ? this.toEntity(doc) : null;
    }

    async findStaleAgents(thresholdMs: number): Promise<IAgent[]> {
        const threshold = new Date(Date.now() - thresholdMs);
        const docs = await this.model.find({
            status: 'online',
            lastHeartbeat: { $lt: threshold }
        }).lean();
        return docs.map(doc => this.toEntity(doc));
    }

    async bulkUpdateStatus(agentIds: string[], status: AgentStatus): Promise<number> {
        const result = await this.model.updateMany(
            { agentId: { $in: agentIds } },
            { $set: { status } }
        );
        return result.modifiedCount;
    }
}
```

### 3.4 Database Adapter Factory

**File:** `src/shared/database/DatabaseAdapterFactory.ts`

```typescript
import { IAgentRepository } from '../repositories/interfaces/IAgentRepository';
import { IChannelRepository } from '../repositories/interfaces/IChannelRepository';
import { ITaskRepository } from '../repositories/interfaces/ITaskRepository';
import { IMemoryRepository } from '../repositories/interfaces/IMemoryRepository';
import { IAnalyticsRepository } from '../repositories/interfaces/IAnalyticsRepository';

// MongoDB implementations
import { MongoAgentRepository } from './adapters/mongodb/MongoAgentRepository';
import { MongoChannelRepository } from './adapters/mongodb/MongoChannelRepository';
import { MongoTaskRepository } from './adapters/mongodb/MongoTaskRepository';
import { MongoMemoryRepository } from './adapters/mongodb/MongoMemoryRepository';
import { MongoAnalyticsRepository } from './adapters/mongodb/MongoAnalyticsRepository';

export type DatabaseType = 'mongodb' | 'postgresql' | 'sqlite' | 'mysql';

export interface DatabaseConfig {
    type: DatabaseType;
    connectionString: string;
    options?: Record<string, any>;
}

export interface RepositoryBundle {
    agents: IAgentRepository;
    channels: IChannelRepository;
    tasks: ITaskRepository;
    memory: IMemoryRepository;
    analytics: IAnalyticsRepository;
    // Add more as needed
}

/**
 * Factory for creating database-specific repository implementations.
 * Usage:
 *   const repos = DatabaseAdapterFactory.create({ type: 'mongodb', connectionString: '...' });
 *   const agent = await repos.agents.findByAgentId('agent-1');
 */
export class DatabaseAdapterFactory {
    private static instance: RepositoryBundle | null = null;
    private static config: DatabaseConfig | null = null;

    /**
     * Initialize the factory with database configuration.
     * Must be called before create().
     */
    static initialize(config: DatabaseConfig): void {
        this.config = config;
        this.instance = null; // Reset instance on re-initialization
    }

    /**
     * Create or return the repository bundle.
     */
    static create(): RepositoryBundle {
        if (!this.config) {
            throw new Error('DatabaseAdapterFactory not initialized. Call initialize() first.');
        }

        if (this.instance) {
            return this.instance;
        }

        switch (this.config.type) {
            case 'mongodb':
                this.instance = this.createMongoRepositories();
                break;
            case 'postgresql':
                throw new Error('PostgreSQL adapter not yet implemented');
            case 'sqlite':
                throw new Error('SQLite adapter not yet implemented');
            case 'mysql':
                throw new Error('MySQL adapter not yet implemented');
            default:
                throw new Error(`Unknown database type: ${this.config.type}`);
        }

        return this.instance;
    }

    /**
     * Get the current configuration.
     */
    static getConfig(): DatabaseConfig | null {
        return this.config;
    }

    private static createMongoRepositories(): RepositoryBundle {
        return {
            agents: new MongoAgentRepository(),
            channels: new MongoChannelRepository(),
            tasks: new MongoTaskRepository(),
            memory: new MongoMemoryRepository(),
            analytics: new MongoAnalyticsRepository()
        };
    }
}
```

---

## 4. Phase 3: Service Layer Refactoring

### 4.1 Overview

Refactor existing services to use repository interfaces instead of direct Mongoose access. This is the most labor-intensive phase.

### 4.2 Refactoring Pattern

**Before (Direct Mongoose):**
```typescript
// src/server/socket/services/AgentService.ts
import { Agent } from '../../../shared/models/agent';

class AgentService {
    async getAgent(agentId: string) {
        return Agent.findOne({ agentId });
    }

    async updateStatus(agentId: string, status: string) {
        return Agent.findOneAndUpdate(
            { agentId },
            { $set: { status, lastHeartbeat: new Date() } },
            { new: true }
        );
    }
}
```

**After (Repository Pattern):**
```typescript
// src/server/socket/services/AgentService.ts
import { IAgentRepository } from '../../../shared/repositories/interfaces/IAgentRepository';
import { DatabaseAdapterFactory } from '../../../shared/database/DatabaseAdapterFactory';

class AgentService {
    private agentRepository: IAgentRepository;

    constructor() {
        this.agentRepository = DatabaseAdapterFactory.create().agents;
    }

    async getAgent(agentId: string) {
        return this.agentRepository.findByAgentId(agentId);
    }

    async updateStatus(agentId: string, status: AgentStatus) {
        return this.agentRepository.updateStatus(agentId, status);
    }
}
```

### 4.3 Files Requiring Refactoring

| File | Current DB Access | Priority |
|------|-------------------|----------|
| `src/server/socket/services/AgentService.ts` | Direct Agent model | High |
| `src/server/socket/services/ChannelService.ts` | Direct Channel model | High |
| `src/server/socket/services/TaskService.ts` | Direct Task model | High |
| `src/server/api/services/MemoryPersistenceService.ts` | Already has interface | Medium |
| `src/server/api/controllers/agentController.ts` | Direct Agent model | Medium |
| `src/server/api/controllers/channelController.ts` | Direct Channel model | Medium |
| `src/server/api/controllers/taskController.ts` | Direct Task model | Medium |
| `src/server/api/controllers/documentController.ts` | Direct Document model | Low |
| `src/server/api/controllers/dashboardController.ts` | Direct model access | Low |
| `src/server/api/routes/analytics.ts` | Raw db.collection() | High (Complex) |
| `src/shared/services/PatternLearningService.ts` | Direct Pattern models | Medium |

### 4.4 Server Initialization Updates

**File:** `src/server/index.ts`

Add database initialization early in the startup sequence:

```typescript
import { DatabaseAdapterFactory } from '../shared/database/DatabaseAdapterFactory';

async function initializeServer() {
    // 1. Initialize database adapter (before services)
    DatabaseAdapterFactory.initialize({
        type: (process.env.DB_TYPE as DatabaseType) || 'mongodb',
        connectionString: process.env.MONGODB_URI || 'mongodb://localhost:27017/mxf'
    });

    // 2. Connect to database
    await DatabaseService.getInstance().connect();

    // 3. Initialize services (they'll use the factory)
    // ... rest of initialization
}
```

---

## 5. Phase 4: Query Builder Abstraction

### 5.1 Overview

For complex queries that don't fit the standard repository methods, provide a fluent query builder that can be translated to any database.

### 5.2 Query Builder Interface

**File:** `src/shared/repositories/types/QueryBuilder.ts`

```typescript
/**
 * Fluent query builder for complex queries.
 * Each database adapter provides its own implementation.
 */
export interface IQueryBuilder<T> {
    /** Filter by field equality */
    where(field: keyof T, value: any): this;

    /** Filter by comparison */
    whereCompare(field: keyof T, operator: ComparisonOperator, value: any): this;

    /** Filter where field is in array */
    whereIn(field: keyof T, values: any[]): this;

    /** Filter where field is not in array */
    whereNotIn(field: keyof T, values: any[]): this;

    /** Filter where array field contains value */
    whereArrayContains(field: keyof T, value: any): this;

    /** Add OR condition group */
    orWhere(builder: (qb: IQueryBuilder<T>) => void): this;

    /** Add AND condition group */
    andWhere(builder: (qb: IQueryBuilder<T>) => void): this;

    /** Order results */
    orderBy(field: keyof T, direction?: 'asc' | 'desc'): this;

    /** Limit results */
    limit(count: number): this;

    /** Skip results */
    offset(count: number): this;

    /** Select specific fields */
    select(...fields: (keyof T)[]): this;

    /** Execute and return results */
    execute(): Promise<T[]>;

    /** Execute and return first result */
    first(): Promise<T | null>;

    /** Execute and return count */
    count(): Promise<number>;
}
```

---

## 6. Phase 5: Alternative Database Adapters

### 6.1 PostgreSQL Adapter (Future)

When implementing PostgreSQL support:

1. **ORM Choice:** Use Prisma or TypeORM for type safety
2. **Schema Migration:** Create equivalent SQL schemas
3. **Array Fields:** Use PostgreSQL arrays or junction tables
4. **JSON Fields:** Use JSONB columns for flexible data
5. **Full-Text Search:** Use PostgreSQL's built-in FTS or delegate to Meilisearch

### 6.2 SQL Schema Mapping (Example)

```sql
-- agents table (PostgreSQL)
CREATE TABLE agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50) DEFAULT 'offline',
    last_heartbeat TIMESTAMP,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- agent_service_types junction table (for array field)
CREATE TABLE agent_service_types (
    agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
    service_type VARCHAR(255) NOT NULL,
    PRIMARY KEY (agent_id, service_type)
);

-- agent_channels junction table (for array field)
CREATE TABLE agent_channels (
    agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
    channel_id UUID REFERENCES channels(id) ON DELETE CASCADE,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (agent_id, channel_id)
);
```

---

## 7. Testing Strategy

### 7.1 Repository Interface Tests

Create abstract test suites that can run against any implementation:

**File:** `tests/repositories/IAgentRepository.test.ts`

```typescript
import { IAgentRepository } from '../../src/shared/repositories/interfaces/IAgentRepository';

/**
 * Abstract test suite for IAgentRepository implementations.
 * Each database adapter runs these same tests.
 */
export function agentRepositoryTests(
    getRepository: () => IAgentRepository,
    cleanup: () => Promise<void>
) {
    describe('IAgentRepository', () => {
        let repository: IAgentRepository;

        beforeEach(async () => {
            repository = getRepository();
            await cleanup();
        });

        describe('findByAgentId', () => {
            it('should return null for non-existent agent', async () => {
                const result = await repository.findByAgentId('non-existent');
                expect(result).toBeNull();
            });

            it('should find agent by agentId', async () => {
                const created = await repository.create({
                    agentId: 'test-agent',
                    name: 'Test Agent',
                    status: 'online'
                });

                const found = await repository.findByAgentId('test-agent');
                expect(found).not.toBeNull();
                expect(found!.name).toBe('Test Agent');
            });
        });

        describe('addChannel / removeChannel', () => {
            it('should add channel without duplicates', async () => {
                await repository.create({
                    agentId: 'test-agent',
                    name: 'Test',
                    currentChannels: []
                });

                await repository.addChannel('test-agent', 'channel-1');
                await repository.addChannel('test-agent', 'channel-1'); // Duplicate

                const agent = await repository.findByAgentId('test-agent');
                expect(agent!.currentChannels).toHaveLength(1);
            });
        });

        // ... more tests
    });
}
```

### 7.2 Running Tests Against Multiple Databases

```typescript
// tests/repositories/mongo/MongoAgentRepository.test.ts
import { MongoAgentRepository } from '../../../src/shared/database/adapters/mongodb/MongoAgentRepository';
import { agentRepositoryTests } from '../IAgentRepository.test';
import { setupTestMongo, cleanupTestMongo } from '../../helpers/mongoTestHelper';

describe('MongoAgentRepository', () => {
    beforeAll(async () => {
        await setupTestMongo();
    });

    afterAll(async () => {
        await cleanupTestMongo();
    });

    agentRepositoryTests(
        () => new MongoAgentRepository(),
        async () => {
            const { Agent } = require('../../../src/shared/models/agent');
            await Agent.deleteMany({});
        }
    );
});
```

---

## 8. File Inventory

### 8.1 Files to Create (New)

| File | Purpose | Phase |
|------|---------|-------|
| `src/shared/repositories/interfaces/IBaseRepository.ts` | Base repository interface | 1 |
| `src/shared/repositories/interfaces/IAgentRepository.ts` | Agent repository interface | 1 |
| `src/shared/repositories/interfaces/IChannelRepository.ts` | Channel repository interface | 1 |
| `src/shared/repositories/interfaces/ITaskRepository.ts` | Task repository interface | 1 |
| `src/shared/repositories/interfaces/IMemoryRepository.ts` | Memory repository interface | 1 |
| `src/shared/repositories/interfaces/IUserRepository.ts` | User repository interface | 1 |
| `src/shared/repositories/interfaces/IToolRepository.ts` | Tool repository interface | 1 |
| `src/shared/repositories/interfaces/IAuditRepository.ts` | Audit repository interface | 1 |
| `src/shared/repositories/interfaces/IPatternRepository.ts` | Pattern repository interface | 1 |
| `src/shared/repositories/interfaces/IAnalyticsRepository.ts` | Analytics repository interface | 1 |
| `src/shared/repositories/types/FilterTypes.ts` | Filter type definitions | 1 |
| `src/shared/repositories/types/PaginationTypes.ts` | Pagination type definitions | 1 |
| `src/shared/repositories/types/QueryBuilder.ts` | Query builder interface | 4 |
| `src/shared/database/adapters/mongodb/MongoBaseRepository.ts` | Base MongoDB implementation | 2 |
| `src/shared/database/adapters/mongodb/MongoAgentRepository.ts` | MongoDB agent repository | 2 |
| `src/shared/database/adapters/mongodb/MongoChannelRepository.ts` | MongoDB channel repository | 2 |
| `src/shared/database/adapters/mongodb/MongoTaskRepository.ts` | MongoDB task repository | 2 |
| `src/shared/database/adapters/mongodb/MongoMemoryRepository.ts` | MongoDB memory repository | 2 |
| `src/shared/database/adapters/mongodb/MongoAnalyticsRepository.ts` | MongoDB analytics repository | 2 |
| `src/shared/database/DatabaseAdapterFactory.ts` | Factory for creating adapters | 2 |
| `tests/repositories/IAgentRepository.test.ts` | Abstract agent repo tests | 2 |
| `tests/repositories/IChannelRepository.test.ts` | Abstract channel repo tests | 2 |
| `tests/repositories/ITaskRepository.test.ts` | Abstract task repo tests | 2 |

### 8.2 Files to Modify (Existing)

| File | Changes | Phase |
|------|---------|-------|
| `src/server/index.ts` | Add DatabaseAdapterFactory initialization | 2 |
| `src/server/socket/services/AgentService.ts` | Use IAgentRepository | 3 |
| `src/server/socket/services/ChannelService.ts` | Use IChannelRepository | 3 |
| `src/server/socket/services/TaskService.ts` | Use ITaskRepository | 3 |
| `src/server/api/controllers/agentController.ts` | Use IAgentRepository | 3 |
| `src/server/api/controllers/channelController.ts` | Use IChannelRepository | 3 |
| `src/server/api/controllers/taskController.ts` | Use ITaskRepository | 3 |
| `src/server/api/routes/analytics.ts` | Use IAnalyticsRepository | 3 |
| `src/shared/services/PatternLearningService.ts` | Use IPatternRepository | 3 |
| `src/server/api/services/MemoryPersistenceService.ts` | Align with IMemoryRepository | 3 |

### 8.3 Files to Keep (Reference Only)

These files remain as MongoDB-specific implementations:

| File | Purpose |
|------|---------|
| `src/shared/models/agent.ts` | Mongoose schema (used by MongoDB adapter) |
| `src/shared/models/channel.ts` | Mongoose schema (used by MongoDB adapter) |
| `src/shared/models/task.ts` | Mongoose schema (used by MongoDB adapter) |
| `src/shared/models/memory.ts` | Mongoose schema (used by MongoDB adapter) |
| All other model files | Mongoose schemas (MongoDB adapter internal) |

---

## 9. Task Breakdown for Agents

### 9.1 Phase 1 Tasks (Repository Interfaces)

Each task should be completed as an independent unit. Tests should pass before moving to the next task.

#### Task 1.1: Create Base Types and Interfaces
**Files to create:**
- `src/shared/repositories/types/FilterTypes.ts`
- `src/shared/repositories/types/PaginationTypes.ts`
- `src/shared/repositories/interfaces/IBaseRepository.ts`
- `src/shared/repositories/interfaces/index.ts`

**Acceptance criteria:**
- All types compile without errors
- Types are exported from index.ts
- No dependencies on Mongoose or any database-specific code

#### Task 1.2: Create Agent Repository Interface
**Files to create:**
- `src/shared/repositories/interfaces/IAgentRepository.ts`

**Reference files:**
- `src/shared/models/agent.ts` - Review current schema
- `src/server/socket/services/AgentService.ts` - Review current usage patterns
- `src/shared/types/agentTypes.ts` - Use existing type definitions

**Acceptance criteria:**
- Interface extends IBaseRepository<IAgent>
- All operations from AgentService are represented
- No Mongoose-specific types in interface

#### Task 1.3: Create Channel Repository Interface
**Files to create:**
- `src/shared/repositories/interfaces/IChannelRepository.ts`

**Reference files:**
- `src/shared/models/channel.ts`
- `src/server/socket/services/ChannelService.ts`
- `src/shared/types/channelTypes.ts`

**Acceptance criteria:**
- Handles participant add/remove operations
- Supports channel search by name
- Includes statistics method

#### Task 1.4: Create Task Repository Interface
**Files to create:**
- `src/shared/repositories/interfaces/ITaskRepository.ts`

**Reference files:**
- `src/shared/models/task.ts`
- `src/server/socket/services/TaskService.ts`
- `src/shared/types/taskTypes.ts`

**Acceptance criteria:**
- Supports complex filtering (status, priority, date ranges)
- Includes overdue task detection
- Supports task hierarchy (subtasks)
- Includes search capability

#### Task 1.5: Create Memory Repository Interface
**Files to create:**
- `src/shared/repositories/interfaces/IMemoryRepository.ts`

**Reference files:**
- `src/shared/models/memory.ts`
- `src/server/api/services/MemoryPersistenceService.ts` - IMPORTANT: This file already has good patterns

**Acceptance criteria:**
- Handles all three memory scopes (agent, channel, relationship)
- Aligns with existing IMemoryPersistenceService interface
- Supports bulk operations

#### Task 1.6: Create Analytics Repository Interface
**Files to create:**
- `src/shared/repositories/interfaces/IAnalyticsRepository.ts`

**Reference files:**
- `src/server/api/routes/analytics.ts` - Review all aggregation pipelines

**Acceptance criteria:**
- All current analytics queries are representable
- Uses generic return types (not MongoDB-specific)
- Supports time range and granularity parameters

#### Task 1.7: Create Remaining Repository Interfaces
**Files to create:**
- `src/shared/repositories/interfaces/IUserRepository.ts`
- `src/shared/repositories/interfaces/IToolRepository.ts`
- `src/shared/repositories/interfaces/IAuditRepository.ts`
- `src/shared/repositories/interfaces/IPatternRepository.ts`

**Reference files:**
- `src/shared/models/user.ts`
- `src/shared/models/toolModels.ts`
- `src/shared/models/mcpTool.ts`
- `src/shared/models/auditLog.ts`
- `src/shared/models/PatternLearningModels.ts`

---

### 9.2 Phase 2 Tasks (MongoDB Adapters)

#### Task 2.1: Create MongoDB Base Repository
**Files to create:**
- `src/shared/database/adapters/mongodb/MongoBaseRepository.ts`

**Dependencies:**
- Phase 1 complete (all interfaces exist)

**Acceptance criteria:**
- Implements all IBaseRepository methods
- Translates FilterOptions to MongoDB queries
- Uses `.lean()` for performance
- Has `toEntity()` abstract method for subclasses

#### Task 2.2: Create MongoDB Agent Repository
**Files to create:**
- `src/shared/database/adapters/mongodb/MongoAgentRepository.ts`
- `tests/repositories/mongo/MongoAgentRepository.test.ts`

**Acceptance criteria:**
- Implements IAgentRepository fully
- All tests pass
- Handles array operations ($addToSet, $pull) correctly

#### Task 2.3: Create MongoDB Channel Repository
**Files to create:**
- `src/shared/database/adapters/mongodb/MongoChannelRepository.ts`
- `tests/repositories/mongo/MongoChannelRepository.test.ts`

**Acceptance criteria:**
- Implements IChannelRepository fully
- Participant operations work correctly
- Statistics method uses aggregation

#### Task 2.4: Create MongoDB Task Repository
**Files to create:**
- `src/shared/database/adapters/mongodb/MongoTaskRepository.ts`
- `tests/repositories/mongo/MongoTaskRepository.test.ts`

**Acceptance criteria:**
- Implements ITaskRepository fully
- Complex filters work correctly
- Search uses text index (if available)

#### Task 2.5: Create MongoDB Memory Repository
**Files to create:**
- `src/shared/database/adapters/mongodb/MongoMemoryRepository.ts`
- `tests/repositories/mongo/MongoMemoryRepository.test.ts`

**Acceptance criteria:**
- Implements IMemoryRepository fully
- Upsert operations work correctly
- All three memory scopes supported

#### Task 2.6: Create MongoDB Analytics Repository
**Files to create:**
- `src/shared/database/adapters/mongodb/MongoAnalyticsRepository.ts`
- `tests/repositories/mongo/MongoAnalyticsRepository.test.ts`

**Acceptance criteria:**
- All aggregation pipelines implemented
- Results match current analytics output
- Supports all time granularities

#### Task 2.7: Create Database Adapter Factory
**Files to create:**
- `src/shared/database/DatabaseAdapterFactory.ts`
- `src/shared/database/index.ts`

**Acceptance criteria:**
- Factory creates correct repositories for 'mongodb' type
- Throws clear errors for unimplemented types
- Singleton pattern for repository bundle

---

### 9.3 Phase 3 Tasks (Service Refactoring)

#### Task 3.1: Refactor AgentService
**Files to modify:**
- `src/server/socket/services/AgentService.ts`

**Changes required:**
1. Add repository property: `private agentRepository: IAgentRepository`
2. Initialize in constructor from factory
3. Replace all `Agent.findOne()` with `this.agentRepository.findByAgentId()`
4. Replace all `Agent.findOneAndUpdate()` with repository methods
5. Remove direct Mongoose import

**Acceptance criteria:**
- No direct Mongoose model imports
- All existing tests pass
- Behavior unchanged

#### Task 3.2: Refactor ChannelService
**Files to modify:**
- `src/server/socket/services/ChannelService.ts`

**Changes required:**
1. Add repository property
2. Replace `Channel.findOne()` calls
3. Replace `$addToSet`/`$pull` with `addParticipant()`/`removeParticipant()`
4. Remove direct Mongoose import

**Acceptance criteria:**
- No direct Mongoose model imports
- Participant operations still work correctly
- All existing tests pass

#### Task 3.3: Refactor TaskService
**Files to modify:**
- `src/server/socket/services/TaskService.ts`

**Changes required:**
1. Add repository property
2. Replace all Task model calls
3. Remove static method calls (Task.findByChannel, etc.)
4. Use repository filter methods instead

**Acceptance criteria:**
- No direct Mongoose model imports
- Task queries still return correct results
- All existing tests pass

#### Task 3.4: Refactor API Controllers
**Files to modify:**
- `src/server/api/controllers/agentController.ts`
- `src/server/api/controllers/channelController.ts`
- `src/server/api/controllers/taskController.ts`

**Changes required:**
1. Inject repositories via factory
2. Replace all direct model access
3. Update error handling for repository patterns

**Acceptance criteria:**
- API responses unchanged
- All endpoint tests pass

#### Task 3.5: Refactor Analytics Routes
**Files to modify:**
- `src/server/api/routes/analytics.ts`

**Changes required:**
1. Replace `db.collection().aggregate()` with IAnalyticsRepository methods
2. Remove direct MongoDB driver usage
3. Use repository methods for all data access

**Acceptance criteria:**
- Dashboard analytics still work
- All charts display correctly
- No direct MongoDB access

#### Task 3.6: Update Server Initialization
**Files to modify:**
- `src/server/index.ts`

**Changes required:**
1. Add DatabaseAdapterFactory.initialize() call
2. Add DB_TYPE environment variable support
3. Ensure initialization order is correct

**Acceptance criteria:**
- Server starts correctly
- Factory is initialized before services
- Existing functionality unchanged

---

### 9.4 Verification Tasks

#### Task V.1: Integration Test Suite
**Create comprehensive integration tests:**
- Test full request flow through repositories
- Verify data consistency
- Test error handling

#### Task V.2: Performance Benchmarks
**Create performance tests:**
- Compare repository performance to direct Mongoose
- Ensure no significant regression
- Document any optimizations needed

#### Task V.3: Documentation
**Update documentation:**
- Add database abstraction architecture docs
- Document how to implement new adapters
- Update CLAUDE.md with new patterns

---

## Appendix A: MongoDB-Specific Code Patterns to Replace

### A.1 Array Operations

**Current (MongoDB-specific):**
```typescript
await Channel.findOneAndUpdate(
    { channelId },
    { $addToSet: { participants: agentId } }
);
```

**Target (Repository):**
```typescript
await channelRepository.addParticipant(channelId, agentId);
```

### A.2 Complex Updates

**Current (MongoDB-specific):**
```typescript
await Agent.findOneAndUpdate(
    { agentId },
    {
        $set: { status: 'online', lastHeartbeat: new Date() },
        $addToSet: { currentChannels: channelId }
    }
);
```

**Target (Repository):**
```typescript
await agentRepository.updateStatus(agentId, 'online');
await agentRepository.addChannel(agentId, channelId);
```

### A.3 Aggregations

**Current (MongoDB-specific):**
```typescript
const result = await db.collection('tasks').aggregate([
    { $match: { status: 'completed' } },
    { $group: { _id: '$priority', count: { $sum: 1 } } }
]).toArray();
```

**Target (Repository):**
```typescript
const result = await analyticsRepository.getTaskStatusCounts();
```

---

## Appendix B: Environment Variables

Add these to your `.env` file:

```bash
# Database Configuration
DB_TYPE=mongodb                    # mongodb | postgresql | sqlite | mysql
MONGODB_URI=mongodb://localhost:27017/mxf

# Future PostgreSQL support
# DB_TYPE=postgresql
# POSTGRES_URI=postgresql://user:pass@localhost:5432/mxf

# Future SQLite support
# DB_TYPE=sqlite
# SQLITE_PATH=./data/mxf.db
```

---

## Appendix C: Success Metrics

| Metric | Target | How to Measure |
|--------|--------|----------------|
| No direct Mongoose imports in services | 0 imports | grep for 'from.*models' in services |
| Repository interface coverage | 100% | All service operations have repository methods |
| Test coverage | >80% | Jest coverage report |
| Performance regression | <5% | Benchmark before/after |
| New adapter implementation time | <2 weeks | Time to implement PostgreSQL adapter |

---

*End of Implementation Plan*
