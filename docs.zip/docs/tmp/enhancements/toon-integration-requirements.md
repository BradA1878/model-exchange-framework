# TOON Integration for MXF

**Version:** 1.0.0  
**Author:** Brad Anderson  
**Date:** December 2024  
**Status:** Proposed

---

## Executive Summary

This document specifies the integration of TOON (Token-Oriented Object Notation) into the Model Exchange Framework (MXF) as an automatic prompt optimization layer. TOON reduces token consumption by 30-60% for uniform array data while improving LLM parsing accuracy. The integration is transparent to agents—they continue emitting standard JSON while the server handles format selection and encoding.

---

## 1. Problem Statement

MXF agents communicate via tool calls over Socket.IO. When Agent A sends a message to Agent B, the payload travels as JSON through the server, then gets injected into Agent B's prompt context. This injection point is where tokens are consumed.

Current inefficiencies:

- Repeated keys in arrays of objects (e.g., batch results, status lists, memory retrievals)
- Verbose JSON syntax for tabular data that LLMs must parse
- No structural metadata to help LLMs validate array lengths or field consistency

TOON addresses these issues for data structures where it provides measurable benefit.

---

## 2. Integration Points

### 2.1 Agent-to-Agent Messaging (Primary)

**Flow:**
```
Agent A ──[tool_call/JSON]──► MXF Server ──[evaluate]──► TOON/JSON ──[prompt injection]──► Agent B
```

**Trigger:** Any `messaging_send` tool call or equivalent message dispatch.

**Location:** Message delivery pipeline in Socket.IO handler, before prompt assembly.

### 2.2 SystemLLM Context Injection (Secondary)

**Flow:**
```
ORPAR Cycle ──[gather context]──► SystemLlmService ──[encode if eligible]──► LLM Provider
```

**Applicable contexts:**
- Agent pool status arrays
- Pending task queues
- Observation batches
- Workload analysis data

### 2.3 Memory Retrieval Injection (Secondary)

**Flow:**
```
memory_search_* ──[results]──► Prompt Builder ──[encode if eligible]──► Agent Context
```

**Applicable data:**
- Conversation search results
- Action/pattern search results
- Any retrieved memory batch injected as context

---

## 3. Functional Requirements

### 3.1 Eligibility Evaluation

**FR-1:** The system SHALL evaluate each payload for TOON eligibility before encoding.

**FR-2:** Eligibility criteria:
- Payload contains at least one array with 5+ elements
- Array elements are objects with identical keys (field order may vary)
- All values are primitives (string, number, boolean, null)
- Calculated tabular eligibility score ≥ 0.8 (80%)

**FR-3:** Payloads failing eligibility SHALL remain as JSON (compact, single-line).

**FR-4:** Eligibility evaluation SHALL complete in < 5ms for payloads under 100KB.

### 3.2 Encoding

**FR-5:** Eligible payloads SHALL be encoded using `@toon-format/toon` library.

**FR-6:** Encoded output SHALL use fenced code blocks with format label:
```
```toon
users[3]{id,name,status}:
  1,Alice,active
  2,Bob,idle
  3,Carol,active
```
```

**FR-7:** The system SHALL support configurable delimiters (comma default, tab optional).

**FR-8:** Mixed payloads (some arrays eligible, some not) SHALL encode eligible portions as TOON and remainder as JSON, clearly delineated.

### 3.3 Transparency

**FR-9:** Sending agents SHALL NOT require modification—they emit standard JSON via tool calls.

**FR-10:** Receiving agents SHALL NOT require modification—they receive formatted prompt content.

**FR-11:** The optimization layer SHALL be invisible to agent logic.

### 3.4 Configuration

**FR-12:** TOON optimization SHALL be globally toggleable via environment variable:
```
TOON_OPTIMIZATION_ENABLED=true
```

**FR-13:** TOON optimization SHALL be configurable per-channel:
```typescript
channel.settings.toonOptimization: 'auto' | 'always' | 'never'
```

**FR-14:** Minimum array length threshold SHALL be configurable (default: 5).

**FR-15:** Eligibility score threshold SHALL be configurable (default: 0.8).

### 3.5 Metrics & Observability

**FR-16:** The system SHALL track per-message:
- Original payload size (bytes)
- Encoded payload size (bytes)
- Format selected (TOON/JSON)
- Eligibility score
- Encoding latency

**FR-17:** The system SHALL aggregate:
- Total tokens saved per channel (estimated)
- TOON selection rate by message type
- Average eligibility scores

**FR-18:** Metrics SHALL be exposed via existing MXF analytics infrastructure.

---

## 4. Technical Requirements

### 4.1 Dependencies

**TR-1:** Add `@toon-format/toon` package (MIT license, TypeScript native).

**TR-2:** No additional runtime dependencies required.

### 4.2 Module Structure

**TR-3:** Create new module at `src/shared/utils/toon/`:
```
toon/
├── index.ts              # Public exports
├── eligibility.ts        # Eligibility evaluation logic
├── encoder.ts            # TOON encoding wrapper
├── formatter.ts          # Prompt formatting (code blocks)
├── metrics.ts            # Metrics collection
└── types.ts              # TypeScript interfaces
```

### 4.3 Integration Points

**TR-4:** Hook into `src/server/socket/` message delivery pipeline.

**TR-5:** Hook into `src/server/services/SystemLlmService.ts` context assembly.

**TR-6:** Hook into memory search result formatting (if applicable).

### 4.4 Performance

**TR-7:** Eligibility check: < 5ms for payloads under 100KB.

**TR-8:** Encoding: < 20ms for payloads under 100KB.

**TR-9:** Total added latency: < 25ms per message.

**TR-10:** Memory overhead: Negligible (encode is stateless).

### 4.5 Error Handling

**TR-11:** Encoding failures SHALL fall back to JSON silently.

**TR-12:** Encoding failures SHALL be logged at WARN level.

**TR-13:** Eligibility evaluation failures SHALL default to JSON.

---

## 5. Interface Specifications

### 5.1 Eligibility Evaluator

```typescript
interface EligibilityResult {
  eligible: boolean;
  score: number;              // 0.0 - 1.0
  reason?: string;            // If not eligible, why
  eligiblePaths?: string[];   // JSON paths of eligible arrays
}

interface EligibilityOptions {
  minArrayLength?: number;    // Default: 5
  minScore?: number;          // Default: 0.8
}

function evaluateEligibility(
  payload: unknown, 
  options?: EligibilityOptions
): EligibilityResult;
```

### 5.2 Encoder

```typescript
interface EncodeOptions {
  delimiter?: ',' | '\t' | '|';  // Default: ','
  indent?: number;                // Default: 2
  wrapInCodeBlock?: boolean;      // Default: true
}

interface EncodeResult {
  output: string;
  format: 'toon' | 'json';
  originalBytes: number;
  encodedBytes: number;
  estimatedTokenSavings: number;
}

function encodeForPrompt(
  payload: unknown, 
  options?: EncodeOptions
): EncodeResult;
```

### 5.3 Message Formatter

```typescript
interface FormatOptions {
  toonEnabled?: boolean;
  eligibilityOptions?: EligibilityOptions;
  encodeOptions?: EncodeOptions;
}

function formatMessagePayload(
  payload: unknown,
  options?: FormatOptions
): string;
```

---

## 6. System Prompt Convention

### 6.1 Agent System Prompt Addition

When TOON optimization is enabled, agent system prompts SHALL include:

```
## Data Formats

Structured data in this conversation may appear in two formats:

1. **TOON** (Token-Oriented Object Notation) - Used for tabular data (arrays of uniform objects):
   ```toon
   items[3]{id,name,value}:
     1,Alpha,100
     2,Beta,200
     3,Gamma,300
   ```
   - `[N]` indicates array length
   - `{fields}` declares column names
   - Rows contain comma-separated values

2. **JSON** - Used for nested or non-uniform structures:
   ```json
   {"config": {"nested": {"value": true}}}
   ```

Both formats represent the same data. Parse them equivalently.
```

### 6.2 Placement

This convention SHALL be injected into agent system prompts when:
- TOON optimization is enabled globally, AND
- Channel settings allow TOON (`auto` or `always`)

---

## 7. Test Requirements

### 7.1 Unit Tests

- Eligibility evaluation with various payload shapes
- Encoding correctness vs. reference implementation
- Edge cases: empty arrays, single-element arrays, mixed types
- Performance benchmarks for eligibility and encoding

### 7.2 Integration Tests

- End-to-end message flow: Agent A → Server → Agent B
- TOON-enabled vs. disabled comparison
- Mixed payload handling
- Fallback behavior on encoding failure

### 7.3 Metrics Tests

- Verify metrics collection accuracy
- Verify aggregation correctness

---

## 8. Rollout Plan

### Phase 1: Core Implementation
- Implement eligibility evaluator
- Implement encoder wrapper
- Add unit tests
- Add configuration options

### Phase 2: Message Pipeline Integration
- Hook into Socket.IO message delivery
- Add system prompt convention injection
- Integration tests

### Phase 3: Secondary Integration Points
- SystemLLM context injection
- Memory retrieval formatting
- Additional integration tests

### Phase 4: Observability
- Metrics collection
- Dashboard integration (if applicable)
- Documentation

---

## 9. Success Criteria

- **Token Reduction:** ≥ 30% reduction on eligible payloads (measured via tokenizer)
- **Latency:** < 25ms added latency per message
- **Reliability:** Zero encoding failures causing message delivery failures
- **Transparency:** No agent code changes required

---

## 10. Open Questions

1. **Tab vs. Comma Delimiter:** Should we default to tab for better tokenization, or stick with comma for readability during debugging?

2. **Metrics Granularity:** Per-message metrics vs. aggregated only? Storage implications for high-volume systems.

3. **LLM Comprehension Testing:** Should we run accuracy benchmarks similar to TOON's published results against MXF-specific payload shapes?

---

## 11. References

- [TOON Specification](https://github.com/toon-format/spec)
- [TOON TypeScript SDK](https://github.com/toon-format/toon)
- [MXF Architecture Documentation](https://github.com/BradA1878/model-exchange-framework/blob/main/docs/index.md)
- [MXP Protocol Documentation](https://github.com/BradA1878/model-exchange-framework/blob/main/docs/mxp-migration-guide.md)
