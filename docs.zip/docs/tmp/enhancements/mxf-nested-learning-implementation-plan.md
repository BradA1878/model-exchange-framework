# MXF Nested Learning Integration Plan

## Implementing Multi-Timescale Memory in the ORPAR Control Loop

**Author:** Brad Anderson  
**Version:** 1.0  
**Date:** December 2025  
**Status:** Draft Proposal

---

## Executive Summary

This document outlines a plan to integrate concepts from Google's Nested Learning paradigm, Titans architecture, MIRAS framework, and Agent0-VL's Self-Evolving Agent into the Model Exchange Framework (MXF). The primary goal is to enhance the ORPAR control loop with multi-timescale memory management and self-evolving reasoning capabilities, enabling agents to learn continuously without catastrophic forgetting, verify their own reasoning through tool-grounded analysis, and self-correct when verification identifies issues.

The integration preserves MXF's existing architecture while adding a Continuum Memory System (CMS) layer that treats memory as a spectrum of modules updating at different frequencies—mirroring how the human brain consolidates short-term experiences into long-term knowledge. The MIRAS framework provides formal design choices (architecture, attentional bias, retention gate, memory algorithm) that allow each memory stratum to be configured optimally for its purpose.

A key addition is the **Self-Evolving Reasoning Cycle (SERC)**, which formalizes the ORPAR loop as a dual-loop structure: an inner loop handling per-cycle execution with integrated verification and self-repair, and an outer loop managing cross-cycle memory consolidation with SystemLLM acting as the system-level optimizer. Agents can now switch between Solver mode (standard ORPAR) and Verifier mode (introspective tool-grounded evaluation), enabling genuine self-correction rather than passive reflection.

**Timeline:** 28 weeks across 10 phases, from foundation through optimization.

---

## 1. Background and Motivation

### 1.1 Current MXF Memory Architecture

MXF currently implements multi-scope memory across three dimensions:

- **Agent-private memory** — Individual agent preferences and state
- **Channel-shared memory** — Collaborative context within a channel
- **Relationship memory** — Inter-agent interaction patterns

This spatial organization is effective for multi-agent coordination but lacks **temporal stratification**. All memories within a scope are treated with equal persistence, leading to:

- Context windows that grow unbounded or get truncated arbitrarily
- No principled mechanism for knowledge consolidation
- Inability to distinguish ephemeral tactical information from stable strategic knowledge
- Reflection outcomes stored without consideration of their long-term relevance

### 1.2 Nested Learning, Titans, MIRAS, and Agent0-VL Core Insights

Google's research and recent agentic AI work introduce several concepts directly applicable to MXF:

**From Nested Learning:**
1. **Multi-timescale updates** — Different model components update at different frequencies, from near-instantaneous to very slow
2. **Surprise-based encoding** — Unexpected events receive stronger memory encoding (Titans architecture)
3. **Optimizer as memory** — The training process itself functions as associative memory
4. **Continuum Memory System** — Memory exists as a spectrum, not a binary short-term/long-term split

**From Titans:**
5. **Gradient-based surprise** — Surprise is the prediction error: the difference between what memory expects and what actually arrives
6. **Momentum for surprise** — Both "momentary surprise" (current input) and "past surprise" (recent context) are considered, ensuring related follow-up information is captured
7. **Adaptive weight decay** — Forgetting is managed through adaptive decay that acts as a gate, discarding information no longer needed while preserving essential knowledge

**From MIRAS Framework:**
8. **Four design choices** — Memory systems are characterized by: architecture (what stores info), attentional bias (what to prioritize), retention gate (how to forget), and memory algorithm (how to update)
9. **Beyond MSE** — Alternative loss functions (YAAD/Huber, MONETA, MEMORA) provide robustness to outliers and more stable memory updates
10. **Deep memory architecture** — Deeper memory modules (MLPs vs. vectors) provide significantly higher expressive power for long-term storage

**From Agent0-VL:**
11. **Unified dual-role architecture** — A single model alternates between Solver (reasoning/action) and Verifier (evaluation) modes
12. **Tool-grounded verification** — Verification uses external tools to cross-check reasoning, not just text-based reflection
13. **Confidence-gated self-repair** — When confidence falls below threshold, generate a PATCH and re-execute
14. **Self-Evolving Reasoning Cycle (SERC)** — Inner loop handles per-task execution, outer loop updates policy via accumulated experience
15. **Process-level rewards** — Reward combines tool verification, confidence, and repair costs for balanced learning

### 1.3 Strategic Alignment

Integrating Nested Learning and SERC concepts supports MXF's evolution toward:

- True continual learning agents that improve over extended deployments
- More efficient context management (reduced token usage through intelligent summarization)
- Emergent multi-agent intelligence through cross-agent pattern consolidation
- Enterprise deployments where agents must maintain institutional knowledge
- **Self-correcting agents** that verify their own reasoning through tool-grounded analysis
- **Adaptive reasoning depth** where surprise signals modulate how deeply agents think
- **SystemLLM as outer optimizer** coordinating cross-agent learning and strategic memory

---

## 2. Technical Architecture

### 2.1 Conceptual Model: Memory Strata

The core addition is a **stratum-based memory model** layered over existing MXF memory scopes. Each stratum operates at a distinct temporal frequency:

| Stratum | Update Frequency | Persistence | Compression | Purpose |
|---------|------------------|-------------|-------------|---------|
| **Immediate** | Every cycle | Ephemeral | None | Current context, working memory |
| **Tactical** | Every 3-5 cycles | Session | Light summarization | Recent patterns, active task context |
| **Operational** | Every 10-20 cycles | Extended session | Moderate summarization | Cross-task patterns, learned procedures |
| **Strategic** | Every 50+ cycles | Persistent | Heavy (embeddings) | Stable knowledge, domain expertise |

### 2.2 ORPAR Phase Enhancements

#### 2.2.1 Observation Phase

**Current:** Gathers environmental context and incoming messages

**Enhanced:** Assembles a **nested observation** that includes:

- Immediate context (unchanged)
- Relevant tactical memories based on current task type
- Applicable strategic knowledge based on domain detection
- A computed **surprise signal** indicating how unexpected the current input is relative to agent's accumulated experience

The surprise signal becomes a key control variable that influences all subsequent phases.

#### 2.2.2 Reasoning Phase

**Current:** LLM-powered analysis and decision making

**Enhanced:** Reasoning receives the nested observation and:

- Uses surprise signal to modulate reasoning depth (high surprise → more deliberative)
- Can query specific memory strata for relevant precedents
- Generates a **memory relevance assessment** indicating which strata were most useful

This enables adaptive compute—simple familiar situations resolved quickly, novel situations receive deeper analysis.

#### 2.2.3 Planning Phase

**Current:** Goal decomposition and workflow creation

**Enhanced:** Plans become **nested plans** with goals at multiple temporal scales:

- Strategic goals (slow-changing, high-level objectives)
- Operational objectives (session-level milestones)
- Tactical tasks (immediate action sequences)

The planner can recognize when tactical execution has drifted from strategic intent and flag for reflection.

#### 2.2.4 Action Phase

**Current:** Strategic action execution with dependency tracking

**Enhanced:** Actions are tagged with expected outcomes to enable surprise calculation post-execution. The action execution includes:

- Predicted outcome distribution
- Confidence level
- Stratum source (which memory level informed this action)

#### 2.2.5 Reflection Phase

**Current:** Analytical review of completed actions

**Enhanced:** Reflection becomes the **CMS update engine**:

1. Calculate actual vs. predicted outcome (surprise magnitude)
2. Determine which strata to update based on surprise threshold
3. Apply appropriate compression for target stratum
4. Update stratum with new memory
5. Apply decay to existing memories in all strata
6. Emit events for cross-agent pattern sharing (if applicable)

### 2.3 Surprise Calculation

The surprise signal is central to the Nested Learning integration. Google's Titans architecture provides a concrete definition: surprise is the **gradient magnitude** — the difference between what the memory expects versus what the input actually provides.

**Core Principle:**
- **Low surprise:** If the agent's memory state already anticipates the type of input received, the gradient is low. The memory can safely skip deep encoding.
- **High surprise:** If the input contradicts or significantly deviates from the memory's expectations, the gradient is high. This signals important or anomalous information that must be prioritized for longer-term storage.

**Calculation Approaches (to be evaluated):**

**Option A: Embedding Distance**
Compare the embedding of current observation against the centroid of recent observations. Large distances indicate surprise. Simple and fast, but semantically shallow.

**Option B: Prediction Error (Gradient-Based)**
If the agent made predictions in the previous cycle, measure divergence between predicted and actual outcomes. This aligns most closely with Titans' approach where surprise equals the model's internal error signal.

**Option C: LLM-Assessed Novelty**
Include a lightweight LLM call in observation that rates novelty on a scale. More expensive but more semantically meaningful.

**Option D: Hybrid**
Fast embedding-based pre-filter, escalate to LLM assessment only when embedding distance exceeds threshold.

**Recommendation:** Start with Option B (prediction error) for v1 as it aligns with Titans research, with Option A as a fast fallback when no predictions exist.

**Momentum for Surprise**

A critical addition from the Titans research: surprise should incorporate **momentum** to capture contextually related information that follows a surprising event.

- **Momentary surprise:** The current input's deviation from expectations
- **Past surprise:** Accumulated surprise from recent context flow

This ensures that if a surprising event occurs, the subsequent related information is also captured even if those individual inputs aren't independently surprising. For example, if an agent receives an unexpected error, the follow-up diagnostic messages should also be promoted to slower strata even though they may be "expected" given the error.

**Momentum Implementation Considerations:**
- Maintain a rolling surprise accumulator with configurable decay
- When momentary surprise exceeds threshold, boost the accumulator
- Accumulator value adds to effective surprise of subsequent observations
- Decay the accumulator each cycle to eventually return to baseline

### 2.4 Retention Gate (Memory Decay)

The MIRAS framework reinterprets "forgetting mechanisms" as **retention gates** — a form of regularization that balances new learning against retaining past knowledge. This is more than simple time-based decay; it's an adaptive system that manages finite memory capacity.

**Adaptive Weight Decay**

Following the Titans approach, each stratum employs adaptive weight decay that acts as a forgetting gate, allowing the system to discard information that is no longer needed while preserving essential knowledge.

| Stratum | Base Decay Rate | Adaptation Trigger |
|---------|-----------------|-------------------|
| **Immediate** | 0.8 per cycle | Fixed — always aggressive |
| **Tactical** | 0.3 per cycle | Increases when capacity exceeded |
| **Operational** | 0.1 per cycle | Decreases for high-access memories |
| **Strategic** | 0.05 per cycle | Capacity-limited, oldest-first eviction |

**Retention Gate Behavior:**

1. **Capacity Management:** When a stratum approaches capacity, decay rate increases to make room for new memories
2. **Access-Based Reinforcement:** Memories that are accessed or referenced have their relevance boosted, implementing spaced repetition
3. **Surprise-Weighted Retention:** Higher initial surprise scores grant stronger retention (slower decay)
4. **Cross-Reference Preservation:** Memories linked to other memories decay more slowly

**Regularization Framing:**

The retention gate can be understood as a regularizer that prevents the memory system from either:
- **Overfitting to recent data** (forgetting everything old)
- **Underfitting to new data** (refusing to update despite new information)

This balance is controlled by a retention strength parameter per stratum that can be tuned based on domain characteristics.

### 2.5 Cross-Agent Pattern Consolidation

The SystemLLM's role expands to function as the **system-level slow optimizer**:

- Observes patterns emerging across multiple agents
- Identifies successful strategies that should propagate
- Updates channel-level strategic memory based on collective learning
- Can adjust individual agent memory configurations based on observed needs

This mirrors the Nested Learning concept of having outer optimization loops that update more slowly but influence the entire system.

### 2.6 MIRAS Design Framework

The MIRAS (Memory, Iteration, Retention, Attention, State) framework from Google Research provides a formal structure for designing memory systems. It defines four key design choices that together determine memory behavior:

#### 2.6.1 Memory Architecture

The structure that stores information. Options range from simple to complex:

| Architecture | Capacity | Speed | Use Case |
|--------------|----------|-------|----------|
| Vector | Low | Fast | Simple state tracking |
| Matrix | Medium | Medium | Relational patterns |
| Deep MLP | High | Slower | Complex knowledge |

**MXF Recommendation:** Use matrix storage for Tactical/Operational strata, consider deep MLP for Strategic stratum where expressive power matters more than speed.

#### 2.6.2 Attentional Bias

The internal learning objective that determines what the memory prioritizes. Standard approaches use mean squared error (MSE) or dot-product similarity, but these can be sensitive to outliers.

**MIRAS Variants for Consideration:**

- **Standard (MSE):** Default approach, works well for clean data
- **YAAD (Huber Loss):** More robust to outliers; doesn't overreact to one-off anomalies. *Recommended for noisy multi-agent channels where message errors or malformed data may occur.*
- **MONETA (Generalized Norms):** Stricter mathematical penalties for more disciplined memory updates. *Consider for high-reliability enterprise deployments.*
- **MEMORA (Probability Map):** Forces memory updates to be controlled and balanced. *Best for scenarios requiring auditability and predictable behavior.*

**MXF Recommendation:** Start with standard MSE, evaluate YAAD for production deployments with unreliable agents or noisy channels.

#### 2.6.3 Retention Gate

The memory regularizer (see Section 2.4). MIRAS formalizes this as the mechanism that balances new learning against retaining past knowledge.

#### 2.6.4 Memory Algorithm

The optimization algorithm used to update memory. Options include:

- **SGD:** Simple, predictable updates
- **Momentum-based:** Smoother updates that consider recent history
- **Adaptive (Adam-style):** Per-parameter learning rates

**MXF Recommendation:** Use momentum-based updates to align with surprise momentum tracking. This creates consistency between how surprise is calculated and how memory is updated.

#### 2.6.5 MIRAS Configuration per Stratum

Different strata may benefit from different MIRAS configurations:

| Stratum | Architecture | Bias | Retention | Algorithm |
|---------|--------------|------|-----------|-----------|
| Immediate | Vector | MSE | Aggressive | SGD |
| Tactical | Matrix | MSE/YAAD | Moderate | Momentum |
| Operational | Matrix | YAAD | Conservative | Momentum |
| Strategic | Deep MLP | MEMORA | Minimal | Adam |

### 2.7 Self-Evolving Reasoning Cycle (SERC)

Inspired by Agent0-VL's architecture, we formalize the MXF control loop as a **Self-Evolving Reasoning Cycle** — a dual-loop structure where agents not only reason and act, but also verify, critique, and repair their own reasoning through tool-grounded analysis.

#### 2.7.1 Dual-Role Architecture

Each MXF agent operates with a unified policy that can switch between two internal modes:

**Solver Mode (m = S):** The agent performs standard ORPAR execution — Observation, Reasoning, Planning, Action. The agent invokes tools as needed for task completion.

**Verifier Mode (m = V):** The agent switches to introspective evaluation mode, validating its own reasoning trajectory through structured critique and tool-based verification.

The role indicator `m` determines which mode is active:

```
πθ(at|st, m) = {
    πS(at|st),              when m = Solver
    πV(at|st, at, ot),      when m = Verifier
}
```

This means the Reflection phase in ORPAR becomes a full Verifier invocation, not merely passive review.

#### 2.7.2 Inner Loop: Per-Cycle Execution

The inner loop handles individual ORPAR cycles with integrated verification:

1. **Observation** — Assemble nested context from memory strata, compute surprise signal
2. **Reasoning** — LLM-powered analysis, modulated by surprise (high surprise = deeper reasoning)
3. **Planning** — Generate nested plan with predicted outcomes
4. **Action** — Execute plan, invoke tools, record actual outcomes
5. **Reflection (Verifier Mode)** — Switch to Verifier mode:
   - Generate structured feedback tuple: `Vt = (scoret, conft, critiquet)`
   - Optionally invoke tools to cross-check reasoning
   - Compute promotion score for memory stratification
   - If confidence below threshold, trigger Self-Repair

#### 2.7.3 Outer Loop: Cross-Cycle Consolidation

The outer loop operates across multiple ORPAR cycles:

- **Memory Consolidation** — Promote high-surprise, high-value memories to slower strata
- **Pattern Recognition** — SystemLLM identifies recurring patterns across agents
- **Strategic Updates** — Update Operational and Strategic strata based on accumulated evidence
- **Policy Refinement** — Adjust agent behavior based on reflection outcomes

This maps to Nested Learning's multi-timescale updates: the inner loop operates at immediate/tactical timescales, while the outer loop handles operational/strategic timescales.

#### 2.7.4 SystemLLM as Outer Optimizer

The SystemLLM extends its current role (server-side reasoning, topic extraction, summaries) to function as the **system-level Verifier and optimizer**:

- **Cross-Agent Verification** — Validate reasoning patterns across multiple agents
- **Tool-Grounded Analysis** — Use MongoDB Lens, search tools, and other MCP servers to verify claims
- **Strategic Memory Updates** — Consolidate successful patterns into channel-level strategic memory
- **Agent Configuration Tuning** — Adjust per-agent MIRAS configurations based on observed performance

### 2.8 Tool-Grounded Verification

A key insight from Agent0-VL: verification should not be purely text-based. The Verifier (whether agent-level or SystemLLM) can invoke external tools to obtain factual evidence for evaluation.

#### 2.8.1 Verification Tuple

During Reflection, the Verifier produces a structured feedback tuple for each reasoning step:

```
Vt = (scoret, conft, critiquet)
```

Where:
- **scoret ∈ [-1, 1]** — Factual correctness assessment
- **conft ∈ [0, 1]** — Epistemic certainty (how confident is the Verifier in its assessment)
- **critiquet** — Natural language reflection describing potential reasoning flaws

#### 2.8.2 Tool Invocation for Verification

The Verifier can invoke MXF's 81+ built-in tools and MCP servers to cross-check reasoning:

| Tool Category | Verification Use Case |
|---------------|----------------------|
| Calculation tools | Verify mathematical reasoning steps |
| Search tools | Fact-check claims against external sources |
| MongoDB Lens | Validate against historical data and patterns |
| Code execution | Re-run computations to verify results |
| Other agents | Cross-validate reasoning with specialist agents |

By combining language-based reflection with executable tool-derived evidence, verification becomes a dynamic evaluation procedure rather than a static correctness check.

#### 2.8.3 Confidence + Surprise Matrix

Confidence and Surprise together provide a richer signal for memory promotion and repair decisions:

| Surprise | Confidence | Interpretation | Memory Action |
|----------|------------|----------------|---------------|
| High | Low | Unexpected AND uncertain | Promote + Trigger Repair |
| High | High | Unexpected but understood | Promote (novel insight) |
| Low | Low | Expected but uncertain | Stay immediate, maybe repair |
| Low | High | Routine, well-understood | Immediate only, fast decay |

### 2.9 Self-Repair Protocol

When the Verifier identifies issues in reasoning (low confidence or failed tool verification), the agent can trigger self-repair rather than simply logging the failure.

#### 2.9.1 Repair Gate

The repair gate determines when self-repair is triggered:

```
gt = σ(κ(τc − conft))
```

Where:
- **τc** — Confidence threshold (default: 0.7)
- **κ** — Gating temperature (controls sharpness of the decision boundary)
- **σ** — Sigmoid function

When `gt` is activated (confidence below threshold), the Verifier issues a repair instruction.

#### 2.9.2 PATCH Instruction Format

The Self-Repair module generates a structured correction:

```json
{
  "action": "PATCH",
  "target_step": 3,
  "patch_type": "reasoning | tool_call | parameter",
  "new_content": "<corrected reasoning or tool invocation>",
  "justification": "<2 sentences referencing critique/evidence>"
}
```

Or, if repair is not warranted:

```json
{
  "action": "NO_CHANGE",
  "target_step": 3,
  "reason": "<why repair is not warranted or evidence is insufficient>"
}
```

#### 2.9.3 Re-Execution Flow

When a PATCH is issued:

1. Inject the PATCH into the agent's context
2. Re-invoke Planning phase with corrected premise
3. Execute corrected Action
4. Re-run Reflection to verify the repair succeeded
5. Track repair cost for reward calculation

#### 2.9.4 Repair Cost Tracking

Self-repair is valuable but not free. The step-wise reward includes a repair penalty:

```
rt = r(t)proc − gt · C(t)repair
```

This discourages unnecessary repairs while still allowing correction when needed. Repair costs are tracked in MXP analytics.

### 2.10 Process-Level Reward Function

Combining insights from Titans (surprise), MIRAS (retention), and Agent0-VL (verification), we define a unified promotion/reward score:

```
promotionScore(t) = αsurprise · (momentarySurpriset + momentumAccumulatort)
                  + αconf · conft
                  + αtool · toolVerificationScoret
                  − βrepair · repairCostt
                  − βdiv · DKL(πV || πref)
```

Where:
- **Surprise terms** — From Titans, including momentum for contextual continuity
- **Confidence** — From Verifier assessment
- **Tool verification** — Bonus for tool-grounded confirmation
- **Repair cost** — Penalty for triggering self-repair
- **KL divergence** — Regularization to prevent drift from reference behavior

This score determines:
1. Whether to promote memories to slower strata
2. How to weight experiences for learning
3. When to trigger self-repair

---

## 3. Component Impact Analysis

### 3.1 New Components

| Component | Description | Complexity |
|-----------|-------------|------------|
| **StratumManager** | Manages the lifecycle of memory strata, handles updates and decay | Medium |
| **SurpriseCalculator** | Computes surprise signals using gradient-based prediction error | Medium |
| **SurpriseMomentumTracker** | Maintains rolling surprise accumulator for context continuity | Low-Medium |
| **MemoryCompressor** | Summarizes/compresses memories for slower strata | Medium-High |
| **NestedObservationBuilder** | Assembles multi-stratum context for reasoning | Medium |
| **RetentionGateService** | Manages adaptive weight decay and capacity-based eviction | Medium |
| **AttentionalBiasProvider** | Implements MSE/YAAD/MONETA/MEMORA bias strategies | Medium |
| **MIRASConfigManager** | Per-stratum MIRAS configuration (architecture, bias, retention, algorithm) | Low-Medium |
| **VerifierModeHandler** | Enables agent role-switching between Solver and Verifier modes | Medium |
| **ToolGroundedVerifier** | Orchestrates tool invocation during Reflection for verification | Medium-High |
| **ConfidenceCalculator** | Computes epistemic certainty scores for verification tuples | Medium |
| **SelfRepairEngine** | Generates PATCH instructions and manages re-execution flow | High |
| **RepairCostTracker** | Tracks repair costs for reward calculation and analytics | Low |
| **SERCOrchestrator** | Coordinates inner/outer loop execution and role transitions | High |
| **ProcessRewardCalculator** | Computes unified promotion/reward scores from all signals | Medium |

### 3.2 Modified Components

| Component | Modification | Impact |
|-----------|--------------|--------|
| **MxfMemoryManager** | Add stratum support, modify storage/retrieval interfaces | High |
| **MxfSystemPromptManager** | Include stratum context in prompt generation | Medium |
| **ReflectionService** | Integrate CMS update logic | High |
| **MxfEventHandlerService** | Handle new stratum-related events | Low |
| **ControlLoopTypes** | Extend Observation, Plan, Reflection types | Medium |
| **EventNames** | Add memory stratum events | Low |

### 3.3 Database Schema Changes

New collections/documents needed:

- **memory_strata** — Stores stratified memories with metadata (stratum, relevance, timestamp, compression level)
- **surprise_history** — Tracks surprise signals over time for analysis
- **decay_schedule** — Configuration for decay rates per agent/channel

### 3.4 MXP 2.0 Integration

The MXP protocol's context compression capabilities align well with stratum compression. Consider:

- Using MXP summarization for tactical → operational promotion
- Tracking token savings per stratum level
- Reporting stratum efficiency in MXP analytics

---

## 4. Project Plan

### 4.1 Phase 1: Foundation (Weeks 1-2)

**Objective:** Establish core infrastructure without disrupting existing functionality

**Deliverables:**
- StratumManager interface and basic implementation
- Memory stratum schema and MongoDB integration
- Configuration system for stratum parameters
- Unit tests for stratum CRUD operations

**Success Criteria:**
- Can create, read, update, delete memories in specific strata
- Existing MxfMemoryManager continues to function unchanged
- Configuration can be set per-agent and per-channel

### 4.2 Phase 2: Surprise Signal (Weeks 3-4)

**Objective:** Implement surprise calculation with momentum and integrate into Observation phase

**Deliverables:**
- SurpriseCalculator with gradient-based prediction error approach
- **SurpriseMomentumTracker** foundation (accumulator with configurable decay)
- NestedObservationBuilder that includes surprise signal + momentum
- Surprise history tracking and basic analytics
- Integration with existing Observation phase
- Prediction tagging in Action phase for next-cycle surprise calculation

**Success Criteria:**
- Every observation includes a computed surprise signal
- Momentum accumulator captures contextually related sequences
- Surprise values correlate sensibly with semantic novelty
- Performance impact is acceptable (< 50ms added latency)

### 4.3 Phase 3: Reflection CMS Engine (Weeks 5-8)

**Objective:** Transform Reflection phase into the memory consolidation engine with full MIRAS support

**Deliverables:**
- Extended ReflectionService with stratum update logic
- Surprise threshold configuration and tuning interface
- **SurpriseMomentumTracker** for capturing contextually related information
- MemoryCompressor for tactical → operational promotion
- **RetentionGateService** with adaptive weight decay
- **AttentionalBiasProvider** with MSE and YAAD implementations
- **MIRASConfigManager** for per-stratum configuration
- New events for stratum updates

**Success Criteria:**
- High-surprise outcomes automatically promoted to slower strata
- Momentum ensures related follow-up information is captured
- Memories decay according to retention gate rules
- YAAD bias handles noisy inputs gracefully
- Compression maintains semantic fidelity (evaluate with test cases)

### 4.4 Phase 4: Tool-Grounded Verification (Weeks 9-11)

**Objective:** Enable Reflection phase to invoke tools for verification, not just text-based review

**Deliverables:**
- **VerifierModeHandler** for agent role-switching (Solver ↔ Verifier)
- **ToolGroundedVerifier** orchestrating tool invocation during Reflection
- Verification tuple generation: `Vt = (scoret, conft, critiquet)`
- **ConfidenceCalculator** for epistemic certainty scoring
- Integration with existing MXF tools (calculation, search, MongoDB Lens)
- MCP server support for verification tool calls
- Verification events and analytics

**Success Criteria:**
- Agents can switch to Verifier mode during Reflection
- Tool invocations provide factual grounding for verification
- Confidence scores correlate with actual reasoning correctness
- Verification results feed into memory promotion decisions

### 4.5 Phase 5: Self-Repair Protocol (Weeks 12-14)

**Objective:** Enable agents to correct their own reasoning when verification identifies issues

**Deliverables:**
- **SelfRepairEngine** with PATCH instruction generation
- Repair gate implementation with configurable threshold τc
- Re-execution flow (inject patch → re-plan → re-act → re-verify)
- **RepairCostTracker** for reward calculation
- NO_CHANGE handling when repair is not warranted
- Repair analytics and visualization in dashboard

**Success Criteria:**
- Low-confidence reasoning triggers self-repair appropriately
- PATCH instructions correctly target faulty reasoning steps
- Re-execution produces improved outcomes
- Repair costs are tracked and factored into rewards
- Unnecessary repairs are discouraged by cost penalty

### 4.6 Phase 6: SERC Orchestration (Weeks 15-17)

**Objective:** Integrate all components into unified Self-Evolving Reasoning Cycle

**Deliverables:**
- **SERCOrchestrator** coordinating inner/outer loop execution
- **ProcessRewardCalculator** with unified promotion scoring
- Inner loop: ORPAR + verification + repair per cycle
- Outer loop: cross-cycle memory consolidation
- SystemLLM integration as outer optimizer
- Cross-agent pattern detection and propagation
- SERC configuration (loop frequencies, thresholds)

**Success Criteria:**
- Complete SERC loop executes correctly across multiple cycles
- Inner loop handles individual task execution with self-correction
- Outer loop consolidates learnings into slower memory strata
- SystemLLM successfully identifies and propagates cross-agent patterns
- Agents demonstrate measurable improvement over iterations

### 4.7 Phase 7: Nested Context Assembly (Weeks 18-19)

**Objective:** Reasoning phase receives full nested context

**Deliverables:**
- Modified MxfSystemPromptManager with stratum context
- Stratum query interface for Reasoning phase
- Memory relevance feedback loop
- Token budget management across strata

**Success Criteria:**
- Prompts include relevant memories from appropriate strata
- Token usage remains within bounds
- Agents demonstrate recall of operational/strategic knowledge

### 4.8 Phase 8: Nested Planning (Weeks 20-21)

**Objective:** Planning phase operates at multiple temporal scales

**Deliverables:**
- Extended Plan types with temporal hierarchy
- Strategic goal tracking across sessions
- Drift detection between tactical execution and strategic intent
- Planning analytics dashboard updates

**Success Criteria:**
- Plans express goals at multiple time horizons
- Strategic goals persist across agent restarts
- Drift detection triggers appropriate reflection

### 4.9 Phase 9: SystemLLM Integration (Weeks 22-24)

**Objective:** System-level pattern consolidation across agents

**Deliverables:**
- SystemLLM pattern detection for cross-agent learning
- Channel-level strategic memory updates
- Agent configuration adjustment based on observed patterns
- Cross-agent knowledge propagation mechanism

**Success Criteria:**
- Successful strategies discovered by one agent can benefit others
- SystemLLM identifies and promotes valuable patterns
- No degradation to individual agent autonomy

### 4.10 Phase 10: Optimization and Hardening (Weeks 25-28)

**Objective:** Production readiness

**Deliverables:**
- Performance optimization (caching, batch operations)
- Comprehensive integration tests
- Documentation updates (SDK docs, API docs)
- Migration guide for existing deployments
- Feature flag for gradual rollout

**Success Criteria:**
- Performance benchmarks meet targets
- All existing tests pass
- Documentation complete
- Rollback procedure validated

---

## 5. Risk Assessment

### 5.1 Technical Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Surprise calculation too slow | Medium | High | Implement caching, use async calculation, fallback to simpler method |
| Memory compression loses critical information | Medium | High | Extensive testing, configurable compression levels, audit trail |
| Token budget exceeded with nested context | High | Medium | Strict budget enforcement, adaptive stratum inclusion |
| Database performance with additional queries | Medium | Medium | Indexing strategy, read replicas, caching layer |
| Cross-agent pattern detection false positives | Medium | Low | Conservative thresholds, human review option |

### 5.2 Project Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Scope creep in reflection engine | High | Medium | Strict phase boundaries, MVP definition per phase |
| Integration complexity with existing code | Medium | High | Comprehensive interface design upfront, adapter patterns |
| Testing complexity for temporal behaviors | High | Medium | Simulation framework for accelerated time, deterministic test modes |

---

## 6. Success Metrics

### 6.1 Quantitative Metrics

- **Memory efficiency:** Reduction in context tokens used while maintaining task performance
- **Recall accuracy:** Agent correctly retrieves relevant strategic knowledge (test suite)
- **Surprise correlation:** Surprise signal correlates with human-judged novelty (validation study)
- **Consolidation rate:** Percentage of high-surprise events successfully promoted to slower strata
- **Decay appropriateness:** Low-relevance memories decay without manual intervention
- **Cross-session retention:** Strategic knowledge persists and remains useful across sessions

### 6.2 Qualitative Metrics

- **Agent coherence:** Agents demonstrate consistent strategic behavior over time
- **Learning visibility:** Operators can observe and understand what agents have learned
- **Graceful degradation:** System functions acceptably if nested memory features disabled
- **Developer experience:** New memory features are intuitive to configure and debug

---

## 7. Open Questions

1. **Stratum count:** Four strata proposed, but should this be configurable? More strata = more granularity but more complexity.

2. **Compression strategy:** Should compression be LLM-based (semantic) or algorithmic (TF-IDF, embeddings)? Trade-off between quality and cost.

3. **Decay triggers:** Should decay be purely time-based, or also triggered by capacity limits or relevance scores?

4. **Cross-agent boundaries:** How much should agents learn from each other? Risk of homogenization vs. benefit of shared knowledge.

5. **Backward compatibility:** Should existing deployments auto-migrate to nested memory, or opt-in only?

6. **Surprise calibration:** How to calibrate surprise thresholds for different domains/use cases?

7. **MIRAS variant selection:** Which attentional bias strategy (MSE/YAAD/MONETA/MEMORA) best fits multi-agent coordination? Should different channels use different strategies based on reliability characteristics?

8. **Momentum window size:** How many cycles should the surprise momentum accumulator consider? Too short loses context; too long creates noise.

9. **Deep memory for Strategic stratum:** Is the added complexity of MLP-based memory storage justified for the Strategic stratum, or is matrix storage sufficient for MXF's use cases?

10. **Gradient calculation cost:** The Titans-style gradient-based surprise requires prediction tracking. What's the performance overhead, and can it be amortized across cycles?

11. **Verifier mode latency:** Switching to Verifier mode adds a verification step to each cycle. What's the acceptable latency budget, and should verification be async?

12. **Tool selection for verification:** Which tools should the Verifier prioritize? Should tool selection be learned or rule-based?

13. **Repair threshold tuning:** The confidence threshold τc (default 0.7) controls repair sensitivity. How to tune this per-domain without extensive experimentation?

14. **Repair loop limits:** Should there be a maximum number of repair attempts per cycle to prevent infinite loops?

15. **Confidence vs. Surprise weighting:** In the combined promotion score, how should confidence and surprise be weighted relative to each other?

16. **Cross-agent repair:** Can one agent's Verifier trigger repair in another agent's reasoning, or is self-repair strictly self-contained?

17. **SERC inner/outer loop frequency:** How many inner loops should execute before an outer loop consolidation? Fixed ratio or adaptive?

18. **Verification tool costs:** Tool invocations during verification add API costs. Should there be a verification budget per cycle?

---

## 8. Dependencies

### 8.1 External Dependencies

- Embedding model availability for surprise calculation
- MongoDB performance characteristics for stratum queries
- MXP 2.0 summarization capabilities for compression

### 8.2 Internal Dependencies

- Completion of any pending MxfMemoryManager refactoring
- Stable ReflectionService interface
- EventBus capacity for additional event types

---

## 9. Future Considerations

### 9.1 Self-Modifying Memory Configuration

Following the Nested Learning concept that Hope "can update the way it updates itself," a future enhancement could allow agents to adjust their own stratum configurations based on task performance. High-volatility domains might benefit from faster strategic updates; stable domains might operate primarily from cached strategic memory.

### 9.2 Federated Learning Across Deployments

If multiple MXF deployments exist, strategic knowledge could potentially be shared across deployments (with appropriate privacy controls), enabling a form of federated continual learning.

### 9.3 Hardware Optimization

As noted in the Nested Learning paper, current AI infrastructure is optimized for transformer architectures. If nested memory patterns prove valuable, future work could explore hardware-aware optimizations for stratum operations.

---

## 10. Appendix: Terminology Mapping

| Google Research Term | MXF Equivalent |
|---------------------|----------------|
| Continuum Memory System | Memory Strata |
| Surprise Signal | Novelty Score |
| Surprise Gradient | Prediction Error |
| Momentary Surprise | Current Cycle Novelty |
| Past Surprise | Momentum Accumulator |
| Fast/Slow Layers | Immediate/Strategic Strata |
| Titans (long-term memory) | Strategic Stratum |
| Self-modifying model | Adaptive stratum configuration |
| Context flow | ORPAR cycle context |
| Outer optimizer | SystemLLM |
| Retention Gate | Adaptive Weight Decay |
| Attentional Bias | Memory Priority Function |
| Memory Architecture | Stratum Storage Type |
| Memory Algorithm | Update Strategy |
| YAAD | Outlier-Robust Bias (Huber Loss) |
| MONETA | Strict Norm Bias |
| MEMORA | Probability-Constrained Bias |
| Weight Decay | Decay Rate / Forgetting Gate |
| Test-time Memorization | Runtime Memory Consolidation |
| Solver Mode | ORPA Phases (standard execution) |
| Verifier Mode | Reflection with tool-grounded verification |
| SERC | Self-Evolving Reasoning Cycle (inner + outer loops) |
| Process-level Reward | Promotion Score |
| Self-Repair | PATCH-based reasoning correction |

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | December 2025 | Brad Anderson | Initial draft |
| 1.1 | December 2025 | Brad Anderson | Added Titans/MIRAS framework, momentum tracking, retention gates, MIRAS design choices |
| 1.2 | December 2025 | Brad Anderson | Added SERC (Self-Evolving Reasoning Cycle), tool-grounded verification, self-repair protocol, expanded to 28-week plan |

---

## References

1. **Nested Learning: The Illusion of Deep Learning Architectures** — Behrouz, Razaviyayn, Zhong, Mirrokni (NeurIPS 2025)
   - https://research.google/blog/introducing-nested-learning-a-new-ml-paradigm-for-continual-learning/

2. **Titans: Learning to Memorize at Test Time** — Behrouz, Razaviyayn, Mirrokni (2025)
   - https://arxiv.org/abs/2501.00663

3. **MIRAS: A Unified Framework for Sequence Modeling** — Google Research (2025)
   - https://arxiv.org/pdf/2504.13173

4. **Agent0-VL: Exploring Self-Evolving Agent for Tool-Integrated Vision-Language Reasoning** — AIMing Lab (2025)
   - https://github.com/aiming-lab/Agent0

---

*This document is part of the Model Exchange Framework (MXF) technical documentation.*
