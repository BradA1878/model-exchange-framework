# Meilisearch Indexing Timing Solutions

**Date**: 2025-11-11
**Status**: Design Proposal
**Priority**: Medium - Affects agent UX for history-heavy workflows

---

## Executive Summary

Agents with extensive conversation histories (300+ messages) face a **timing issue** where `memory_search_conversations` tools are unavailable during initial task execution because Meilisearch indexing takes 2-5 minutes to complete. This document explores architectural solutions to ensure agents have history search capabilities when they need them.

---

## Background: The Discovery

### Initial Investigation: Solar Storm Demo

**Symptom**: Storm Coordinator agent reports:
```
"I don't have a memory_search_conversations tool available in my tool list!"
```

**Agent Configuration**:
```typescript
allowedTools: [
    'task_create',
    'task_complete',
    'api_fetch',
    'memory_search_conversations',  // ← Explicitly requested!
    'add', 'sub', 'mul', 'div'
]
```

**Agent's Prompt Instructions** (line 182):
```
STEP 3: SEARCH HISTORICAL PATTERNS (if Meilisearch ready)
```

### Root Cause Analysis

**The Current Architecture**:

```
1. Agent connects → memoryManager.initialize()
2. loadAgentMemory() loads 300+ messages from MongoDB
3. backfillConversationsToMeilisearch() sends to server
4. Server processes with embeddings (~580ms per message)
   - 300 msgs × 580ms = 174 seconds (2.9 minutes)
   - 500 msgs × 580ms = 290 seconds (4.8 minutes)
5. Event emitted: meilisearch:backfill:complete
6. AgentService sets meilisearchReady = true
7. Tools refresh → memory_search tools become available

PROBLEM: Step 1-7 happens AFTER agent is already "ready" and may receive tasks!
```

**Filtering Logic** (`McpService.ts:267-283`):
```typescript
if (meilisearchEnabled && filter?.agentId) {
    const agentData = agentService.getAgent(filter.agentId);
    const meilisearchReady = agentData?.meilisearchReady || false;

    if (!meilisearchReady) {
        // Remove memory_search tools until backfill complete
        allTools = allTools.filter(tool => !tool.name.startsWith('memory_search_'));
        this.logger.info(`Removed search tools (backfill not ready)`);
    }
}
```

**Why This Filtering Is Correct**:
- Prevents agents from calling tools that would fail or return incomplete results
- Security: Ensures embeddings are generated server-side (not client-side)
- Performance: Avoids slow searches on partially-indexed data

**Test Results** (meilisearch-integration.test.ts):
- 21 messages indexed in 12.2 seconds
- ~580ms per message (includes embedding generation)
- Backfill event successfully triggered and received

---

## Current Workarounds

### 1. n8n Workflow Delay
Add a wait step in n8n workflow after demo start, before task creation:
```
Start Demo → Wait 20 minutes → Create Task
```

**Pros**: Simple, works for scheduled workflows
**Cons**: Wastes time, brittle, not applicable to on-demand tasks

### 2. Prompt Adjustment (Immediate Fix)
Change agent prompt from implementation details to tool names:

**Before** (confusing):
```
STEP 3: SEARCH HISTORICAL PATTERNS (if Meilisearch ready)
```

**After** (clear):
```
STEP 3: SEARCH HISTORICAL PATTERNS (if memory_search_conversations available)

Check your available tools list:
- IF memory_search_conversations IS in your tools → Use it to search past responses
- IF NOT in your tools → History still indexing (normal for extensive conversation logs)
  * Note in reasoning: "Historical search unavailable (indexing ~300+ messages)"
  * Proceed immediately with n8n data + API fetches - sufficient for analysis

DO NOT wait or delay - the 11 API sources are your primary data.
Historical patterns are supplementary intelligence.
```

**Pros**: Works immediately, no code changes, graceful degradation
**Cons**: Agent can't use history even when it would be valuable

---

## Proposed Solutions

### Solution 1: Server-Side Proactive Background Indexing

**Concept**: Server maintains a background indexing service that pre-indexes agent histories **before** agents connect.

#### Architecture

```typescript
// New Service: src/server/services/MeilisearchBackgroundIndexer.ts
class MeilisearchBackgroundIndexer {
    private indexingQueue: Map<string, IndexingJob>;
    private completedIndexes: Map<string, IndexStatus>;
    private activeJobs: Map<string, Promise<void>>;

    /**
     * Pre-index an agent's history in background
     */
    async preIndexAgentHistory(
        agentId: string,
        channelId: string,
        priority: 'background' | 'high' = 'background'
    ): Promise<void> {
        // 1. Check if already indexed recently
        const existing = this.completedIndexes.get(agentId);
        if (existing && Date.now() - existing.timestamp < 3600000) { // 1 hour
            return; // Already indexed recently
        }

        // 2. Load conversation history from MongoDB
        const messages = await AgentMemory.findOne({ agentId })
            .select('conversationHistory')
            .lean();

        if (!messages?.conversationHistory?.length) {
            // No history - mark as ready immediately
            this.completedIndexes.set(agentId, {
                indexed: true,
                messageCount: 0,
                timestamp: Date.now()
            });
            return;
        }

        // 3. Index with embeddings
        const meilisearch = MxfMeilisearchService.getInstance();
        let indexed = 0;
        let failed = 0;

        for (const msg of messages.conversationHistory) {
            try {
                await meilisearch.indexConversation(msg);
                indexed++;
            } catch (error) {
                failed++;
                logger.error(`Failed to index message: ${error}`);
            }
        }

        // 4. Mark as complete
        this.completedIndexes.set(agentId, {
            indexed: true,
            messageCount: indexed,
            timestamp: Date.now(),
            failedCount: failed
        });

        logger.info(`Pre-indexed ${indexed} messages for ${agentId} (${failed} failed)`);
    }

    /**
     * Check if agent's history is already indexed
     */
    isIndexReady(agentId: string): boolean {
        const status = this.completedIndexes.get(agentId);
        return status?.indexed === true;
    }

    /**
     * Queue agent for background indexing
     */
    queueIndexing(agentId: string, channelId: string, priority: 'background' | 'high'): void {
        if (this.activeJobs.has(agentId)) {
            return; // Already indexing
        }

        const job = this.preIndexAgentHistory(agentId, channelId, priority);
        this.activeJobs.set(agentId, job);

        job.finally(() => {
            this.activeJobs.delete(agentId);
        });
    }

    /**
     * Pre-index all known "active" agents
     * Called on server startup or via cron
     */
    async preIndexActiveAgents(): Promise<void> {
        // Get agents active in last 24 hours
        const activeAgents = await Agent.find({
            lastActivity: { $gte: Date.now() - 86400000 }
        }).select('agentId channelId');

        logger.info(`Pre-indexing ${activeAgents.length} active agents...`);

        // Index in parallel (with concurrency limit)
        const CONCURRENCY = 5;
        for (let i = 0; i < activeAgents.length; i += CONCURRENCY) {
            const batch = activeAgents.slice(i, i + CONCURRENCY);
            await Promise.all(
                batch.map(agent =>
                    this.preIndexAgentHistory(agent.agentId, agent.channelId)
                )
            );
        }

        logger.info(`✅ Pre-indexing complete for ${activeAgents.length} agents`);
    }
}
```

#### Integration Points

**Server Startup** (`src/server/index.ts`):
```typescript
// After Meilisearch initialization
const backgroundIndexer = MeilisearchBackgroundIndexer.getInstance();

// Pre-index known active agents
if (process.env.ENABLE_MEILISEARCH === 'true') {
    backgroundIndexer.preIndexActiveAgents().catch(error => {
        logger.error('Background indexing failed:', error);
    });
}
```

**Agent Registration** (`AgentService.registerAgent`):
```typescript
public registerAgent(agentId: string, capabilities: string[], allowedTools?: string[]): IAgent {
    // Check if history already indexed
    const indexReady = backgroundIndexer.isIndexReady(agentId);

    const agent: IAgent = {
        agentId,
        capabilities,
        allowedTools,
        status: AgentConnectionStatus.CONNECTING,
        meilisearchReady: indexReady,  // TRUE if pre-indexed!
        socketIds: [],
        metadata: {}
    };

    // If not ready but has history, queue for indexing
    if (!indexReady) {
        // Check if history exists in MongoDB
        AgentMemory.findOne({ agentId })
            .select('conversationHistory')
            .then(memory => {
                if (memory?.conversationHistory?.length > 0) {
                    backgroundIndexer.queueIndexing(agentId, channelId, 'high');
                }
            });
    }

    this.agents.set(agentId, agent);
    return agent;
}
```

**Cron Job** (Optional - for production):
```typescript
// Index active agents every 6 hours
cron.schedule('0 */6 * * *', async () => {
    await backgroundIndexer.preIndexActiveAgents();
});
```

#### Benefits
✅ Zero wait for recurring agents (pre-indexed on schedule)
✅ Minimal wait for new agents (high-priority queue)
✅ No application code changes required
✅ Works automatically in background
✅ Server has full control

#### Challenges
❌ Requires MongoDB query on each registration
❌ Index could become stale if many new messages
❌ Memory overhead for index status cache

---

### Solution 2: SDK Pre-Load API (Developer Control)

**Concept**: Expose explicit method in SDK that pre-loads and indexes history before creating agent.

#### Architecture

```typescript
// New SDK Method: src/sdk/MxfSDK.ts
interface PreloadOptions {
    /** Callback for progress updates */
    onProgress?: (indexed: number, total: number) => void;

    /** Maximum time to wait for indexing (ms) */
    timeout?: number;

    /** Whether to wait for completion or return immediately */
    waitForCompletion?: boolean;
}

interface PreloadResult {
    success: boolean;
    indexed: number;
    total: number;
    duration: number;
    timedOut?: boolean;
}

class MxfSDK {
    /**
     * Pre-load and index an agent's conversation history
     *
     * Call this BEFORE createAgent() for agents with large histories.
     * This ensures memory_search tools are immediately available.
     *
     * @param agentId - Agent ID to pre-load
     * @param channelId - Channel ID
     * @param options - Preload options
     * @returns Promise resolving to preload results
     *
     * @example
     * // Pre-load before creating agent
     * await sdk.preloadAgentHistory('storm-coordinator', 'solar-storm-response', {
     *     onProgress: (i, t) => console.log(`Indexing: ${i}/${t}`),
     *     timeout: 300000 // 5 minutes
     * });
     * const agent = await sdk.createAgent(config); // Immediately ready!
     */
    async preloadAgentHistory(
        agentId: string,
        channelId: string,
        options: PreloadOptions = {}
    ): Promise<PreloadResult> {
        const {
            onProgress,
            timeout = 300000, // 5 minutes default
            waitForCompletion = true
        } = options;

        // 1. Check if agent already has meilisearchReady = true
        const status = await this.checkAgentIndexStatus(agentId);
        if (status.ready) {
            return {
                success: true,
                indexed: status.indexed,
                total: status.total,
                duration: 0 // Already done
            };
        }

        // 2. Fetch conversation history from server
        const response = await this.apiClient.get(
            `/api/agents/${agentId}/memory`,
            { params: { fields: 'conversationHistory' } }
        );
        const messages = response.data.memory?.conversationHistory || [];

        if (messages.length === 0) {
            // No history - ready immediately
            return {
                success: true,
                indexed: 0,
                total: 0,
                duration: 0
            };
        }

        // 3. Request server-side indexing with embeddings
        const indexingRequest = {
            agentId,
            channelId,
            messages,
            priority: 'immediate', // High priority for pre-loads
            requestId: `preload-${Date.now()}`
        };

        await this.apiClient.post('/api/meilisearch/preload', indexingRequest);

        // 4. Wait for completion or return immediately
        if (!waitForCompletion) {
            return {
                success: true,
                indexed: 0,
                total: messages.length,
                duration: 0
            };
        }

        // 5. Listen for backfill completion event
        return new Promise((resolve, reject) => {
            const startTime = Date.now();
            let lastProgress = 0;

            const timeoutHandle = setTimeout(() => {
                cleanup();
                resolve({
                    success: false,
                    indexed: lastProgress,
                    total: messages.length,
                    duration: Date.now() - startTime,
                    timedOut: true
                });
            }, timeout);

            const completeHandler = (payload: any) => {
                if (payload.agentId === agentId) {
                    cleanup();
                    resolve({
                        success: true,
                        indexed: payload.data.indexedDocuments,
                        total: payload.data.totalDocuments,
                        duration: Date.now() - startTime
                    });
                }
            };

            const progressHandler = (payload: any) => {
                if (payload.agentId === agentId && onProgress) {
                    lastProgress = payload.data.indexedDocuments;
                    onProgress(payload.data.indexedDocuments, payload.data.totalDocuments);
                }
            };

            const cleanup = () => {
                clearTimeout(timeoutHandle);
                EventBus.client.off('meilisearch:backfill:complete', completeHandler);
                EventBus.client.off('meilisearch:backfill:progress', progressHandler);
            };

            EventBus.client.on('meilisearch:backfill:complete', completeHandler);
            EventBus.client.on('meilisearch:backfill:progress', progressHandler);
        });
    }

    /**
     * Helper: Check if agent's history is already indexed
     */
    private async checkAgentIndexStatus(agentId: string): Promise<{
        ready: boolean;
        indexed: number;
        total: number;
    }> {
        try {
            const response = await this.apiClient.get(`/api/meilisearch/status/${agentId}`);
            return response.data;
        } catch (error) {
            return { ready: false, indexed: 0, total: 0 };
        }
    }
}
```

#### Server API Endpoint

```typescript
// New Route: src/server/api/routes/meilisearch.ts
router.post('/meilisearch/preload', authenticateDual, async (req, res) => {
    const { agentId, channelId, messages, priority } = req.body;

    // Validate inputs
    if (!agentId || !channelId || !messages) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    // Use existing backfill handler
    const payload = {
        agentId,
        channelId,
        data: {
            operationId: `preload-${Date.now()}`,
            metadata: {
                messages,
                priority
            }
        }
    };

    EventBus.server.emit('meilisearch:backfill:request', payload);

    res.json({
        success: true,
        message: `Indexing ${messages.length} messages for ${agentId}`,
        estimatedDuration: messages.length * 580 // ms
    });
});

router.get('/meilisearch/status/:agentId', authenticateDual, async (req, res) => {
    const { agentId } = req.params;

    const agentService = AgentService.getInstance();
    const agent = agentService.getAgent(agentId);

    // Check Meilisearch for indexed count
    const meilisearch = MxfMeilisearchService.getInstance();
    const searchResult = await meilisearch.searchConversations({
        query: '',
        filter: `agentId = "${agentId}"`,
        limit: 0
    });

    // Check MongoDB for total count
    const memory = await AgentMemory.findOne({ agentId }).select('conversationHistory');
    const totalMessages = memory?.conversationHistory?.length || 0;

    res.json({
        ready: agent?.meilisearchReady || false,
        indexed: searchResult.estimatedTotalHits,
        total: totalMessages
    });
});
```

#### Usage Pattern

```typescript
// Solar Storm Demo: examples/solar-storm-demo/solar-storm-demo.ts
export const initializeAgents = async (sdk: MxfSDK): Promise<{ [key: string]: MxfAgent }> => {
    const agents: { [key: string]: MxfAgent } = {};

    StoryLogger.logSystemUpdate('🔍 Pre-loading agent histories for search capabilities...');

    // Pre-load histories in parallel
    const preloadResults = await Promise.all([
        sdk.preloadAgentHistory('storm-coordinator', config.channelId, {
            onProgress: (i, t) => console.log(`  Coordinator: ${i}/${t} messages indexed`)
        }),
        sdk.preloadAgentHistory('storm-logger', config.channelId),
        sdk.preloadAgentHistory('storm-workflow', config.channelId)
    ]);

    StoryLogger.logSystemUpdate(`✅ Histories indexed:`);
    preloadResults.forEach((result, idx) => {
        const name = ['storm-coordinator', 'storm-logger', 'storm-workflow'][idx];
        StoryLogger.logSystemUpdate(`   ${name}: ${result.indexed}/${result.total} (${result.duration}ms)`);
    });

    StoryLogger.logSystemUpdate('🚀 Bringing solar storm response team online...');

    // NOW create agents - they'll have meilisearchReady = true immediately
    for (const [id, agentConfig] of Object.entries(agentConfigurations)) {
        StoryLogger.logSystemUpdate(`⚡ Initializing ${agentConfig.name}...`);

        const agent = await sdk.createAgent(agentConfig);
        await agent.connect();

        agents[id] = agent;

        StoryLogger.logSystemUpdate(`✅ ${agentConfig.name} ready (with full search capabilities)`);
        await new Promise(resolve => setTimeout(resolve, 250));
    }

    return agents;
};
```

#### Benefits
✅ **Explicit Control**: Developer chooses when to pre-load
✅ **Parallel Loading**: Can pre-load multiple agents concurrently
✅ **Progress Visibility**: Show indexing progress to users
✅ **Non-Blocking Option**: Can start indexing and continue (waitForCompletion: false)
✅ **Works with Existing Architecture**: No changes to core agent lifecycle
✅ **Self-Documenting**: Clear API makes timing expectations obvious

#### Challenges
❌ **Requires Code Changes**: Applications must explicitly call preload
❌ **Developer Must Remember**: Easy to forget for new use cases
❌ **Extra API Round-Trip**: Adds latency before agent creation

---

### Solution 3: Agent Pool / Warm Pool Pattern

**Concept**: Maintain a pool of "warm" agents with histories already indexed, ready for immediate use.

#### Architecture

```typescript
// New Service: src/sdk/services/MxfAgentPool.ts
interface PooledAgent {
    agent: MxfAgent;
    config: AgentCreationConfig;
    readyAt: number;
    lastUsed: number;
}

class MxfAgentPool {
    private warmAgents: Map<string, PooledAgent> = new Map();
    private indexingPromises: Map<string, Promise<void>> = new Map();
    private maxPoolSize: number = 10;
    private maxIdleTime: number = 3600000; // 1 hour

    /**
     * Pre-warm an agent with indexed history
     */
    async warmAgent(agentId: string, config: AgentCreationConfig): Promise<void> {
        if (this.warmAgents.has(agentId)) {
            return; // Already warm
        }

        // 1. Create agent instance
        const agent = new MxfAgent(config);

        // 2. Connect and initialize (triggers history load + indexing)
        await agent.connect();

        // 3. Wait for Meilisearch to finish indexing
        await this.waitForIndexingComplete(agentId, config.channelId);

        // 4. Store in warm pool
        this.warmAgents.set(agentId, {
            agent,
            config,
            readyAt: Date.now(),
            lastUsed: 0
        });

        console.log(`✅ Agent ${agentId} warmed and ready (history indexed)`);
    }

    /**
     * Get a warm agent (or create on-demand if not in pool)
     */
    async getAgent(agentId: string, config: AgentCreationConfig): Promise<MxfAgent> {
        // Check warm pool first
        if (this.warmAgents.has(agentId)) {
            const pooled = this.warmAgents.get(agentId)!;
            pooled.lastUsed = Date.now();

            // Return agent but keep in pool (reusable)
            return pooled.agent;
        }

        // Not in pool - warm it now
        await this.warmAgent(agentId, config);
        return this.getAgent(agentId, config);
    }

    /**
     * Pre-warm multiple agents for an application
     */
    async warmPool(configs: AgentCreationConfig[]): Promise<void> {
        await Promise.all(
            configs.map(config => this.warmAgent(config.agentId, config))
        );
    }

    /**
     * Wait for indexing to complete
     */
    private async waitForIndexingComplete(
        agentId: string,
        channelId: string,
        timeout: number = 300000
    ): Promise<void> {
        return new Promise((resolve, reject) => {
            const timeoutHandle = setTimeout(() => {
                reject(new Error(`Indexing timeout for ${agentId}`));
            }, timeout);

            EventBus.client.on('meilisearch:backfill:complete', (payload: any) => {
                if (payload.agentId === agentId) {
                    clearTimeout(timeoutHandle);
                    resolve();
                }
            });
        });
    }

    /**
     * Clean up idle agents
     */
    async cleanupIdleAgents(): void {
        const now = Date.now();
        for (const [agentId, pooled] of this.warmAgents.entries()) {
            if (now - pooled.lastUsed > this.maxIdleTime) {
                await pooled.agent.disconnect();
                this.warmAgents.delete(agentId);
            }
        }
    }
}
```

#### Usage Pattern

```typescript
// Initialize pool at application startup
const agentPool = new MxfAgentPool();

// Warm the pool (e.g., on app startup or before peak hours)
await agentPool.warmPool([
    coordinatorConfig,
    loggerConfig,
    workflowConfig
]);

console.log('✅ Agent pool ready - all histories indexed');

// Later, when task arrives from n8n:
const coordinator = await agentPool.getAgent('storm-coordinator', coordinatorConfig);
// Agent is IMMEDIATELY ready with indexed history and memory_search tools!

// Clean up periodically
setInterval(() => agentPool.cleanupIdleAgents(), 600000); // Every 10 min
```

#### Benefits
✅ **Zero Latency**: Agents ready instantly when needed
✅ **Perfect for Production**: Ideal for recurring workloads
✅ **Predictable Performance**: No variance in agent startup time
✅ **Reusable Pattern**: Works for any agent-based application

#### Challenges
❌ **Memory Overhead**: Keeps agents in memory
❌ **Connection Management**: Need to handle stale connections
❌ **Pool Sizing**: How many agents to keep warm?
❌ **Refresh Strategy**: When to re-warm agents with new messages?

---

### Solution 4: Smart Agent Flag - SDK Signals Server (⭐ New Insight!)

**Concept**: When creating an agent, SDK analyzes config and signals server if indexing is needed.

#### Architecture

```typescript
// SDK: Detect if agent needs history search
class MxfAgent {
    constructor(config: AgentConfig) {
        // ... existing initialization ...

        // Detect if this agent needs memory search capabilities
        this.needsHistorySearch = this.detectHistorySearchNeeded(config);

        if (this.needsHistorySearch) {
            this.logger.info('🔍 Agent requires memory search - will signal server for priority indexing');
        }
    }

    /**
     * Detect if agent needs memory_search tools based on configuration
     */
    private detectHistorySearchNeeded(config: AgentConfig): boolean {
        // Case 1: Explicitly includes memory_search in allowedTools
        if (config.allowedTools?.some(tool => tool.startsWith('memory_search_'))) {
            return true;
        }

        // Case 2: allowedTools is empty/null/undefined → Gets core tools
        // Check if core tools include memory_search when Meilisearch enabled
        if (!config.allowedTools || config.allowedTools.length === 0) {
            const meilisearchEnabled = process.env.ENABLE_MEILISEARCH === 'true';
            return meilisearchEnabled; // Core tools include memory_search when enabled
        }

        // Case 3: Has specific allowedTools but no memory_search → Doesn't need it
        return false;
    }
}

// Server: Priority queue based on agent signals
class AgentService {
    public registerAgent(agentId: string, capabilities: string[], allowedTools?: string[]): IAgent {
        // Detect if agent needs history search
        const needsHistorySearch = this.detectHistorySearchNeeded(allowedTools);

        const agent: IAgent = {
            agentId,
            capabilities,
            allowedTools,
            status: AgentConnectionStatus.CONNECTING,
            meilisearchReady: false, // Start as false
            socketIds: [],
            metadata: {
                needsHistorySearch // Store for later use
            }
        };

        this.agents.set(agentId, agent);

        // If agent needs history search, prioritize its indexing
        if (needsHistorySearch) {
            this.logger.info(`🔍 Agent ${agentId} needs history search - queuing priority indexing`);
            // Queue for immediate indexing (same logic as Solution 1)
            this.queuePriorityIndexing(agentId);
        }

        return agent;
    }

    /**
     * Detect if agent needs memory_search based on allowedTools
     */
    private detectHistorySearchNeeded(allowedTools?: string[]): boolean {
        const meilisearchEnabled = process.env.ENABLE_MEILISEARCH === 'true';
        if (!meilisearchEnabled) return false;

        // Case 1: Explicit memory_search in allowedTools
        if (allowedTools?.some(tool => tool.startsWith('memory_search_'))) {
            return true;
        }

        // Case 2: No allowedTools specified → Gets core tools (includes memory_search)
        if (!allowedTools || allowedTools.length === 0) {
            return true;
        }

        // Case 3: Has allowedTools but no memory_search
        return false;
    }

    /**
     * Queue agent for priority indexing
     */
    private async queuePriorityIndexing(agentId: string): Promise<void> {
        // Check if history exists
        const memory = await AgentMemory.findOne({ agentId })
            .select('conversationHistory')
            .lean();

        if (!memory?.conversationHistory?.length) {
            // No history - mark as ready immediately
            const agent = this.agents.get(agentId);
            if (agent) {
                agent.meilisearchReady = true;
                this.agents.set(agentId, agent);
            }
            return;
        }

        // Has history - index it with high priority
        const backgroundIndexer = MeilisearchBackgroundIndexer.getInstance();
        await backgroundIndexer.queueIndexing(agentId, agent.channelId, 'high');
    }
}
```

#### Benefits
✅ **Automatic Detection**: No developer code changes needed
✅ **Smart Prioritization**: Only indexes when needed
✅ **Efficient**: Doesn't waste resources on agents that don't need search
✅ **Backward Compatible**: Existing agents work without changes
✅ **Self-Optimizing**: System learns which agents need indexing

#### Challenges
❌ **Still Has Wait Time**: Agent connects before indexing complete
❌ **Complex Detection Logic**: Edge cases in allowedTools parsing

---

### Solution 5: Hybrid Approach - Best of All Worlds

**Concept**: Combine multiple solutions for different use cases.

#### Strategy Matrix

| Agent Type | Solution | Rationale |
|------------|----------|-----------|
| **Recurring Production** (storm-coordinator runs every 12h) | Solution 1: Background Indexing | Server pre-indexes on schedule, zero wait |
| **On-Demand Critical** (needs immediate history) | Solution 2: SDK Pre-Load | Explicit control, show progress |
| **High-Volume Pool** (100s of agents) | Solution 3: Warm Pool | Keep frequently-used agents ready |
| **General Use** | Solution 4: Smart Flagging | Automatic, works for most cases |

#### Implementation

```typescript
// 1. Server runs background indexer (Solution 1)
cron.schedule('0 */6 * * *', async () => {
    await backgroundIndexer.preIndexActiveAgents();
});

// 2. SDK provides pre-load API (Solution 2)
sdk.preloadAgentHistory('critical-agent', 'channel');

// 3. SDK provides agent pool (Solution 3)
const pool = new MxfAgentPool();
await pool.warmPool([config1, config2]);

// 4. Agent registration auto-detects need (Solution 4)
// Happens automatically based on allowedTools
```

---

## 🎯 Recommended Implementation Strategy

### Phase 1: Quick Wins (This Week)

**1. Prompt Fix** (Immediate)
- Update storm-coordinator prompt to check tool availability
- Use tool names, not implementation details
- File: `examples/solar-storm-demo/solar-storm-demo.ts:182-195`

**2. Smart Agent Flagging** (Solution 4)
- Add detection logic to `AgentService.registerAgent()`
- Queue priority indexing for agents with memory_search in allowedTools
- Files:
  - `src/server/socket/services/AgentService.ts`
  - `src/sdk/MxfAgent.ts` (add detection method)

### Phase 2: SDK Enhancement (Next Sprint)

**3. SDK Pre-Load API** (Solution 2)
- Add `sdk.preloadAgentHistory()` method
- Add `/api/meilisearch/preload` endpoint
- Add `/api/meilisearch/status/:agentId` endpoint
- Update solar-storm-demo to use it
- Files:
  - `src/sdk/MxfSDK.ts`
  - `src/server/api/routes/meilisearch.ts` (new file)

### Phase 3: Production Optimization (Future)

**4. Background Indexer** (Solution 1)
- Implement `MeilisearchBackgroundIndexer` service
- Add cron job for recurring agents
- Integrate with agent registration
- Files:
  - `src/server/services/MeilisearchBackgroundIndexer.ts` (new)
  - `src/server/index.ts` (startup integration)

**5. Agent Pool** (Solution 3 - Optional)
- For high-volume production deployments
- Implement as separate package or feature flag

---

## Key Insight: Smart Detection Logic

**The Brilliant Realization** (from discussion):

> "Using the SDK, developers could flag agents for server-side indexing **only if** Meilisearch is enabled AND memory_search_conversations is in allowedTools (or if allowedTools is empty/null/undefined, since core tools include it)"

### Detection Algorithm

```typescript
function agentNeedsHistorySearch(allowedTools?: string[]): boolean {
    const meilisearchEnabled = process.env.ENABLE_MEILISEARCH === 'true';

    if (!meilisearchEnabled) {
        return false; // Meilisearch disabled globally
    }

    // Case 1: Explicit memory_search in allowedTools
    if (allowedTools?.some(tool => tool.startsWith('memory_search_'))) {
        return true;
    }

    // Case 2: No allowedTools specified → Gets core tools
    if (!allowedTools || allowedTools.length === 0) {
        // Core tools include memory_search when ENABLE_MEILISEARCH=true
        return true;
    }

    // Case 3: Has specific allowedTools without memory_search
    return false;
}
```

This enables **automatic, intelligent prioritization** without developer intervention!

---

## Edge Cases & Considerations

### 1. Race Condition: Messages Added During Indexing

**Scenario**: Agent has 300 messages. Indexing starts. User sends 5 new messages. Indexing completes.

**Current Behavior**: New messages indexed real-time, old messages indexed via backfill. ✅ Works!

**Why**:
- New messages go through `memoryManager.addConversationMessage()`
- Calls `meilisearchService.indexConversation()` immediately
- Backfill only handles historical messages
- No duplicate indexing (document IDs are unique)

### 2. Index Staleness

**Scenario**: Agent pre-indexed at 6 AM. 100 new messages added. Agent connects at 12 PM.

**Current Behavior**: Backfill skipped (messages.length === 0 after loading only new messages)

**Potential Issue**: If MongoDB returns only NEW messages, old ones won't re-index.

**Solution**: Track last indexed timestamp per agent
```typescript
interface IndexStatus {
    agentId: string;
    lastIndexedAt: number;
    messageCount: number;
}

// When loading memory
const lastIndexed = await getLastIndexTimestamp(agentId);
const messages = await AgentMemory.findOne({ agentId })
    .select({
        conversationHistory: {
            $filter: { timestamp: { $gt: lastIndexed } }
        }
    });
```

### 3. Multi-Channel Agents

**Scenario**: Agent participates in multiple channels, each with separate history.

**Current**: Filter uses `agentId` only (line 108 in MemorySearchTools.ts)

**Enhancement Needed**:
```typescript
// Current filter (CORRECT for security)
let filter = `agentId = "${context.agentId}"`;

// But should ALSO filter by channel for isolation
if (context.channelId) {
    filter += ` AND channelId = "${context.channelId}"`;
}
```

This ensures agents only search history from the current channel, not all channels.

### 4. Memory Usage - Large Histories

**Scenario**: Agent has 10,000 messages in history.

**Indexing Time**: 10,000 × 580ms = 5,800 seconds = **97 minutes**

**Solution**:
- Implement incremental indexing (index last 1000 messages, older ones on-demand)
- Add message pruning strategy (archive messages older than 90 days)
- Use pagination for very large histories

---

## Performance Benchmarks

### Test Data (meilisearch-integration.test.ts)
- **21 messages**: 12.2 seconds = **580ms/message**
- Includes embedding generation via OpenRouter → OpenAI

### Projections

| Message Count | Indexing Time | Strategy |
|---------------|---------------|----------|
| 0-50 | <30 seconds | Acceptable wait on connect |
| 50-200 | 30-120 seconds | Priority queue + prompt fallback |
| 200-500 | 2-5 minutes | **Pre-load or background indexing required** |
| 500-1000 | 5-10 minutes | **Pre-load essential** |
| 1000+ | 10+ minutes | **Background only + incremental indexing** |

### Optimization Opportunities

**Batch Embedding Generation**:
```typescript
// Current: One API call per message (580ms each)
for (const msg of messages) {
    const embedding = await generateEmbedding(msg.content); // 580ms
    await indexConversation(msg, embedding);
}

// Optimized: Batch embedding requests (50-100ms per message)
const contents = messages.map(m => m.content);
const embeddings = await generateEmbeddingsBatch(contents); // Single API call
for (let i = 0; i < messages.length; i++) {
    await indexConversation(messages[i], embeddings[i]);
}

// Potential speedup: 5-10x faster
```

**OpenAI Batch API**:
- Send 100 messages in single request
- Get 100 embeddings back
- Reduces from 300 API calls to 3 API calls
- **Estimated improvement**: 300 messages in ~30 seconds instead of 3 minutes

---

## Recommended Action Plan

### Immediate (This Week)

1. **Fix Prompt** - Use tool names instead of "Meilisearch ready"
   - File: `examples/solar-storm-demo/solar-storm-demo.ts:182`
   - Change: "if Meilisearch ready" → "if memory_search_conversations available"
   - Add: Graceful degradation instructions

2. **Add Channel Filtering** - Security enhancement
   - File: `src/shared/protocols/mcp/tools/MemorySearchTools.ts:106-120`
   - Add: `AND channelId = "${context.channelId}"` to filter

### Short Term (Next 2 Weeks)

3. **Implement Smart Detection** (Solution 4)
   - Add detection method to `AgentService`
   - Queue high-priority indexing for flagged agents
   - Files:
     - `src/server/socket/services/AgentService.ts`
     - `src/sdk/MxfAgent.ts`

4. **Batch Embedding API**
   - Update `MxfMeilisearchService` to batch embeddings
   - Use OpenAI batch API or parallel requests
   - Target: 5x speedup (300 msgs in 30-60 seconds)

### Medium Term (Next Month)

5. **SDK Pre-Load API** (Solution 2)
   - Implement `sdk.preloadAgentHistory()`
   - Add server endpoints
   - Update solar-storm-demo to showcase it
   - Add to SDK documentation

6. **Background Indexer Service** (Solution 1)
   - Implement background indexing service
   - Add cron job for active agents
   - Integrate with agent registration

### Long Term (Future)

7. **Agent Pool** (Solution 3 - Optional)
   - For high-throughput production deployments
   - Implement as optional feature

8. **Incremental Indexing**
   - Index recent 1000 messages first
   - Archive older messages
   - On-demand deep search for very old history

---

## Configuration & Environment Variables

### Proposed New Variables

```bash
# Meilisearch Background Indexing
MEILISEARCH_BACKGROUND_INDEXING=true          # Enable background indexer
MEILISEARCH_PREINDEX_ACTIVE_AGENTS=true       # Pre-index agents active in last 24h
MEILISEARCH_PREINDEX_CRON="0 */6 * * *"       # Cron schedule for background indexing
MEILISEARCH_PRIORITY_QUEUE_ENABLED=true       # Enable priority queue for flagged agents

# Performance Tuning
MEILISEARCH_BATCH_EMBEDDINGS=true             # Use batch embedding API
MEILISEARCH_MAX_BATCH_SIZE=100                # Embeddings per batch request
MEILISEARCH_CONCURRENT_INDEXING=5             # Parallel indexing jobs
MEILISEARCH_INDEX_TIMEOUT_MS=600000           # 10 minutes max per agent

# Agent-Specific Indexing
MEILISEARCH_AUTO_DETECT_SEARCH_NEEDS=true     # Smart detection based on allowedTools
MEILISEARCH_PRIORITY_AGENTS="storm-coordinator,critical-agent"  # Always pre-index these
```

---

## Code Changes Summary

### Files to Create

1. `src/server/services/MeilisearchBackgroundIndexer.ts` - Background indexing service
2. `src/server/api/routes/meilisearch.ts` - Pre-load API endpoints
3. `src/sdk/services/MxfAgentPool.ts` - Agent pool implementation (optional)

### Files to Modify

1. `src/sdk/MxfSDK.ts` - Add `preloadAgentHistory()` method
2. `src/sdk/MxfAgent.ts` - Add history search detection
3. `src/server/socket/services/AgentService.ts` - Add smart flagging + priority queue
4. `src/shared/protocols/mcp/tools/MemorySearchTools.ts` - Add channel filter
5. `examples/solar-storm-demo/solar-storm-demo.ts` - Update prompt + optionally use preload
6. `src/shared/services/MxfMeilisearchService.ts` - Add batch embedding support

### New Events

```typescript
// Add to EventNames.ts
export const MeilisearchEvents = {
    BACKFILL_PROGRESS: 'meilisearch:backfill:progress',  // For progress updates
    PRELOAD_REQUESTED: 'meilisearch:preload:requested',  // SDK requests preload
    PRIORITY_QUEUE_UPDATED: 'meilisearch:priority:updated' // Queue status
}
```

---

## Testing Strategy

### Unit Tests

1. **Smart Detection**:
   - Agent with `allowedTools: ['memory_search_conversations']` → Detected
   - Agent with `allowedTools: []` → Detected (gets core tools)
   - Agent with `allowedTools: ['task_create']` → Not detected
   - Agent with `allowedTools: undefined` → Detected (gets core tools)

2. **Background Indexer**:
   - Pre-index 100 messages → Verify all indexed
   - Check index status → Return accurate counts
   - Concurrent indexing → No race conditions

3. **SDK Pre-Load**:
   - Call preload → Wait for completion → Create agent
   - Timeout handling → Graceful degradation
   - Progress callbacks → Accurate counts

### Integration Tests

1. **Solar Storm Demo**:
   - Run demo with 300 message history
   - Verify memory_search available immediately
   - Verify search returns relevant results

2. **Multi-Agent Scenario**:
   - 3 agents, different history sizes (0, 100, 500 messages)
   - All should work correctly based on their needs

### Load Tests

1. **Concurrent Indexing**:
   - 10 agents connecting simultaneously
   - All with 200+ message histories
   - Verify server handles load without degradation

---

## Migration Path

### For Existing Applications

**No Breaking Changes**:
- Current behavior maintained as default
- Tools still filtered until indexing complete
- Prompts guide agents to handle unavailable tools

**Opt-In Enhancements**:
```typescript
// Option 1: Use SDK pre-load (explicit)
await sdk.preloadAgentHistory(agentId, channelId);

// Option 2: Enable background indexing (server config)
// Set MEILISEARCH_BACKGROUND_INDEXING=true

// Option 3: Use agent pool (advanced)
const pool = new MxfAgentPool();
await pool.warmPool([config]);
```

---

## Open Questions

1. **Index Persistence**: How long to cache "already indexed" status?
   - Option A: Until new messages detected (check on connect)
   - Option B: Fixed TTL (1 hour)
   - Option C: Invalidate on agent disconnect

2. **Priority Queue**: How to prioritize when multiple agents need indexing?
   - Option A: FIFO (first come, first served)
   - Option B: By message count (smallest first for quick wins)
   - Option C: By agent metadata (critical agents first)

3. **Resource Limits**: How many concurrent indexing jobs?
   - Current: Unlimited (could overwhelm server)
   - Proposed: 5 concurrent jobs max
   - Queue others until slots available

4. **Embedding Provider**: Should we support local embeddings for speed?
   - OpenAI API: 580ms/message (current)
   - Local model (sentence-transformers): ~50ms/message
   - Trade-off: Speed vs. quality

5. **Search Tool Availability During Indexing**: Should we provide a degraded version?
   - Option A: Remove tools until 100% complete (current)
   - Option B: Allow search but warn "indexing in progress, results partial"
   - Option C: Provide keyword-only search until semantic ready

---

## Related Issues

### Multi-Channel Security

**Current Filter** (`MemorySearchTools.ts:108`):
```typescript
if (context.agentId) {
    filter = `agentId = "${context.agentId}"`;
}
```

**Security Concern**: Should also filter by channel to prevent cross-channel history leaks:
```typescript
let filter = `agentId = "${context.agentId}"`;
if (context.channelId) {
    filter += ` AND channelId = "${context.channelId}"`;
}
```

**Recommendation**: Add channel isolation as part of this enhancement.

---

## Metrics to Track

### Success Metrics

1. **Indexing Latency**:
   - Before: Agent connects → 2-5 min wait → Tools available
   - After: Agent connects → Tools available immediately (if pre-indexed)
   - Target: <10 seconds for 90% of agents

2. **Tool Availability**:
   - Before: 60-80% of agents have memory_search unavailable on first task
   - After: 95%+ of agents have it available (via pre-indexing)

3. **Developer Experience**:
   - Survey: "How often do you work around indexing delays?"
   - Target: <5% of developers need workarounds

### Performance Metrics

1. **Embedding Generation**:
   - Current: 580ms per message
   - Target (with batching): 50-100ms per message
   - Improvement: 5-10x faster

2. **Server Resource Usage**:
   - CPU during background indexing
   - Memory for index status cache
   - Network bandwidth for embedding API calls

---

## Conclusion

The Meilisearch indexing timing issue is solvable through multiple approaches. The recommended **hybrid strategy** provides:

1. **Immediate relief**: Prompt fixes (works now)
2. **Smart automation**: Auto-detection and priority queue (no dev changes needed)
3. **Explicit control**: SDK pre-load API (for critical use cases)
4. **Production optimization**: Background indexing (for recurring agents)

**Next Steps**:
1. Implement prompt fix for solar-storm-demo ✅ Ready to merge
2. Prototype smart detection + priority queue ⏭️ Next sprint
3. Design SDK pre-load API 📋 Backlog
4. Evaluate batch embedding optimization 🔬 Research

---

## Appendix: Alternative Considered

### "Just Make It Fast" Approach

**Idea**: Use local embedding model instead of OpenAI API

**Implementation**:
```typescript
import { pipeline } from '@xenova/transformers';

const embedder = await pipeline('feature-extraction',
    'Xenova/all-MiniLM-L6-v2'
);

// Generate embeddings locally (~50ms per message)
const embedding = await embedder(text, { pooling: 'mean', normalize: true });
```

**Performance**:
- 300 messages × 50ms = 15 seconds (vs. 174 seconds)
- **11x faster!**

**Trade-offs**:
- Lower quality embeddings (384 dimensions vs. 1536)
- Requires model download (~90MB)
- CPU intensive
- Different from OpenAI embeddings (can't mix)

**Recommendation**: Consider for on-premise deployments where OpenAI API isn't available.

---

**Document Version**: 1.0
**Last Updated**: 2025-11-11
**Author**: Claude Code + Brad Anderson
**Status**: Design Proposal - Awaiting Review
