# MXF Code Execution Implementation Plan
## Enhancing MXF with Anthropic's MCP Code Execution Patterns

**Date:** November 5, 2024
**Status:** Proposal
**Priority:** High
**Estimated Timeline:** 7-10 weeks
**Reference:** [Anthropic Engineering - Code Execution with MCP](https://www.anthropic.com/engineering/code-execution-with-mcp)

---

> **Important Context:** This plan complements MXF's existing optimization stack (MXP 2.0, Meilisearch, tool-aware prompts). MXP already provides 60-80% token reduction and 70-90% bandwidth reduction. Code execution adds a **fourth optimization layer** focused on workflow execution efficiency, not token optimization.

---

## Executive Summary

This plan outlines the implementation of code execution capabilities in MXF, following Anthropic's proven patterns for efficient agent-MCP interaction. By enabling agents to write and execute code for complex workflows, we can achieve:

- **60-75% reduction in multi-step workflow latency** (15-50s → 7-12s by eliminating model round-trips)
- **75% reduction in API calls for multi-step tasks** (N calls → 1 call + sandbox execution)
- **Enhanced data processing** (filter/transform datasets locally without model involvement)
- **Complex control flow** (loops, conditionals, error handling in native JavaScript)
- **Workflow persistence** (save proven patterns as reusable "Skills")

### Key Innovation

**MXF already has excellent tool discovery** (tool-aware prompts, `tools_recommend`, semantic search). This enhancement focuses on a different problem: **multi-step workflows**.

Instead of executing workflows as sequential tool calls with model coordination:
```
Agent → Model → Tool Call 1 → Model → Tool Call 2 → Model → Tool Call 3
(5-10 seconds per step = 15-30s total)
```

Agents write TypeScript code that composes tools and executes workflows in a sandboxed environment:
```
Agent → Model writes code → Sandbox executes all steps → Final result to Model
(Sub-second execution, no model round-trips)
```

### Quick Comparison: Current MXF vs Code Execution

| Scenario | Current MXF | With Code Execution | Improvement |
|----------|-------------|---------------------|-------------|
| **Token optimization** | MXP 2.0: 60-80% reduction ✅ | Same ✅ | No change (keep MXP) |
| **Tool discovery** | tools_recommend + tool-aware prompts ✅ | Same ✅ | No change (keep as-is) |
| **Single tool call** | Fast & efficient ✅ | Same ✅ | No change (keep as-is) |
| **Multi-step workflow (3-5 steps)** | 3-5 LLM calls = 15-30s | 1 LLM call + local execution = ~2s | **90% faster execution** |
| **Large dataset filtering** | Data through model (MXP compressed) | Filter in sandbox, return final only | **Eliminate intermediate passes** |
| **Control flow (loops)** | N model calls (MXP optimized) | Execute loop locally | **N→1 LLM calls** |
| **Data transformations** | Describe to model → tool calls | JavaScript in sandbox | **Native operations** |
| **Workflow reuse** | Manual recreation | Save as "Skill" | **New capability** |
| **Bandwidth optimization** | MXP 2.0: 70-90% reduction ✅ | Same ✅ | No change (keep MXP) |

**Key Insight:** Code execution complements MXP 2.0. MXP optimizes communication and tokens. Code execution optimizes workflow execution by eliminating model round-trips for multi-step operations.

---

## Current State Analysis

### MXF Strengths (Foundation Already Exists)

#### Core Infrastructure
✅ **Hybrid Tool System**: 81+ internal tools + external MCP servers
✅ **MongoDB + Redis**: Persistent storage and caching infrastructure
✅ **n8n Integration**: Workflow automation platform
✅ **Docker Stack**: Production-ready containerization with 6 services

#### Token & Performance Optimization (Already Excellent!)
✅ **MXP 2.0 Protocol**: 60-80% token reduction through:
  - Context compression using SystemLLM
  - Prompt optimization and template matching
  - Entity deduplication
  - **Tool schema reduction** (smart prompting)
  - Conversation summarization
  - 70-90% bandwidth reduction with binary encoding

✅ **Intelligent Tool Discovery**:
  - `tools_recommend` (AI-powered via SystemLLM)
  - `tools_discover` (interactive exploration)
  - Tool-aware prompts - agents **never** load all 81 tools into context

✅ **Meilisearch Integration**: 87% prompt reduction for semantic search
  - Search conversations, actions, patterns
  - Hybrid keyword + semantic search
  - Sub-50ms query latency

✅ **Pattern Learning**: Continuous optimization and knowledge sharing

#### Quality & Reliability
✅ **SystemLLM Service**: AI-powered reasoning, validation, code generation
✅ **Proactive Validation**: Pre-execution validation with <50ms latency
✅ **Auto-Correction**: >80% success rate fixing parameter errors
✅ **ML Error Prediction**: >70% accuracy predicting failures

### Current Workflow Limitations (What We're Solving)

**Important:** MXF already has excellent token optimization via MXP 2.0 (60-80% reduction) and Meilisearch (87% for search). Code execution solves a **different** problem: **workflow execution efficiency**.

❌ **Sequential Multi-Step Workflows**: Each tool call requires model round-trip
  - Example: Search → Filter → Send message = 3 model calls (15-30s total)
  - MXP optimizes the tokens, but still requires 3 separate LLM calls

❌ **Intermediate Data Through Model**: Even with MXP compression, large datasets must pass through model
  - Example: Search returns 1000 items → model processes → filters to 5
  - MXP reduces token cost, but data still flows through LLM

❌ **No Local Data Processing**: Can't execute JavaScript operations in execution environment
  - Example: Can't run `.filter()`, `.map()`, `.reduce()` on datasets
  - Must describe transformations to model, which executes via tool calls

❌ **Limited Control Flow**: Loops and conditionals require model coordination
  - Example: "For each agent, send a message" = N tool calls with model in loop
  - MXP optimizes each call, but doesn't eliminate the loop overhead

❌ **No Workflow Persistence**: Can't save multi-step workflows as reusable code patterns
  - Agents must recreate workflows each time
  - No "Skills" library for common operations

❌ **PII in Multi-Step Operations**: Sensitive data visible during model coordination
  - Example: Email addresses in intermediate filtering steps
  - Tokenization would help but adds complexity

**Example Current Flow:**
```typescript
// Step 1: Agent asks model to search
await executeTool('memory_search_conversations', { query: 'auth' });
// → Returns 1000 results to model (thousands of tokens)

// Step 2: Model processes, decides to filter
// → Another model call, more latency

// Step 3: Model asks to send messages
await executeTool('messaging_send', { ... });
// → Each step: 5-10s latency

// Total: 15-30s for 3-step workflow
```

**What Code Execution Enables:**
```typescript
// Agent writes code once, executes locally
const results = await searchConversations({ query: 'auth', limit: 1000 });
const filtered = results.filter(r => r.score > 0.8); // Local processing
const top5 = filtered.slice(0, 5); // Only 5 returned to model

for (const result of top5) {
  await sendMessage({ content: result.summary }); // Loop locally
}

return { processed: top5.length }; // Single result to model

// Total: ~2s execution, no model round-trips
```

---

## Architecture Overview

### System Components

```
┌─────────────────────────────────────────────────────────────┐
│                   Agent with LLM                            │
│                                                              │
│  Option 1: Single Tool Call (KEEP - already works great)    │
│  → executeTool('search_conversations', {})                  │
│                                                              │
│  Option 2: Multi-Step Workflow (NEW - code execution)       │
│  → executeCode(`                                            │
│      const results = await searchConversations({});         │
│      const filtered = results.filter(...);                  │
│      return filtered;                                       │
│    `)                                                       │
│                                                              │
└────────────────────┬───────────────────────────────────────┘
                     │
        ┌────────────┴────────────┐
        │                         │
        ▼                         ▼
┌──────────────────┐   ┌──────────────────────┐
│ EXISTING (KEEP)  │   │ NEW (ADD)            │
│                  │   │                      │
│ Direct Tool      │   │ Code Execution       │
│ Execution        │   │ Sandbox              │
│ • Single calls   │   │ • Multi-tool flows   │
│ • tools_recommend│   │ • Data processing    │
│ • tools_discover │   │ • Control flow       │
│ • Fast & simple  │   │ • vm2/isolated-vm    │
└────────┬─────────┘   └────────┬─────────────┘
         │                      │
         │             ┌────────┴──────────┐
         │             │                   │
         │             ▼                   ▼
         │     ┌──────────────┐   ┌──────────────┐
         │     │ Tool-as-Code │   │ Skill Library│
         │     │ Wrappers     │   │ (MongoDB)    │
         │     │ • Type-safe  │   │ • Reusable   │
         │     └──────┬───────┘   └──────────────┘
         │            │
         └────────────┴─────────────────┐
                      │                 │
                      ▼                 ▼
              ┌──────────────────────────────────┐
              │  PII Tokenization Layer (NEW)    │
              │  • Tokenize before LLM           │
              │  • Untokenize for tools          │
              └────────────┬─────────────────────┘
                           │
                           ▼
              ┌──────────────────────────────────┐
              │  Existing MXF Tool System        │
              │  • 81+ internal tools            │
              │  • External MCP servers          │
              │  • Meilisearch, MongoDB, Redis   │
              └──────────────────────────────────┘
```

### Integration Philosophy

**Keep What Works:**
- ✅ Direct tool execution for single operations
- ✅ `tools_recommend` for AI-powered discovery
- ✅ `tools_discover` for interactive exploration
- ✅ Tool-aware prompts (no context bloat)

**Add What's Missing:**
- ➕ Code execution for multi-step workflows
- ➕ Local data processing capabilities
- ➕ Workflow persistence as "Skills"
- ➕ PII tokenization for sensitive data

---

## Implementation Phases

## Phase 1: Foundation & Code Execution (Weeks 1-3)

### 1.1 Basic Code Execution Sandbox

**File:** `src/shared/services/CodeExecutionSandboxService.ts`

```typescript
interface SandboxConfig {
  timeout: number;           // Max execution time (ms)
  memoryLimit: number;       // Max memory (MB)
  allowedModules: string[];  // Whitelisted imports
  toolAccess: string[];      // Allowed MCP tools
}

interface ExecutionResult {
  success: boolean;
  output: any;
  logs: string[];
  executionTime: number;
  resourceUsage: {
    memory: number;
    cpu: number;
  };
  error?: string;
}

class CodeExecutionSandboxService {
  private vm: any; // vm2 or isolated-vm instance

  async executeCode(
    code: string,
    context: SandboxContext,
    config: SandboxConfig
  ): Promise<ExecutionResult> {
    // Validate code before execution
    await this.validateCode(code);

    // Create isolated sandbox
    const sandbox = this.createSandbox(context, config);

    // Execute with timeout and resource limits
    const result = await this.runInSandbox(sandbox, code, config);

    // Log execution metrics
    await this.logExecution(result);

    return result;
  }

  private createSandbox(
    context: SandboxContext,
    config: SandboxConfig
  ) {
    return {
      // Provide only whitelisted tools
      tools: this.createToolProxies(config.toolAccess),

      // Utility functions
      console: this.createConsoleProxy(),

      // Limited Node.js APIs
      setTimeout,
      setInterval,

      // Context from agent
      agentId: context.agentId,
      channelId: context.channelId,
      memory: context.memory
    };
  }

  private async validateCode(code: string): Promise<void> {
    // AST analysis for malicious patterns
    // Resource consumption estimation
    // Security policy checks
    // Throws if validation fails
  }
}
```

**Security Features:**
1. **Resource Limits**: CPU, memory, execution time
2. **Module Whitelist**: Only approved imports allowed
3. **Tool Access Control**: Per-agent permissions
4. **AST Analysis**: Detect dangerous patterns
5. **Audit Logging**: All executions logged

**Technology Choice: vm2 vs isolated-vm**

| Feature | vm2 | isolated-vm |
|---------|-----|-------------|
| **Isolation** | Good | Excellent |
| **Performance** | Fast | Very Fast |
| **Setup** | Simple | Complex |
| **Memory Control** | Limited | Precise |
| **Recommendation** | Phase 1 | Phase 3 |

**Phase 1 Decision:** Start with **vm2** for rapid prototyping, migrate to **isolated-vm** in Phase 3 for production hardening.

**Deliverables:**
- ✅ CodeExecutionSandboxService implementation
- ✅ Resource limit enforcement
- ✅ Security validation pipeline
- ✅ Audit logging system
- ✅ Error handling and recovery
- ✅ Integration tests with malicious code samples

---

### 1.2 Tool-as-Code Wrappers (Top 20 Tools)

**File Structure:**
```
src/shared/protocols/mcp/tool-wrappers/
├── index.ts              # Export all wrappers
├── memory/
│   ├── searchConversations.ts
│   ├── searchActions.ts
│   └── searchPatterns.ts
├── messaging/
│   ├── sendMessage.ts
│   ├── broadcastMessage.ts
│   └── getMessages.ts
├── agents/
│   ├── listAgents.ts
│   └── getAgentInfo.ts
└── channels/
    ├── listChannels.ts
    └── getChannelInfo.ts
```

**Example Wrapper:**
```typescript
// src/shared/protocols/mcp/tool-wrappers/memory/searchConversations.ts

import { MemorySearchToolInput, MemorySearchResult } from '../../types';
import { MxfMeilisearchService } from '../../../services/MxfMeilisearchService';

/**
 * Search conversation history semantically
 *
 * @example
 * const results = await searchConversations({
 *   query: 'authentication discussion',
 *   channelId: 'dev-channel',
 *   limit: 5
 * });
 */
export async function searchConversations(
  input: MemorySearchToolInput
): Promise<MemorySearchResult[]> {
  const service = MxfMeilisearchService.getInstance();

  return await service.searchConversations({
    query: input.query,
    filter: input.channelId ? `channelId = "${input.channelId}"` : undefined,
    limit: input.limit || 10,
    hybridRatio: input.hybridRatio || 0.7
  });
}

// Type-safe exports
export type SearchConversationsInput = MemorySearchToolInput;
export type SearchConversationsResult = MemorySearchResult[];
```

**Agent Usage:**
```typescript
// Instead of this (old way):
const result1 = await agent.executeTool('memory_search_conversations', {
  query: 'authentication',
  limit: 5
});
const result2 = await agent.executeTool('memory_search_actions', {
  query: 'send message',
  limit: 5
});
// ... wait for model response, then continue

// Agents write this (new way):
const code = `
import { searchConversations, searchActions } from './memory';

async function analyzeAuthenticationWorkflow() {
  // Execute in parallel, no model round-trip
  const [conversations, actions] = await Promise.all([
    searchConversations({ query: 'authentication', limit: 5 }),
    searchActions({ query: 'send message', limit: 5 })
  ]);

  // Process locally, no token cost
  const relevantActions = actions.filter(a =>
    conversations.some(c => c.content.includes(a.toolName))
  );

  // Return only final summary
  return {
    totalConversations: conversations.length,
    relevantActions: relevantActions.length,
    recommendation: 'Use JWT tokens based on conversation patterns'
  };
}

return await analyzeAuthenticationWorkflow();
`;

// Execute and get final result
const result = await agent.executeCode(code);
```

**Priority Tools for Phase 1:**

1. **Memory Search** (3 tools)
   - `searchConversations`
   - `searchActions`
   - `searchPatterns`

2. **Messaging** (3 tools)
   - `sendMessage`
   - `broadcastMessage`
   - `getMessages`

3. **Agent Operations** (4 tools)
   - `listAgents`
   - `getAgentInfo`
   - `updateAgentStatus`
   - `findAgents`

4. **Channel Operations** (4 tools)
   - `listChannels`
   - `getChannelInfo`
   - `joinChannel`
   - `leaveChannel`

5. **Task Management** (3 tools)
   - `createTask`
   - `updateTaskStatus`
   - `listTasks`

6. **Control Loop** (3 tools)
   - `getCurrentPhase`
   - `transitionPhase`
   - `getLoopMetrics`

**Deliverables:**
- ✅ 20 tool-as-code wrappers
- ✅ TypeScript definitions and JSDoc
- ✅ Usage examples for each tool
- ✅ Integration with sandbox service
- ✅ Documentation generator
- ✅ Unit tests for all wrappers

---

## Phase 2: Core Features (Weeks 4-7)

### 2.1 Complete Tool-as-Code System (All 81+ Tools)

Expand Phase 1 wrappers to cover all tools:

**Categories:**
1. ✅ Memory & Search (6 tools)
2. ✅ Messaging & Communication (8 tools)
3. ✅ Agent Operations (10 tools)
4. ✅ Channel Management (8 tools)
5. ✅ Task Management (9 tools)
6. ✅ Control Loop (7 tools)
7. ✅ Meta Tools (11 tools)
8. ✅ Validation Tools (8 tools)
9. ✅ Analytics (7 tools)
10. ✅ Infrastructure (7 tools)

**Automated Wrapper Generation:**

```typescript
// tools/generate-wrappers.ts
class ToolWrapperGenerator {
  async generateWrapper(tool: McpTool): Promise<string> {
    // Parse tool schema
    // Generate TypeScript types
    // Create wrapper function
    // Add JSDoc with examples
    // Export with proper types

    return `
/**
 * ${tool.description}
 *
 * @category ${tool.category}
 * ${this.generateParamDocs(tool.inputSchema)}
 * ${this.generateExamples(tool.examples)}
 */
export async function ${tool.name}(
  input: ${this.generateInputType(tool)}
): Promise<${this.generateOutputType(tool)}> {
  // Implementation
}
    `.trim();
  }
}
```

**Deliverables:**
- ✅ 81+ tool wrappers (automated generation)
- ✅ Comprehensive type definitions
- ✅ Category-based organization
- ✅ Auto-generated documentation
- ✅ Validation for all wrappers
- ✅ Regression test suite

---

### 2.2 Skill Persistence System

**File:** `src/shared/services/SkillPersistenceService.ts`

```typescript
interface Skill {
  id: string;
  name: string;
  description: string;
  category: string;
  code: string;
  language: 'typescript' | 'javascript';

  // Metadata
  author: string;           // Agent ID
  createdAt: Date;
  updatedAt: Date;
  version: number;

  // Usage tracking
  usageCount: number;
  successRate: number;
  avgExecutionTime: number;

  // Dependencies
  requiredTools: string[];
  requiredSkills: string[];

  // Examples
  examples: SkillExample[];

  // Learning data
  effectiveness: number;    // 0-1 score
  feedback: SkillFeedback[];
}

interface SkillExample {
  description: string;
  input: any;
  output: any;
  executionTime: number;
}

class SkillPersistenceService {
  async saveSkill(skill: Skill): Promise<string> {
    // Validate skill code
    await this.validateSkill(skill);

    // Save to MongoDB
    const skillDoc = await SkillModel.create(skill);

    // Index in Meilisearch for semantic search
    await this.indexSkill(skillDoc);

    // Update agent's skill library
    await this.updateAgentSkills(skill.author, skillDoc.id);

    return skillDoc.id;
  }

  async searchSkills(query: string, options: {
    category?: string;
    minEffectiveness?: number;
    author?: string;
    limit?: number;
  }): Promise<Skill[]> {
    // Semantic search via Meilisearch
    const results = await MxfMeilisearchService.getInstance()
      .searchIndex('mxf-skills', query, {
        filter: this.buildFilter(options),
        limit: options.limit || 10
      });

    return results.hits;
  }

  async executeSkill(
    skillId: string,
    input: any,
    context: ExecutionContext
  ): Promise<SkillExecutionResult> {
    // Load skill from database
    const skill = await this.getSkill(skillId);

    // Execute in sandbox
    const result = await CodeExecutionSandboxService.getInstance()
      .executeCode(skill.code, context, {
        timeout: 30000,
        memoryLimit: 256,
        allowedModules: skill.requiredTools,
        toolAccess: skill.requiredTools
      });

    // Update usage metrics
    await this.updateSkillMetrics(skillId, result);

    return result;
  }

  async learnFromExecution(
    skillId: string,
    execution: ExecutionResult,
    feedback: SkillFeedback
  ): Promise<void> {
    // Update effectiveness score
    // Add example if successful
    // Suggest improvements via SystemLLM
    // Update search index
  }
}
```

**Skill YAML Format:**

```yaml
# skills/multi-agent-coordination/SKILL.md
name: multi-agent-coordination
version: 1.2.0
author: AgentOrchestrator
category: coordination

description: |
  Coordinates multiple agents to solve complex tasks through
  intelligent task decomposition and result aggregation.

required_tools:
  - listAgents
  - sendMessage
  - createTask
  - searchConversations

required_skills:
  - task-decomposition
  - result-aggregation

examples:
  - description: Coordinate research across 3 agents
    input:
      topic: "AI safety frameworks"
      agentCount: 3
    output:
      tasksCreated: 3
      resultsAggregated: true
      completionTime: 45000

effectiveness: 0.94
usage_count: 127
avg_execution_time: 38000
```

**Agent Usage:**

```typescript
// Discover and use skills
const skills = await agent.searchSkills('coordinate multiple agents');

// Execute skill
const result = await agent.executeSkill(skills[0].id, {
  topic: 'authentication patterns',
  agentCount: 3
});

// Save new skill
await agent.saveSkill({
  name: 'semantic-search-workflow',
  description: 'Search conversations, filter, and summarize',
  code: `
    async function semanticSearchWorkflow(query) {
      const results = await searchConversations({ query, limit: 20 });
      const filtered = results.filter(r => r.relevanceScore > 0.8);
      const summary = filtered.map(r => r.content).join('\\n');
      return { count: filtered.length, summary };
    }
  `,
  category: 'search',
  requiredTools: ['searchConversations']
});
```

**Deliverables:**
- ✅ SkillPersistenceService implementation
- ✅ MongoDB schema for skills
- ✅ Meilisearch skill index
- ✅ SKILL.md format specification
- ✅ Skill execution tracking
- ✅ Learning and improvement system
- ✅ Skill sharing across agents
- ✅ Documentation and examples

---

### 2.3 Enhanced Code Validation

**File:** `src/shared/services/CodeValidationService.ts`

```typescript
interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
  suggestions: string[];
  securityScore: number;
  estimatedCost: {
    executionTime: number;
    memory: number;
    apiCalls: number;
  };
}

class CodeValidationService {
  async validateCode(code: string): Promise<ValidationResult> {
    const results = await Promise.all([
      this.syntaxValidation(code),
      this.securityValidation(code),
      this.resourceEstimation(code),
      this.dependencyValidation(code),
      this.styleValidation(code)
    ]);

    return this.aggregateResults(results);
  }

  private async securityValidation(code: string): Promise<ValidationResult> {
    // Parse AST
    const ast = this.parseCode(code);

    // Check for dangerous patterns
    const dangerousPatterns = [
      'eval(',
      'Function(',
      'child_process',
      'fs.unlink',
      '__proto__',
      'process.exit'
    ];

    const found = this.detectPatterns(ast, dangerousPatterns);

    // Dynamic analysis via SystemLLM
    const llmAnalysis = await this.analyzeSecurity(code);

    return {
      valid: found.length === 0,
      errors: found,
      securityScore: this.calculateScore(found, llmAnalysis)
    };
  }

  private async resourceEstimation(code: string): Promise<EstimationResult> {
    // Analyze loops, recursion, API calls
    // Estimate execution time and memory
    // Predict tool usage and costs

    return {
      estimatedTime: 5000,      // ms
      estimatedMemory: 50,       // MB
      estimatedApiCalls: 3,
      estimatedCost: 0.002       // USD
    };
  }

  private async dependencyValidation(code: string): Promise<ValidationResult> {
    // Extract imports
    const imports = this.extractImports(code);

    // Verify all tools exist
    const missing = await this.checkToolAvailability(imports);

    // Check permissions
    const unauthorized = await this.checkToolPermissions(imports);

    return {
      valid: missing.length === 0 && unauthorized.length === 0,
      errors: [...missing, ...unauthorized]
    };
  }
}
```

**Integration with Auto-Correction:**

```typescript
class CodeAutoCorrectionService {
  async correctCode(
    code: string,
    validationErrors: ValidationError[]
  ): Promise<CorrectionResult> {
    // Use SystemLLM to fix common issues
    const corrected = await SystemLlmService.getInstance().chat({
      messages: [{
        role: 'user',
        content: `Fix these validation errors in the code:

Code:
\`\`\`typescript
${code}
\`\`\`

Errors:
${validationErrors.map(e => `- ${e.message}`).join('\n')}

Return only the corrected code, no explanations.`
      }],
      model: 'claude-3-haiku',
      temperature: 0.3
    });

    // Re-validate corrected code
    const validation = await CodeValidationService.getInstance()
      .validateCode(corrected);

    return {
      code: corrected,
      validation,
      corrections: this.diffCode(code, corrected)
    };
  }
}
```

**Deliverables:**
- ✅ CodeValidationService implementation
- ✅ AST-based security analysis
- ✅ Resource estimation engine
- ✅ Dependency validation
- ✅ Style checking
- ✅ Auto-correction integration
- ✅ Comprehensive test suite

---

## Phase 3: Enterprise & Security (Weeks 8-10)

### 3.1 PII Tokenization Service

**File:** `src/shared/services/PIITokenizationService.ts`

```typescript
interface TokenizationConfig {
  enabledPatterns: PIIPattern[];
  tokenPrefix: string;
  storageLocation: 'memory' | 'redis' | 'mongodb';
  ttl: number; // Time to live in seconds
}

type PIIPattern =
  | 'email'
  | 'phone'
  | 'ssn'
  | 'credit_card'
  | 'ip_address'
  | 'api_key'
  | 'custom';

interface TokenMapping {
  token: string;
  originalValue: string;
  pattern: PIIPattern;
  createdAt: Date;
  expiresAt: Date;
}

class PIITokenizationService {
  private tokenMap: Map<string, TokenMapping> = new Map();

  async tokenize(data: any, config: TokenizationConfig): Promise<any> {
    // Deep clone to avoid mutation
    const tokenized = this.deepClone(data);

    // Apply patterns
    for (const pattern of config.enabledPatterns) {
      await this.applyPattern(tokenized, pattern);
    }

    return tokenized;
  }

  private async applyPattern(data: any, pattern: PIIPattern): Promise<void> {
    const regex = this.getPatternRegex(pattern);

    const traverse = (obj: any) => {
      if (typeof obj === 'string') {
        return obj.replace(regex, (match) => {
          const token = this.generateToken(pattern);
          this.storeMapping(token, match, pattern);
          return token;
        });
      } else if (Array.isArray(obj)) {
        return obj.map(traverse);
      } else if (typeof obj === 'object' && obj !== null) {
        const result: any = {};
        for (const [key, value] of Object.entries(obj)) {
          result[key] = traverse(value);
        }
        return result;
      }
      return obj;
    };

    return traverse(data);
  }

  async untokenize(data: any): Promise<any> {
    const untokenized = this.deepClone(data);

    const traverse = (obj: any) => {
      if (typeof obj === 'string') {
        // Check if it's a token
        if (this.isToken(obj)) {
          const mapping = this.getMapping(obj);
          return mapping ? mapping.originalValue : obj;
        }
        return obj;
      } else if (Array.isArray(obj)) {
        return obj.map(traverse);
      } else if (typeof obj === 'object' && obj !== null) {
        const result: any = {};
        for (const [key, value] of Object.entries(obj)) {
          result[key] = traverse(value);
        }
        return result;
      }
      return obj;
    };

    return traverse(data);
  }

  private getPatternRegex(pattern: PIIPattern): RegExp {
    const patterns: Record<PIIPattern, RegExp> = {
      email: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g,
      phone: /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g,
      ssn: /\b\d{3}-\d{2}-\d{4}\b/g,
      credit_card: /\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b/g,
      ip_address: /\b(?:\d{1,3}\.){3}\d{1,3}\b/g,
      api_key: /\b[A-Za-z0-9]{32,}\b/g,
      custom: /CUSTOM_PATTERN/g
    };

    return patterns[pattern];
  }

  private generateToken(pattern: PIIPattern): string {
    return `{{TOKEN_${pattern.toUpperCase()}_${this.generateId()}}}`;
  }

  private storeMapping(token: string, value: string, pattern: PIIPattern): void {
    this.tokenMap.set(token, {
      token,
      originalValue: value,
      pattern,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 3600000) // 1 hour
    });
  }
}
```

**Integration Example:**

```typescript
// Before sending to LLM
const agentData = {
  message: 'Contact john.doe@example.com at 555-123-4567',
  apiKey: 'sk_live_abc123xyz789'
};

const tokenized = await PIITokenizationService.getInstance().tokenize(
  agentData,
  {
    enabledPatterns: ['email', 'phone', 'api_key'],
    tokenPrefix: 'PII',
    storageLocation: 'redis',
    ttl: 3600
  }
);

// Sent to LLM:
// {
//   message: 'Contact {{TOKEN_EMAIL_001}} at {{TOKEN_PHONE_001}}',
//   apiKey: '{{TOKEN_API_KEY_001}}'
// }

// When executing tools, untokenize
const realData = await PIITokenizationService.getInstance().untokenize(
  tokenized
);
// Real data restored for tool execution
```

**Deliverables:**
- ✅ PIITokenizationService implementation
- ✅ Regex patterns for common PII types
- ✅ Redis storage for tokens
- ✅ Automatic expiration
- ✅ Custom pattern support
- ✅ Audit logging
- ✅ GDPR compliance documentation

---

### 3.2 Advanced Security Policies

**File:** `src/shared/services/SecurityPolicyService.ts`

```typescript
interface SecurityPolicy {
  id: string;
  name: string;
  level: 'standard' | 'enhanced' | 'regulated' | 'classified';

  // Code execution restrictions
  allowedModules: string[];
  deniedPatterns: string[];
  maxExecutionTime: number;
  maxMemory: number;

  // Data flow rules
  allowDataExfiltration: boolean;
  allowedDataDestinations: string[];
  requireEncryption: boolean;

  // Tool permissions
  allowedTools: string[];
  deniedTools: string[];
  requireApproval: string[]; // Tools requiring human approval

  // Audit requirements
  logAllExecutions: boolean;
  requireHumanReview: boolean;
  alertOnViolations: boolean;
}

class SecurityPolicyService {
  async enforcePolicy(
    policy: SecurityPolicy,
    code: string,
    context: ExecutionContext
  ): Promise<PolicyEnforcementResult> {
    // Check code compliance
    const codeCheck = await this.checkCodeCompliance(code, policy);

    // Check context permissions
    const contextCheck = await this.checkContextPermissions(context, policy);

    // Check data flow
    const dataFlowCheck = await this.checkDataFlow(code, policy);

    if (!codeCheck.compliant || !contextCheck.compliant || !dataFlowCheck.compliant) {
      return {
        allowed: false,
        violations: [
          ...codeCheck.violations,
          ...contextCheck.violations,
          ...dataFlowCheck.violations
        ]
      };
    }

    // Log if required
    if (policy.logAllExecutions) {
      await this.logExecution(code, context, policy);
    }

    // Request approval if required
    if (policy.requireHumanReview) {
      await this.requestApproval(code, context);
    }

    return { allowed: true, violations: [] };
  }

  async checkDataFlow(code: string, policy: SecurityPolicy): Promise<DataFlowResult> {
    // Analyze data destinations in code
    const destinations = this.extractDataDestinations(code);

    // Check against allowed destinations
    const violations = destinations.filter(dest =>
      !policy.allowedDataDestinations.includes(dest)
    );

    return {
      compliant: violations.length === 0,
      violations: violations.map(v => ({
        type: 'unauthorized_data_destination',
        destination: v,
        severity: 'high'
      }))
    };
  }
}
```

**Pre-defined Policies:**

```typescript
const SECURITY_POLICIES = {
  standard: {
    level: 'standard',
    allowedModules: ['*'],
    maxExecutionTime: 30000,
    maxMemory: 256,
    allowDataExfiltration: true,
    logAllExecutions: false,
    requireHumanReview: false
  },

  enhanced: {
    level: 'enhanced',
    allowedModules: ['./tools/*'],
    deniedPatterns: ['eval', 'Function'],
    maxExecutionTime: 15000,
    maxMemory: 128,
    allowDataExfiltration: true,
    allowedDataDestinations: ['internal-tools', 'approved-apis'],
    logAllExecutions: true,
    requireHumanReview: false
  },

  regulated: {
    level: 'regulated',
    allowedModules: ['./tools/memory', './tools/messaging'],
    deniedPatterns: ['eval', 'Function', 'process', 'require'],
    maxExecutionTime: 10000,
    maxMemory: 64,
    allowDataExfiltration: false,
    requireEncryption: true,
    logAllExecutions: true,
    requireHumanReview: true,
    alertOnViolations: true
  },

  classified: {
    level: 'classified',
    allowedModules: [], // No imports
    allowedTools: ['messaging_send'], // Whitelist only
    deniedPatterns: ['.*'], // Deny all dynamic code
    maxExecutionTime: 5000,
    maxMemory: 32,
    allowDataExfiltration: false,
    requireEncryption: true,
    requireApproval: ['*'], // All tools require approval
    logAllExecutions: true,
    requireHumanReview: true,
    alertOnViolations: true
  }
};
```

**Deliverables:**
- ✅ SecurityPolicyService implementation
- ✅ 4 pre-defined policy levels
- ✅ Policy enforcement engine
- ✅ Data flow analysis
- ✅ Human-in-the-loop approval system
- ✅ Violation alerting
- ✅ Compliance reporting

---

### 3.3 Production Hardening

**Upgrade to isolated-vm:**

```typescript
import ivm from 'isolated-vm';

class IsolatedVMSandbox {
  async executeCode(code: string, config: SandboxConfig): Promise<ExecutionResult> {
    // Create isolated VM with memory limit
    const isolate = new ivm.Isolate({ memoryLimit: config.memoryLimit });

    // Create context
    const context = await isolate.createContext();

    // Inject tools as transferable functions
    const jail = context.global;
    await jail.set('global', jail.derefInto());

    // Add tool proxies
    for (const tool of config.allowedTools) {
      await this.injectTool(jail, tool);
    }

    // Compile and run with timeout
    const script = await isolate.compileScript(code);
    const result = await script.run(context, {
      timeout: config.timeout,
      reference: true
    });

    // Clean up
    isolate.dispose();

    return result;
  }
}
```

**Resource Monitoring:**

```typescript
class ResourceMonitoringService {
  async monitorExecution(executionId: string): Promise<ResourceMetrics> {
    return {
      cpu: await this.getCpuUsage(executionId),
      memory: await this.getMemoryUsage(executionId),
      io: await this.getIOUsage(executionId),
      network: await this.getNetworkUsage(executionId)
    };
  }

  async enforceResourceLimits(
    executionId: string,
    limits: ResourceLimits
  ): Promise<void> {
    const metrics = await this.monitorExecution(executionId);

    if (metrics.memory > limits.maxMemory) {
      await this.killExecution(executionId, 'memory_limit_exceeded');
    }

    if (metrics.cpu > limits.maxCpu) {
      await this.throttleExecution(executionId);
    }
  }
}
```

**Deliverables:**
- ✅ isolated-vm integration
- ✅ Resource monitoring service
- ✅ Automatic limit enforcement
- ✅ Performance benchmarks
- ✅ Load testing results
- ✅ Production deployment guide

---

## Integration with Existing MXF Components

### 1. MxfClient SDK Integration

```typescript
// New methods on MxfClient
class MxfClient {
  // EXISTING: Keep all current tool discovery methods
  // - executeTool('tools_recommend', { objective: '...' })
  // - executeTool('tools_discover', { category: '...' })
  // These already work great!

  // NEW: Code execution for multi-step workflows
  async executeCode(code: string, config?: SandboxConfig): Promise<ExecutionResult> {
    return this.emit('code:execute', { code, config });
  }

  // NEW: Skill management
  async saveSkill(skill: Skill): Promise<string> {
    return this.emit('skill:save', { skill });
  }

  async searchSkills(query: string): Promise<Skill[]> {
    return this.executeTool('skill_search', { query });
  }

  async executeSkill(skillId: string, input: any): Promise<any> {
    return this.emit('skill:execute', { skillId, input });
  }
}
```

### 2. Dashboard UI Components

**New Dashboard Pages:**

1. **Code Execution Monitor** (`/dashboard/code-execution`)
   - Real-time execution logs
   - Resource usage graphs
   - Error tracking
   - Performance metrics

2. **Skill Library** (`/dashboard/skills`)
   - Browse and search skills
   - View skill details and examples
   - Edit and test skills
   - Track usage and effectiveness

3. **Security Policies** (`/dashboard/security`)
   - Configure security policies
   - Review approval requests
   - Audit log viewer
   - Violation alerts

### 3. SystemLLM Prompts

**Enhanced Agent System Prompt:**

```markdown
You can write TypeScript code to execute complex workflows efficiently:

## Available Tools
Search tools semantically: `searchTools(query)` returns relevant tools
Discover 81+ tools without loading all definitions into context

## Code Execution
Write TypeScript code using tool-as-code pattern:

```typescript
import { searchConversations, sendMessage } from './tools';

async function analyzeAndRespond() {
  const results = await searchConversations({ query: 'bug reports' });
  const critical = results.filter(r => r.priority === 'critical');

  for (const bug of critical) {
    await sendMessage({
      channelId: 'dev-channel',
      content: `Critical bug found: ${bug.summary}`
    });
  }

  return { processed: critical.length };
}
```

## Skills
Save reusable code patterns:
- `saveSkill(name, code)` - Save for future use
- `searchSkills(query)` - Find existing patterns
- `executeSkill(id, input)` - Run saved skill

## Best Practices
1. Use code for multi-step workflows (faster, cheaper)
2. Return only final results (not intermediate data)
3. Process data in code (filter, transform, aggregate)
4. Save effective patterns as skills
```

---

## Testing Strategy

### Unit Tests

```typescript
describe('CodeExecutionSandboxService', () => {
  it('should execute simple code', async () => {
    const result = await sandbox.executeCode('return 1 + 1');
    expect(result.output).toBe(2);
  });

  it('should enforce timeout limits', async () => {
    const code = 'while(true) {}';
    await expect(sandbox.executeCode(code, { timeout: 1000 }))
      .rejects.toThrow('Execution timeout');
  });

  it('should enforce memory limits', async () => {
    const code = 'const arr = []; while(true) arr.push(new Array(1000000))';
    await expect(sandbox.executeCode(code, { memoryLimit: 10 }))
      .rejects.toThrow('Memory limit exceeded');
  });

  it('should prevent dangerous code', async () => {
    const code = 'require("child_process").exec("rm -rf /")';
    await expect(sandbox.executeCode(code))
      .rejects.toThrow('Security violation');
  });
});

describe('SkillPersistenceService', () => {
  it('should save and retrieve skills', async () => {
    const skillId = await skills.saveSkill({
      name: 'test-skill',
      code: 'return "hello"'
    });

    const skill = await skills.getSkill(skillId);
    expect(skill.name).toBe('test-skill');
  });

  it('should search skills semantically', async () => {
    const results = await skills.searchSkills('coordinate agents');
    expect(results.length).toBeGreaterThan(0);
    expect(results[0].category).toBe('coordination');
  });
});

describe('PIITokenizationService', () => {
  it('should tokenize emails', async () => {
    const data = { email: 'test@example.com' };
    const tokenized = await pii.tokenize(data, {
      enabledPatterns: ['email']
    });

    expect(tokenized.email).toMatch(/{{TOKEN_EMAIL_\d+}}/);
  });

  it('should untokenize data', async () => {
    const data = { email: 'test@example.com' };
    const tokenized = await pii.tokenize(data, { enabledPatterns: ['email'] });
    const untokenized = await pii.untokenize(tokenized);

    expect(untokenized.email).toBe('test@example.com');
  });
});
```

### Integration Tests

```typescript
describe('End-to-End Code Execution', () => {
  it('should execute multi-tool workflow', async () => {
    const code = `
      import { searchConversations, sendMessage } from './tools';

      const results = await searchConversations({ query: 'test' });
      await sendMessage({
        channelId: 'test-channel',
        content: \`Found \${results.length} results\`
      });

      return results.length;
    `;

    const result = await agent.executeCode(code);
    expect(result.success).toBe(true);
    expect(typeof result.output).toBe('number');
  });

  it('should save and execute skills', async () => {
    const skillId = await agent.saveSkill({
      name: 'count-agents',
      code: `
        import { listAgents } from './tools';
        const agents = await listAgents();
        return agents.length;
      `
    });

    const result = await agent.executeSkill(skillId, {});
    expect(result.output).toBeGreaterThan(0);
  });
});
```

### Load Tests

```typescript
describe('Performance Tests', () => {
  it('should handle 100 concurrent executions', async () => {
    const executions = Array(100).fill(null).map(() =>
      sandbox.executeCode('return Math.random()')
    );

    const results = await Promise.all(executions);
    expect(results.every(r => r.success)).toBe(true);
  });

  it('should maintain <50ms p95 latency', async () => {
    const latencies = [];

    for (let i = 0; i < 1000; i++) {
      const start = Date.now();
      await sandbox.executeCode('return 1');
      latencies.push(Date.now() - start);
    }

    const p95 = percentile(latencies, 95);
    expect(p95).toBeLessThan(50);
  });
});
```

---

## Monitoring & Observability

### Metrics to Track

**Execution Metrics:**
- Executions per minute
- Average execution time
- Success/failure rate
- Resource usage (CPU, memory)
- Tool calls per execution
- Code size distribution

**Cost Metrics:**
- Token savings vs. traditional approach
- Execution cost (compute resources)
- API call reduction
- Total cost per agent

**Security Metrics:**
- Policy violations
- Security scans performed
- PII tokens created
- Approval requests
- Sandbox escapes attempted

### Dashboard Graphs

```typescript
// Real-time execution monitor
interface ExecutionDashboard {
  activeExecutions: number;
  queuedExecutions: number;
  executionsPerMinute: TimeSeries;
  resourceUsage: {
    cpu: number;
    memory: number;
  };
  recentExecutions: ExecutionLog[];
  errorRate: number;
}

// Skill analytics
interface SkillAnalytics {
  totalSkills: number;
  skillsByCategory: Record<string, number>;
  topSkills: SkillRanking[];
  skillUsageTrend: TimeSeries;
  averageEffectiveness: number;
}
```

---

## Migration Strategy

### Phase-by-Phase Rollout

**Week 1-2: Internal Testing**
- Deploy to staging environment
- Test with non-production agents
- Gather performance metrics
- Fix critical bugs

**Week 3-4: Beta Testing**
- Enable for 10% of agents
- Monitor for issues
- Collect feedback
- Iterate on UX

**Week 5-6: Gradual Rollout**
- Increase to 50% of agents
- Monitor cost savings
- Track adoption rate
- Provide training materials

**Week 7-8: Full Deployment**
- Enable for 100% of agents
- Deprecate old tool-calling pattern (optional)
- Update documentation
- Celebrate launch 🎉

### Backward Compatibility

```typescript
// Old way still works
const result = await agent.executeTool('searchConversations', { query: 'test' });

// New way (recommended)
const result = await agent.executeCode(`
  import { searchConversations } from './tools';
  return await searchConversations({ query: 'test' });
`);

// Agents can choose based on use case
```

---

## Cost-Benefit Analysis

### Expected Benefits

**Important Context:** MXF already has MXP 2.0 providing 60-80% token reduction and 70-90% bandwidth reduction. Code execution adds **execution efficiency**, not token optimization.

**1. Execution Latency Reduction (Primary Benefit)**
- Current: Multi-step workflow = 3-5 LLM API calls with model coordination
  - Each call: 5-10s (model reasoning + tool execution)
  - Total: 15-50s for 3-5 step workflow
- With code execution: 1 LLM call to write code + local execution
  - Model writes code once: 5-10s
  - Sandbox executes all steps: <2s
  - Total: ~7-12s for same workflow
- **Benefit: 60-75% latency reduction for multi-step workflows**

**2. API Call Reduction (Cost Savings)**
- Current: N-step workflow = N LLM API calls (even with MXP optimization)
  - Example: 5-step workflow = 5 API calls × $0.006/call = $0.03
  - MXP reduces tokens per call, but doesn't reduce call count
- With code execution: 1 LLM call + sandbox compute
  - Example: 1 API call × $0.006 + $0.001 sandbox = $0.007
  - **Savings: ~75% cost reduction for multi-step workflows**

**3. Data Processing Efficiency**
- Current: Even with MXP compression, intermediate data flows through model
  - Example: 1000 search results → model → filter to 5
  - MXP compresses tokens, but model still processes dataset
- With code execution: Process data in sandbox
  - Example: 1000 results filtered locally → only 5 to model
  - **Benefit: No model involvement in data transformations**

**4. Complex Control Flow**
- Current: Loops/conditionals require model coordination
  - Example: "Send message to 10 agents" = 10 model-coordinated calls
- With code execution: Native JavaScript control flow
  - Example: `for (agent of agents) { await sendMessage(...) }`
  - **Benefit: Programming language features without model overhead**

**5. Workflow Persistence (New Capability)**
- Agents can save proven workflows as "Skills"
- Reuse across agents and channels
- Build library of optimized patterns
- **Benefit: Accelerate future development**

**6. Developer Experience**
- Familiar programming constructs (loops, async/await, try/catch)
- Type-safe tool composition
- Local debugging and testing
- **Benefit: Easier to build complex agent behaviors**

### Costs

**Development:**
- Phase 1: 3 weeks × $200/hour × 40 hours = $24,000
- Phase 2: 4 weeks × $200/hour × 40 hours = $32,000
- Phase 3: 3 weeks × $200/hour × 40 hours = $24,000
- **Total: $80,000**

**Infrastructure:**
- Sandbox compute: ~$500/month
- Storage (skills): ~$50/month
- Monitoring: ~$100/month
- **Total: ~$650/month**

### ROI Calculation

**Assumptions:**
- 1,000 agents × 10 multi-step workflows/day = 10,000 workflows
- Average workflow: 4 tool calls with intermediate data processing
- Each workflow currently costs: ~$0.03 (tokens + API calls)
- With code execution: ~$0.012 (60% reduction)

**Monthly Calculations:**
- Current cost: 10,000 workflows/day × $0.03 × 30 days = **$9,000/month**
- With code execution: 10,000 workflows/day × $0.012 × 30 days = **$3,600/month**
- **Monthly savings: $5,400/month**
- **Annual savings: $64,800/year**

**Additional Benefits (not monetized):**
- 90% latency reduction = better user experience
- Enable complex workflows previously not feasible
- Skill library accelerates future development

**Payback period: ~15 months** (conservative estimate)

**Note:** ROI increases significantly with:
- Higher agent count
- More complex workflows (5+ steps)
- Larger datasets requiring processing
- Adoption of skill reuse across agents

---

## Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|---------|-----------|
| **Sandbox escape** | Low | Critical | Use isolated-vm, regular security audits |
| **Resource exhaustion** | Medium | High | Resource limits, monitoring, auto-scaling |
| **Code injection** | Medium | High | AST validation, SystemLLM review |
| **PII leakage** | Low | Critical | Tokenization, audit logging, encryption |
| **Performance degradation** | Low | Medium | Load testing, caching, optimization |
| **Skill quality issues** | Medium | Low | Effectiveness tracking, community review |

---

## Success Metrics

### Phase 1 Success Criteria
- [ ] Tool discovery reduces context by >80%
- [ ] Sandbox executes code safely with 0 escapes
- [ ] 20 tool wrappers implemented and tested
- [ ] Documentation complete and reviewed

### Phase 2 Success Criteria
- [ ] 81+ tool wrappers deployed
- [ ] 50+ skills created by agents
- [ ] Skill search has >90% relevance
- [ ] Code validation catches >95% of security issues

### Phase 3 Success Criteria
- [ ] PII tokenization covers all common patterns
- [ ] Security policies enforced with 0 violations
- [ ] Production deployment completes successfully
- [ ] Performance meets SLA (<50ms p95 latency)

### Overall Success Metrics (6 months post-launch)
- [ ] >70% of agents using code execution
- [ ] >$30K/month cost savings
- [ ] >90% reduction in multi-step latency
- [ ] >500 community-contributed skills
- [ ] 0 security incidents

---

## Documentation Plan

### Developer Docs
1. **Code Execution Guide** - How to write code for agents
2. **Tool-as-Code Reference** - Complete API documentation
3. **Skill Development Guide** - Creating reusable skills
4. **Security Best Practices** - Safe code patterns
5. **Migration Guide** - Moving from tool calls to code

### API Docs
1. **CodeExecutionSandboxService API**
2. **SkillPersistenceService API**
3. **PIITokenizationService API**
4. **SecurityPolicyService API**

### User Docs
1. **Agent Guide** - Using code execution effectively
2. **Skill Library** - Browse and use community skills
3. **Dashboard Tutorial** - Monitoring code execution
4. **Troubleshooting** - Common issues and solutions

---

## Conclusion

This implementation plan enhances MXF's already-excellent architecture with code execution capabilities for multi-step workflows. By following Anthropic's proven patterns, we can:

✅ **Reduce multi-step workflow latency by 60-75%** (15-50s → 7-12s by eliminating model round-trips)
✅ **Reduce API calls by 75%** for multi-step workflows (N calls → 1 call + sandbox)
✅ **Enable local data processing** without passing through model (even with MXP compression)
✅ **Enable complex control flow** (loops, conditionals) in native JavaScript
✅ **Enable skill persistence and sharing** across agents for workflow reuse
✅ **Maintain enterprise-grade security** with sandboxing and PII protection

**MXF's Existing Strengths (Keep & Leverage):**
- ✅ **MXP 2.0**: 60-80% token reduction, 70-90% bandwidth reduction
- ✅ **Intelligent tool discovery**: `tools_recommend`, `tools_discover`, tool-aware prompts
- ✅ **Meilisearch**: 87% prompt reduction for semantic search
- ✅ **SystemLLM**: AI-powered reasoning and code generation
- ✅ **Validation pipeline**: Proactive validation & auto-correction
- ✅ **Production infrastructure**: Docker, MongoDB, Redis, n8n

**New Capabilities (Add to Complete the Stack):**
- ➕ **Code execution sandbox**: Multi-step workflows without model round-trips
- ➕ **Local data processing**: JavaScript transformations in execution environment
- ➕ **Workflow persistence**: Reusable "Skills" library
- ➕ **PII tokenization**: Enhanced privacy for multi-step operations

**The Complete Optimization Stack:**
1. **MXP 2.0** → Optimizes tokens and bandwidth (messaging layer)
2. **Tool-aware prompts** → Optimizes tool discovery (prompt layer)
3. **Meilisearch** → Optimizes memory retrieval (data layer)
4. **Code execution** → Optimizes workflow execution (execution layer) ← NEW

**Next Steps:**
1. Review and approve this plan
2. Assemble development team
3. Set up staging environment
4. Begin Phase 1 implementation (sandbox + tool wrappers)
5. Track metrics and iterate

**Estimated Timeline:** 7-10 weeks
**Estimated Cost:** $80,000 development + $650/month operations
**Expected ROI:** $64,800/year savings (15-month payback, conservative)

**Note:** ROI improves significantly with scale and adoption of complex workflows.

---

**Questions or Feedback?** Let's discuss this plan and refine it based on your priorities and constraints.
