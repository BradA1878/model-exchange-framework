# MXF LSP-MCP Bridge Integration

## Requirements Specification v1.0

**Status:** Draft
**Author:** Brad Anderson
**Date:** December 2025
**MXF Version Target:** 2.x
**Estimated Effort:** 6-8 weeks (MVP) / 10-14 weeks (Full)

---

## Executive Summary

This document specifies the integration of Language Server Protocol (LSP) capabilities into the MXF framework via an LSP-MCP Bridge. The bridge exposes language intelligence features (go-to-definition, find-references, diagnostics, completions, hover, rename) as MCP tools that agents can invoke for precise, semantic code understanding.

The integration addresses a critical gap in MXF's current developer tools: the existing code analysis tools use regex/pattern-based heuristics rather than true semantic understanding. By leveraging production-grade language servers (typescript-language-server, pylsp, gopls), MXF agents gain access to the same code intelligence that powers modern IDEs.

**Key Benefits:**
- Real-time diagnostics without manual tool invocation
- Precise go-to-definition and find-references (not regex approximations)
- Intelligent code completions for code generation tasks
- Safe, project-wide refactoring via rename operations
- Multi-language extensibility through a single abstraction

---

## 1. Problem Statement

### 1.1 Current State

MXF provides developer tools via internal MCP tools, but they have significant limitations:

| Tool | Current Approach | Limitation |
|------|------------------|------------|
| `typescript_check` | Invokes `tsc` via shell | Batch-only, no incremental, slow feedback |
| `find_functions` | Regex pattern matching | Misses edge cases, no type awareness |
| `trace_dependencies` | String-based import parsing | Doesn't resolve aliases, barrel exports, or re-exports |
| `suggest_refactoring` | Heuristic line-count analysis | No cyclomatic complexity, no AST understanding |
| `validate_architecture` | Import path pattern matching | Can't trace through type-only imports or dynamic imports |

**Root Cause:** All tools operate on text patterns rather than semantic program understanding.

### 1.2 Desired State

- Agents invoke `lsp_goto_definition` and receive precise source locations
- Agents receive real-time diagnostics without explicit tool calls
- Code completions are context-aware (available symbols, types, imports)
- Rename operations update all references across the entire project
- Multi-language support via pluggable language server backends
- Graceful degradation when LSP servers are unavailable

### 1.3 Why LSP?

The Language Server Protocol is a battle-tested standard:
- **Battle-tested**: Powers VS Code, Neovim, Emacs, and 50+ editors
- **Multi-language**: Same interface for TypeScript, Python, Go, Rust, etc.
- **Rich features**: 20+ language intelligence capabilities
- **Active ecosystem**: Community-maintained servers for every major language
- **Incremental**: Efficient for large codebases via differential sync

---

## 2. Architecture Overview

### 2.1 Layer Model

```
┌─────────────────────────────────────────────────────────────────┐
│                      MXF AGENT LAYER                            │
│   Agents invoke MCP tools: lsp_goto_definition, lsp_hover...   │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                  HYBRID MCP TOOL REGISTRY                       │
│   Routes tool calls to internal or external handlers            │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │              LSP TOOLS (new internal tools)             │   │
│   │   • lsp_goto_definition    • lsp_find_references        │   │
│   │   • lsp_diagnostics        • lsp_completions            │   │
│   │   • lsp_hover              • lsp_rename                 │   │
│   │   • lsp_document_symbols   • lsp_workspace_symbols      │   │
│   └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                      LSP SERVICE LAYER (new)                    │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │              LspServerManager                           │   │
│   │   • Server lifecycle (spawn, health, restart)           │   │
│   │   • Connection pooling by project root                  │   │
│   │   • Circuit breaker + exponential backoff               │   │
│   └─────────────────────────────────────────────────────────┘   │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │              LspDocumentManager                         │   │
│   │   • Open document tracking (didOpen/didChange/didClose) │   │
│   │   • Incremental or full sync modes                      │   │
│   │   • Document version management                         │   │
│   └─────────────────────────────────────────────────────────┘   │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │              LspProtocolAdapter                         │   │
│   │   • JSON-RPC message encoding/decoding                  │   │
│   │   • Request/response correlation                        │   │
│   │   • Notification handling (diagnostics, logs)           │   │
│   └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                   LANGUAGE SERVER LAYER                         │
│   ┌────────────────┐  ┌────────────────┐  ┌────────────────┐   │
│   │ typescript-    │  │    pylsp       │  │    gopls       │   │
│   │ language-server│  │   (Python)     │  │     (Go)       │   │
│   │   (TS/JS)      │  │                │  │                │   │
│   └────────────────┘  └────────────────┘  └────────────────┘   │
│                                                                 │
│   Communication: stdio (primary) | TCP socket (optional)        │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Integration Points

| Component | Role | Integration Method |
|-----------|------|-------------------|
| `HybridMcpToolRegistry` | Tool registration and discovery | Register LspTools at startup |
| `ExternalMcpServerManager` | Lifecycle patterns | Reuse circuit breaker, health monitoring |
| `McpToolDocumentationService` | Tool help and examples | Add LSP tool documentation |
| `tools_recommend` | Intelligent tool selection | Recommend LSP tools for code navigation intents |
| `ValidationCacheService` | Caching pattern | Cache LSP responses (diagnostics, symbols) |
| `EventBus` | System events | Emit LSP lifecycle events |

### 2.3 Data Flow: Go-to-Definition Example

```
┌──────────┐    ┌──────────────┐    ┌─────────────┐    ┌──────────────┐
│  Agent   │───>│ lsp_goto_    │───>│ LspServer   │───>│ typescript-  │
│          │    │ definition   │    │ Manager     │    │ language-srv │
└──────────┘    └──────────────┘    └─────────────┘    └──────────────┘
                      │                    │                   │
                      │  1. Resolve        │  2. Ensure        │
                      │     project root   │     server alive  │
                      │                    │                   │
                      │                    │  3. Open doc      │
                      │                    │     (if needed)   │
                      │                    │                   │
                      │                    │  4. Send request  │
                      │                    │<──────────────────│
                      │                    │  5. Location[]    │
                      │<───────────────────│                   │
                      │  6. Format result  │                   │
                      │                    │                   │
```

---

## 3. Functional Requirements

### 3.1 Core LSP Operations

**FR-001**: The system SHALL provide an `lsp_goto_definition` tool that returns the source location(s) of a symbol's definition.

**FR-002**: The system SHALL provide an `lsp_find_references` tool that returns all locations where a symbol is referenced.

**FR-003**: The system SHALL provide an `lsp_diagnostics` tool that returns errors, warnings, and hints for a file.

**FR-004**: The system SHALL provide an `lsp_completions` tool that returns context-aware code completions at a position.

**FR-005**: The system SHALL provide an `lsp_hover` tool that returns type information and documentation for a symbol.

**FR-006**: The system SHALL provide an `lsp_rename` tool that returns all edits required to rename a symbol across the project.

**FR-007**: The system SHALL provide an `lsp_document_symbols` tool that returns the symbol outline for a file.

**FR-008**: The system SHALL provide an `lsp_workspace_symbols` tool that searches for symbols across the entire workspace.

### 3.2 Document Management

**FR-009**: The system SHALL track which documents are "open" in each language server session.

**FR-010**: The system SHALL support both full and incremental document synchronization modes.

**FR-011**: The system SHALL automatically open a document before performing operations that require it.

**FR-012**: The system SHALL close documents that have not been accessed for a configurable timeout period.

**FR-013**: The system SHALL handle document version numbers correctly for incremental sync.

### 3.3 Server Lifecycle Management

**FR-014**: The system SHALL spawn language servers on-demand when first LSP operation is requested.

**FR-015**: The system SHALL maintain a pool of language server instances, keyed by project root path.

**FR-016**: The system SHALL implement health checks with configurable intervals (default: 30 seconds).

**FR-017**: The system SHALL automatically restart crashed language servers with exponential backoff.

**FR-018**: The system SHALL implement circuit breakers to prevent cascading failures.

**FR-019**: The system SHALL gracefully shut down language servers on MXF shutdown.

**FR-020**: The system SHALL support configurable maximum concurrent language server instances.

### 3.4 Multi-Language Support

**FR-021**: The system SHALL support TypeScript/JavaScript via `typescript-language-server`.

**FR-022**: The system SHALL support Python via `pylsp` or `pyright` (configurable).

**FR-023**: The system SHALL support Go via `gopls`.

**FR-024**: The system SHALL provide an extension point for adding additional language servers.

**FR-025**: The system SHALL automatically detect file language from extension and route to appropriate server.

### 3.5 Integration with Existing Tools

**FR-026**: The `tools_recommend` meta-tool SHALL recommend LSP tools for code navigation intents.

**FR-027**: The system SHALL emit EventBus events for LSP operations (for analytics tracking).

**FR-028**: LSP tools SHALL follow the same input validation patterns as existing MCP tools.

**FR-029**: LSP tool errors SHALL be handled by `tools_recommend_on_error` for recovery suggestions.

**FR-030**: LSP operation results SHALL be indexable by Meilisearch for semantic memory search.

---

## 4. Non-Functional Requirements

### 4.1 Performance

**NFR-001**: Language server initialization SHALL complete within 5 seconds for a typical project.

**NFR-002**: Go-to-definition operations SHALL complete within 500ms for cached documents.

**NFR-003**: Diagnostics for a single file SHALL return within 2 seconds.

**NFR-004**: The system SHALL cache diagnostic results with configurable TTL (default: 5 seconds).

**NFR-005**: Memory usage per language server instance SHALL not exceed 512MB under normal operation.

**NFR-006**: The system SHALL support at least 10 concurrent language server instances.

### 4.2 Reliability

**NFR-007**: Language server crashes SHALL NOT cause MXF server crashes.

**NFR-008**: Operations SHALL timeout after configurable duration (default: 30 seconds).

**NFR-009**: Failed operations SHALL be retryable via standard MXF retry patterns.

**NFR-010**: The system SHALL implement graceful degradation when language servers are unavailable.

**NFR-011**: Fallback to existing regex-based tools SHALL occur when LSP is unavailable.

### 4.3 Security

**NFR-012**: Language servers SHALL only access files within configured workspace roots.

**NFR-013**: File paths in LSP responses SHALL be validated against allowed directory patterns.

**NFR-014**: Code execution capabilities (if any) in language servers SHALL be disabled.

**NFR-015**: Language server binaries SHALL be sourced from trusted package registries (npm, pip, go modules).

### 4.4 Observability

**NFR-016**: The system SHALL emit structured logs for all LSP operations.

**NFR-017**: The system SHALL expose metrics:
- `mxf_lsp_operations_total{operation,language,status}`
- `mxf_lsp_operation_duration_seconds{operation,language}`
- `mxf_lsp_servers_active{language}`
- `mxf_lsp_server_restarts_total{language}`

**NFR-018**: The system SHALL integrate with the existing MXF analytics dashboard.

**NFR-019**: The system SHALL track LSP operation success rates per agent for pattern learning.

---

## 5. Technical Specification

### 5.1 New Interfaces

```typescript
// src/shared/services/lsp/interfaces/ILspServerManager.ts

export interface ILspServerManager {
  /**
   * Get or create a language server for the given project and language.
   */
  getServer(projectRoot: string, language: SupportedLanguage): Promise<ILspConnection>;

  /**
   * Shutdown a specific language server.
   */
  shutdownServer(projectRoot: string, language: SupportedLanguage): Promise<void>;

  /**
   * Shutdown all language servers.
   */
  shutdownAll(): Promise<void>;

  /**
   * Get health status of all active servers.
   */
  getHealthStatus(): LspHealthStatus[];

  /**
   * Register a custom language server configuration.
   */
  registerLanguageServer(config: LanguageServerConfig): void;
}

export interface ILspConnection {
  /**
   * Send a request to the language server.
   */
  request<T>(method: string, params: unknown): Promise<T>;

  /**
   * Send a notification to the language server.
   */
  notify(method: string, params: unknown): void;

  /**
   * Subscribe to server notifications.
   */
  onNotification(method: string, handler: (params: unknown) => void): Disposable;

  /**
   * Check if the connection is healthy.
   */
  isHealthy(): boolean;

  /**
   * Close the connection.
   */
  close(): Promise<void>;
}

export interface LanguageServerConfig {
  language: string;
  command: string;
  args: string[];
  env?: Record<string, string>;
  initializationOptions?: unknown;
  capabilities?: Partial<ClientCapabilities>;
}

export type SupportedLanguage =
  | 'typescript'
  | 'javascript'
  | 'python'
  | 'go'
  | 'rust'
  | string; // Allow custom languages

export interface LspHealthStatus {
  projectRoot: string;
  language: SupportedLanguage;
  status: 'healthy' | 'unhealthy' | 'starting' | 'stopped';
  pid?: number;
  lastHealthCheck: Date;
  uptime: number;
  requestCount: number;
  errorCount: number;
}
```

```typescript
// src/shared/services/lsp/interfaces/ILspDocumentManager.ts

export interface ILspDocumentManager {
  /**
   * Open a document in the language server.
   */
  openDocument(uri: string, languageId: string, content: string): Promise<void>;

  /**
   * Update an open document (incremental or full).
   */
  updateDocument(uri: string, changes: TextDocumentContentChangeEvent[]): Promise<void>;

  /**
   * Close a document.
   */
  closeDocument(uri: string): Promise<void>;

  /**
   * Check if a document is open.
   */
  isDocumentOpen(uri: string): boolean;

  /**
   * Get the current version of an open document.
   */
  getDocumentVersion(uri: string): number | undefined;

  /**
   * Ensure a document is open, reading from disk if needed.
   */
  ensureDocumentOpen(filePath: string): Promise<void>;
}

export interface TextDocumentContentChangeEvent {
  range?: Range;
  rangeLength?: number;
  text: string;
}

export interface Range {
  start: Position;
  end: Position;
}

export interface Position {
  line: number;      // 0-indexed
  character: number; // 0-indexed (UTF-16 code units)
}
```

### 5.2 LSP Tool Definitions

```typescript
// src/shared/protocols/mcp/tools/LspTools.ts

import { McpToolDefinition } from '../../types/toolTypes';

export const lspTools: McpToolDefinition[] = [
  {
    name: 'lsp_goto_definition',
    description: 'Navigate to the definition of a symbol at a specific location in a file',
    inputSchema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          description: 'Absolute path to the source file'
        },
        line: {
          type: 'number',
          description: 'Line number (1-indexed)'
        },
        character: {
          type: 'number',
          description: 'Character position in the line (1-indexed)'
        }
      },
      required: ['file', 'line', 'character']
    },
    examples: [
      {
        input: {
          file: '/project/src/services/UserService.ts',
          line: 42,
          character: 15
        },
        description: 'Find the definition of the symbol at line 42, character 15'
      }
    ],
    metadata: {
      category: 'lsp',
      timeout: 30000,
      tags: ['code-navigation', 'semantic-analysis']
    }
  },

  {
    name: 'lsp_find_references',
    description: 'Find all references to a symbol across the entire project',
    inputSchema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          description: 'Absolute path to the source file'
        },
        line: {
          type: 'number',
          description: 'Line number (1-indexed)'
        },
        character: {
          type: 'number',
          description: 'Character position in the line (1-indexed)'
        },
        includeDeclaration: {
          type: 'boolean',
          description: 'Include the declaration in results (default: true)',
          default: true
        }
      },
      required: ['file', 'line', 'character']
    },
    examples: [
      {
        input: {
          file: '/project/src/utils/helpers.ts',
          line: 10,
          character: 20,
          includeDeclaration: true
        },
        description: 'Find all usages of the function defined at line 10'
      }
    ],
    metadata: {
      category: 'lsp',
      timeout: 60000, // Longer timeout for project-wide search
      tags: ['code-navigation', 'refactoring', 'impact-analysis']
    }
  },

  {
    name: 'lsp_diagnostics',
    description: 'Get real-time errors, warnings, and hints for a file',
    inputSchema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          description: 'Absolute path to the source file'
        },
        severity: {
          type: 'string',
          enum: ['error', 'warning', 'information', 'hint', 'all'],
          description: 'Filter by severity level (default: all)',
          default: 'all'
        }
      },
      required: ['file']
    },
    examples: [
      {
        input: {
          file: '/project/src/components/Button.tsx',
          severity: 'error'
        },
        description: 'Get only errors for the Button component'
      }
    ],
    metadata: {
      category: 'lsp',
      timeout: 10000,
      tags: ['validation', 'type-checking', 'linting']
    }
  },

  {
    name: 'lsp_completions',
    description: 'Get context-aware code completions at a specific position',
    inputSchema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          description: 'Absolute path to the source file'
        },
        line: {
          type: 'number',
          description: 'Line number (1-indexed)'
        },
        character: {
          type: 'number',
          description: 'Character position in the line (1-indexed)'
        },
        triggerCharacter: {
          type: 'string',
          description: 'Character that triggered completion (e.g., ".", ":")',
          maxLength: 1
        },
        limit: {
          type: 'number',
          description: 'Maximum number of completions to return (default: 50)',
          default: 50
        }
      },
      required: ['file', 'line', 'character']
    },
    examples: [
      {
        input: {
          file: '/project/src/index.ts',
          line: 25,
          character: 10,
          triggerCharacter: '.',
          limit: 20
        },
        description: 'Get completions after typing a dot'
      }
    ],
    metadata: {
      category: 'lsp',
      timeout: 5000,
      tags: ['code-generation', 'autocomplete']
    }
  },

  {
    name: 'lsp_hover',
    description: 'Get type information and documentation for a symbol',
    inputSchema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          description: 'Absolute path to the source file'
        },
        line: {
          type: 'number',
          description: 'Line number (1-indexed)'
        },
        character: {
          type: 'number',
          description: 'Character position in the line (1-indexed)'
        }
      },
      required: ['file', 'line', 'character']
    },
    examples: [
      {
        input: {
          file: '/project/src/types.ts',
          line: 15,
          character: 8
        },
        description: 'Get type information for the symbol at line 15'
      }
    ],
    metadata: {
      category: 'lsp',
      timeout: 5000,
      tags: ['documentation', 'type-information']
    }
  },

  {
    name: 'lsp_rename',
    description: 'Compute all edits required to rename a symbol across the project',
    inputSchema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          description: 'Absolute path to the source file'
        },
        line: {
          type: 'number',
          description: 'Line number (1-indexed)'
        },
        character: {
          type: 'number',
          description: 'Character position in the line (1-indexed)'
        },
        newName: {
          type: 'string',
          description: 'New name for the symbol'
        },
        preview: {
          type: 'boolean',
          description: 'Only preview changes, do not apply (default: true)',
          default: true
        }
      },
      required: ['file', 'line', 'character', 'newName']
    },
    examples: [
      {
        input: {
          file: '/project/src/services/api.ts',
          line: 5,
          character: 15,
          newName: 'fetchUserData',
          preview: true
        },
        description: 'Preview renaming a function to fetchUserData'
      }
    ],
    metadata: {
      category: 'lsp',
      timeout: 60000,
      tags: ['refactoring', 'code-modification']
    }
  },

  {
    name: 'lsp_document_symbols',
    description: 'Get the symbol outline for a file (functions, classes, variables)',
    inputSchema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          description: 'Absolute path to the source file'
        }
      },
      required: ['file']
    },
    examples: [
      {
        input: {
          file: '/project/src/controllers/AuthController.ts'
        },
        description: 'Get all symbols defined in AuthController'
      }
    ],
    metadata: {
      category: 'lsp',
      timeout: 10000,
      tags: ['code-navigation', 'documentation']
    }
  },

  {
    name: 'lsp_workspace_symbols',
    description: 'Search for symbols across the entire workspace',
    inputSchema: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: 'Symbol name query (supports fuzzy matching)'
        },
        projectRoot: {
          type: 'string',
          description: 'Project root directory (defaults to current workspace)'
        },
        limit: {
          type: 'number',
          description: 'Maximum number of results (default: 100)',
          default: 100
        }
      },
      required: ['query']
    },
    examples: [
      {
        input: {
          query: 'UserService',
          limit: 50
        },
        description: 'Find all symbols matching "UserService"'
      }
    ],
    metadata: {
      category: 'lsp',
      timeout: 30000,
      tags: ['code-navigation', 'search']
    }
  }
];
```

### 5.3 Configuration Schema

```typescript
// src/shared/types/lspConfig.ts

export interface MxfLspConfig {
  enabled: boolean;

  servers: {
    typescript: TypeScriptServerConfig;
    python?: PythonServerConfig;
    go?: GoServerConfig;
    custom?: CustomServerConfig[];
  };

  document: {
    syncMode: 'full' | 'incremental';
    idleCloseTimeout: number;  // ms, default: 300000 (5 min)
    maxOpenDocuments: number;  // default: 50
  };

  lifecycle: {
    healthCheckInterval: number;  // ms, default: 30000
    startupTimeout: number;       // ms, default: 30000
    shutdownTimeout: number;      // ms, default: 10000
    maxInstances: number;         // default: 10
    restartPolicy: {
      maxRetries: number;         // default: 3
      backoffMultiplier: number;  // default: 2
      initialDelay: number;       // ms, default: 1000
      maxDelay: number;           // ms, default: 30000
    };
  };

  cache: {
    enabled: boolean;
    diagnosticsTtl: number;    // ms, default: 5000
    symbolsTtl: number;        // ms, default: 60000
    completionsTtl: number;    // ms, default: 1000
  };

  security: {
    allowedRoots: string[];    // Glob patterns for allowed project roots
    blockedCommands: string[]; // Language server commands to block
  };

  analytics: {
    trackOperations: boolean;
    trackPerformance: boolean;
    trackErrors: boolean;
  };
}

export interface TypeScriptServerConfig {
  enabled: boolean;
  command: string;             // default: 'typescript-language-server'
  args: string[];              // default: ['--stdio']
  nodeModulesPath?: string;    // Path to node_modules with tsserver
  tsconfig?: string;           // Path to tsconfig.json
  maxTsServerMemory?: number;  // MB, default: 4096
}

export interface PythonServerConfig {
  enabled: boolean;
  type: 'pylsp' | 'pyright';
  command: string;
  args: string[];
  pythonPath?: string;
  venvPath?: string;
}

export interface GoServerConfig {
  enabled: boolean;
  command: string;             // default: 'gopls'
  args: string[];
  gopath?: string;
  goroot?: string;
}

export interface CustomServerConfig {
  name: string;
  extensions: string[];        // File extensions this server handles
  command: string;
  args: string[];
  initializationOptions?: unknown;
}
```

### 5.4 Response Types

```typescript
// src/shared/types/lspResponses.ts

export interface LspLocation {
  file: string;       // Absolute path
  line: number;       // 1-indexed
  character: number;  // 1-indexed
  endLine?: number;
  endCharacter?: number;
}

export interface LspDefinitionResult {
  success: boolean;
  locations: LspLocation[];
  message?: string;
}

export interface LspReferencesResult {
  success: boolean;
  references: LspLocation[];
  totalCount: number;
  message?: string;
}

export interface LspDiagnostic {
  file: string;
  line: number;
  character: number;
  endLine: number;
  endCharacter: number;
  severity: 'error' | 'warning' | 'information' | 'hint';
  message: string;
  code?: string | number;
  source?: string;
  relatedInformation?: LspRelatedInformation[];
}

export interface LspRelatedInformation {
  location: LspLocation;
  message: string;
}

export interface LspDiagnosticsResult {
  success: boolean;
  diagnostics: LspDiagnostic[];
  counts: {
    errors: number;
    warnings: number;
    information: number;
    hints: number;
  };
}

export interface LspCompletionItem {
  label: string;
  kind: CompletionItemKind;
  detail?: string;
  documentation?: string;
  sortText?: string;
  insertText: string;
  insertTextFormat?: 'plaintext' | 'snippet';
}

export type CompletionItemKind =
  | 'text' | 'method' | 'function' | 'constructor' | 'field'
  | 'variable' | 'class' | 'interface' | 'module' | 'property'
  | 'unit' | 'value' | 'enum' | 'keyword' | 'snippet'
  | 'color' | 'file' | 'reference' | 'folder' | 'enumMember'
  | 'constant' | 'struct' | 'event' | 'operator' | 'typeParameter';

export interface LspCompletionsResult {
  success: boolean;
  items: LspCompletionItem[];
  isIncomplete: boolean;
  message?: string;
}

export interface LspHoverResult {
  success: boolean;
  contents: string;         // Markdown formatted
  range?: {
    start: { line: number; character: number };
    end: { line: number; character: number };
  };
  message?: string;
}

export interface LspRenameEdit {
  file: string;
  edits: Array<{
    range: {
      start: { line: number; character: number };
      end: { line: number; character: number };
    };
    newText: string;
  }>;
}

export interface LspRenameResult {
  success: boolean;
  edits: LspRenameEdit[];
  filesAffected: number;
  locationsAffected: number;
  preview: boolean;
  message?: string;
}

export interface LspSymbol {
  name: string;
  kind: SymbolKind;
  location: LspLocation;
  containerName?: string;
  children?: LspSymbol[];
}

export type SymbolKind =
  | 'file' | 'module' | 'namespace' | 'package' | 'class'
  | 'method' | 'property' | 'field' | 'constructor' | 'enum'
  | 'interface' | 'function' | 'variable' | 'constant' | 'string'
  | 'number' | 'boolean' | 'array' | 'object' | 'key'
  | 'null' | 'enumMember' | 'struct' | 'event' | 'operator'
  | 'typeParameter';

export interface LspDocumentSymbolsResult {
  success: boolean;
  symbols: LspSymbol[];
  message?: string;
}

export interface LspWorkspaceSymbolsResult {
  success: boolean;
  symbols: LspSymbol[];
  totalCount: number;
  message?: string;
}
```

---

## 6. Use Cases

### 6.1 Intelligent Code Navigation

**Actor**: Developer Agent
**Trigger**: Agent needs to understand how a function works
**Flow**:
1. Agent identifies function call in code via `Read` tool
2. Agent invokes `lsp_goto_definition` with file, line, character
3. LSP service opens document in language server (if needed)
4. Language server resolves symbol to definition location
5. Agent receives precise file path and line number
6. Agent reads definition using existing `Read` tool

**Benefit**: Precise navigation vs. regex-based guessing; works with aliases, re-exports, type inference.

### 6.2 Impact Analysis for Refactoring

**Actor**: Refactoring Agent
**Trigger**: User requests renaming a function
**Flow**:
1. Agent invokes `lsp_find_references` to discover all usages
2. Agent analyzes impact (how many files, what patterns)
3. Agent invokes `lsp_rename` with `preview: true` to see all changes
4. Agent presents summary to user for approval
5. Upon approval, agent applies edits or invokes `lsp_rename` with `preview: false`

**Benefit**: Safe, project-wide refactoring; no missed references; handles edge cases (string literals, comments, etc.).

### 6.3 Real-Time Code Validation

**Actor**: Code Generation Agent
**Trigger**: Agent generates new code
**Flow**:
1. Agent writes code to file using `Write` tool
2. Agent invokes `lsp_diagnostics` to check for errors
3. If errors found, agent analyzes and fixes issues
4. Agent re-checks until diagnostics are clean
5. Agent reports success with confidence

**Benefit**: Immediate feedback; no need to run full build; catches type errors during generation.

### 6.4 Context-Aware Code Generation

**Actor**: Code Completion Agent
**Trigger**: Agent needs to implement a function body
**Flow**:
1. Agent positions cursor at implementation point
2. Agent invokes `lsp_completions` with trigger context
3. Language server provides available symbols, types, imports
4. Agent uses completions to inform code generation
5. Agent validates with `lsp_diagnostics`

**Benefit**: Generated code uses correct APIs; proper type matching; aware of available imports.

### 6.5 Codebase Understanding

**Actor**: Research Agent
**Trigger**: Agent needs to understand unfamiliar codebase
**Flow**:
1. Agent identifies entry point file
2. Agent invokes `lsp_document_symbols` to get file structure
3. Agent uses `lsp_goto_definition` to trace dependencies
4. Agent uses `lsp_hover` to understand types and APIs
5. Agent builds mental model of architecture

**Benefit**: Faster onboarding; accurate understanding; discovers non-obvious relationships.

---

## 7. Migration & Rollout

### Phase 1: Foundation (Weeks 1-3)

- [ ] Implement `LspProtocolAdapter` (JSON-RPC encoding/decoding)
- [ ] Implement `LspServerManager` with basic lifecycle (spawn/shutdown)
- [ ] Add TypeScript language server configuration
- [ ] Create basic `lsp_diagnostics` tool
- [ ] Unit tests for protocol adapter
- [ ] Integration tests with real typescript-language-server

**Deliverables:**
- Working LSP connection to TypeScript language server
- Diagnostic retrieval for TypeScript files
- Basic error handling and logging

### Phase 2: Core Operations (Weeks 4-5)

- [ ] Implement `LspDocumentManager` with document tracking
- [ ] Add `lsp_goto_definition` tool
- [ ] Add `lsp_find_references` tool
- [ ] Add `lsp_hover` tool
- [ ] Implement document sync (open/close/change)
- [ ] Add response caching layer

**Deliverables:**
- Full navigation operations working
- Document lifecycle management
- Cached responses for performance

### Phase 3: Advanced Operations (Weeks 6-7)

- [ ] Add `lsp_completions` tool
- [ ] Add `lsp_rename` tool (preview mode only initially)
- [ ] Add `lsp_document_symbols` tool
- [ ] Add `lsp_workspace_symbols` tool
- [ ] Implement circuit breaker and health monitoring
- [ ] Add server restart with exponential backoff

**Deliverables:**
- Full LSP tool suite
- Production-ready reliability features
- Health monitoring integration

### Phase 4: Multi-Language & Polish (Weeks 8-10)

- [ ] Add Python language server support (pylsp)
- [ ] Add Go language server support (gopls)
- [ ] Integrate with `tools_recommend` for intelligent routing
- [ ] Add analytics tracking
- [ ] Add dashboard integration
- [ ] Performance optimization
- [ ] Documentation and examples

**Deliverables:**
- Multi-language support
- Full MXF integration
- Production documentation

### Phase 5: Extended Features (Weeks 11-14, Optional)

- [ ] Non-preview rename (apply edits)
- [ ] Code actions (quick fixes)
- [ ] Signature help
- [ ] Call hierarchy
- [ ] Type hierarchy
- [ ] Semantic tokens (syntax highlighting data)

**Deliverables:**
- Extended LSP capabilities
- IDE-parity feature set

---

## 8. Open Questions

### 8.1 Stateful vs Stateless Document Management

**Question**: Should we maintain open documents across requests (stateful) or open/analyze/close per request (stateless)?

**Trade-offs**:
- Stateful: Faster subsequent operations, incremental updates possible
- Stateless: Simpler implementation, no memory accumulation

**Recommendation**: Start stateful with idle document cleanup (5-minute timeout).

### 8.2 Rename Apply Mode

**Question**: Should `lsp_rename` support directly applying edits, or always return edits for agent to apply?

**Trade-offs**:
- Direct apply: Simpler agent logic, atomic operation
- Return edits: Agent can review, selective apply, better audit trail

**Recommendation**: Start with preview-only, add apply mode in Phase 5.

### 8.3 Multi-Project Support

**Question**: How to handle monorepos or workspaces with multiple tsconfig.json files?

**Options**:
1. One server per tsconfig (more accurate, more memory)
2. One server per workspace root (simpler, may have cross-project issues)
3. User-configured project boundaries

**Recommendation**: Start with option 2, add option 1 as configuration.

### 8.4 Completion Filtering

**Question**: How much should we filter/rank completions before returning to agents?

**Options**:
1. Return raw LSP completions (more options, agent must filter)
2. Filter to top-N by sort order (simpler for agent)
3. AI-powered re-ranking (most relevant, higher latency)

**Recommendation**: Option 2 with configurable limit, option 3 as future enhancement.

### 8.5 External LSP Server Support

**Question**: Should we support user-provided external language servers (not bundled)?

**Trade-offs**:
- Yes: Maximum flexibility, user-maintained
- No: Simpler, known configurations, easier support

**Recommendation**: Yes, via `custom` server configuration.

---

## 9. Dependencies

### 9.1 NPM Packages (New)

| Package | Version | Purpose |
|---------|---------|---------|
| `vscode-languageserver-protocol` | ^3.17.x | LSP type definitions |
| `vscode-jsonrpc` | ^8.x | JSON-RPC transport |
| `typescript-language-server` | ^4.x | TypeScript/JavaScript LSP (peer) |

### 9.2 External Tools (Optional, for multi-language)

| Tool | Installation | Purpose |
|------|--------------|---------|
| `pylsp` | `pip install python-lsp-server` | Python LSP |
| `gopls` | `go install golang.org/x/tools/gopls@latest` | Go LSP |
| `rust-analyzer` | Via rustup | Rust LSP |

### 9.3 Existing MXF Dependencies

| Component | Usage |
|-----------|-------|
| `HybridMcpToolRegistry` | Register LSP tools |
| `ExternalMcpServerManager` | Lifecycle patterns (reference) |
| `ValidationCacheService` | Response caching patterns |
| `EventBus` | Lifecycle events |
| `Logger` | Structured logging |
| `tools_recommend` | Tool recommendation integration |

---

## 10. Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Language server memory leaks | Medium | High | Implement memory monitoring, restart policy |
| Slow operations on large codebases | High | Medium | Caching, timeouts, incremental operations |
| TypeScript version mismatches | Medium | Medium | Document supported versions, use bundled tsserver |
| Security: Path traversal | Low | High | Validate paths against allowlist, sandbox roots |
| Complexity: Document sync issues | Medium | Medium | Start with full sync, add incremental carefully |
| User confusion: 1-indexed vs 0-indexed | Medium | Low | Consistent 1-indexed in API, convert at protocol layer |

---

## 11. Success Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| LSP tool adoption rate | >50% of code navigation requests | Analytics tracking |
| Go-to-definition accuracy | >99% correct locations | Manual validation sample |
| Average operation latency | <500ms for cached operations | Performance monitoring |
| Language server uptime | >99.5% | Health check metrics |
| Agent task success rate improvement | +15% for code-related tasks | Before/after comparison |
| Memory overhead per server | <512MB steady state | Resource monitoring |

---

## 12. References

- [Language Server Protocol Specification 3.17](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/)
- [TypeScript Language Server](https://github.com/typescript-language-server/typescript-language-server)
- [VS Code Language Server Extension Guide](https://code.visualstudio.com/api/language-extensions/language-server-extension-guide)
- [vscode-languageserver-node](https://github.com/microsoft/vscode-languageserver-node)
- [pylsp (Python LSP)](https://github.com/python-lsp/python-lsp-server)
- [gopls (Go LSP)](https://github.com/golang/tools/tree/master/gopls)
- MXF System Architecture v2.0
- MXF MCP Tool Development Guide

---

## Appendix A: LSP Protocol Quick Reference

### A.1 Core LSP Methods Used

| Method | Request Type | Response Type |
|--------|-------------|---------------|
| `initialize` | `InitializeParams` | `InitializeResult` |
| `initialized` | `InitializedParams` | (notification) |
| `shutdown` | (none) | (none) |
| `exit` | (none) | (notification) |
| `textDocument/didOpen` | `DidOpenTextDocumentParams` | (notification) |
| `textDocument/didChange` | `DidChangeTextDocumentParams` | (notification) |
| `textDocument/didClose` | `DidCloseTextDocumentParams` | (notification) |
| `textDocument/definition` | `DefinitionParams` | `Location[]` |
| `textDocument/references` | `ReferenceParams` | `Location[]` |
| `textDocument/hover` | `HoverParams` | `Hover` |
| `textDocument/completion` | `CompletionParams` | `CompletionItem[]` |
| `textDocument/rename` | `RenameParams` | `WorkspaceEdit` |
| `textDocument/documentSymbol` | `DocumentSymbolParams` | `DocumentSymbol[]` |
| `workspace/symbol` | `WorkspaceSymbolParams` | `SymbolInformation[]` |
| `textDocument/publishDiagnostics` | (server notification) | `PublishDiagnosticsParams` |

### A.2 Position Encoding

- LSP uses 0-indexed lines and characters
- Characters are counted in UTF-16 code units
- MXF tools expose 1-indexed for human readability
- Conversion happens at the protocol adapter layer

### A.3 Document URI Format

```
file:///absolute/path/to/file.ts
```

- Always use absolute paths
- Convert to/from file URIs at the adapter layer
- Handle Windows paths (`file:///C:/path/...`)

---

## Appendix B: Sample Integration Code

### B.1 Registering LSP Tools

```typescript
// src/server/index.ts (addition to initialization)

import { lspTools } from '../shared/protocols/mcp/tools/LspTools';
import { LspServerManager } from '../shared/services/lsp/LspServerManager';

async function initializeLspIntegration() {
  // Initialize LSP server manager
  const lspManager = LspServerManager.getInstance();
  await lspManager.initialize(config.lsp);

  // Register LSP tools with the hybrid registry
  const hybridRegistry = HybridMcpToolRegistry.getInstance();
  for (const tool of lspTools) {
    hybridRegistry.registerInternalTool({
      ...tool,
      handler: createLspToolHandler(tool.name, lspManager)
    });
  }

  // Register for graceful shutdown
  process.on('SIGTERM', async () => {
    await lspManager.shutdownAll();
  });
}
```

### B.2 Tool Handler Factory

```typescript
// src/shared/services/lsp/LspToolHandlers.ts

export function createLspToolHandler(
  toolName: string,
  lspManager: ILspServerManager
): ToolHandler {
  const handlers: Record<string, ToolHandler> = {
    'lsp_goto_definition': async (input, context) => {
      const { file, line, character } = input;
      const language = detectLanguage(file);
      const projectRoot = findProjectRoot(file);

      const connection = await lspManager.getServer(projectRoot, language);
      await ensureDocumentOpen(connection, file);

      const result = await connection.request('textDocument/definition', {
        textDocument: { uri: fileToUri(file) },
        position: { line: line - 1, character: character - 1 }
      });

      return formatDefinitionResult(result);
    },

    // ... other handlers
  };

  return handlers[toolName];
}
```

---

*Document Version: 1.0 | Last Updated: December 2025*
