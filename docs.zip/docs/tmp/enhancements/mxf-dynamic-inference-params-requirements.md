# MXF Dynamic Inference Parameters

**Requirements Document**  
Version 1.0 | December 2024

---

## Executive Summary

This document defines requirements for implementing dynamic inference parameter control within MXF. The feature enables agents to operate with phase-optimized LLM configurations during ORPAR cognitive cycles and provides a meta-tool for runtime parameter adjustment requests. The goal is improved task outcomes, cost optimization, and agent autonomy through metacognitive control over inference behavior.

---

## Problem Statement

Current MXF implementation uses static inference parameters across all cognitive phases, despite evidence that different phases benefit from different configurations. Observation tasks require precision and speed, while reasoning tasks benefit from extended thinking and exploratory temperature. Planning demands structured output, while reflection needs genuine evaluative capacity. A one-size-fits-all approach leaves performance on the table.

Additionally, agents lack the ability to signal when a task exceeds their current configuration's capabilities—forcing premature execution or suboptimal results when a parameter adjustment (model upgrade, extended reasoning budget, temperature shift) would yield better outcomes.

---

## Goals

- Optimize task outcomes by matching inference parameters to cognitive phase requirements
- Reduce unnecessary token spend by using lighter configurations where appropriate
- Enable agent-initiated parameter escalation for complex or unexpected tasks
- Build empirical feedback loops correlating parameter choices with task success
- Maintain backward compatibility with existing agent configurations

---

## Feature 1: Phase-Aware Parameter Profiles

### Overview

Extend the existing ORPAR model selection logic to include full parameter profiles per phase. Each cognitive phase (Observation, Reasoning, Planning, Action, Reflection) will have an associated configuration tuple specifying model, temperature, reasoning token budget, and max output tokens.

### Product Requirements

#### PR-1: Default Phase Profiles

The system shall ship with sensible default parameter profiles for each ORPAR phase, tuned based on typical cognitive demands:

- **Observation:** Low temperature (0.1-0.3), minimal reasoning tokens, fast model. Optimized for accurate data intake without hallucination.
- **Reasoning:** Moderate temperature (0.4-0.6), extended reasoning token budget, high-capability model. Enables exploration of solution space.
- **Planning:** Low temperature (0.2-0.4), structured output enforcement, strategic model. Deterministic plan generation.
- **Action:** Low temperature (0.1-0.2), minimal reasoning overhead, reliable execution model. Precision tool calling.
- **Reflection:** Moderate temperature (0.3-0.5), extended reasoning for evaluation, high-capability model. Genuine assessment without rubber-stamping.

#### PR-2: Profile Customization

Developers shall be able to override default phase profiles at agent creation, channel level, or task level. More specific configurations take precedence over general ones.

#### PR-3: Cost Visibility

The analytics system shall track and report cost implications of phase parameter choices, enabling operators to understand the cost/quality tradeoff of different profile configurations.

### Technical Requirements

#### TR-1: Parameter Profile Schema

Define a `PhaseParameterProfile` type containing:

- **model:** String identifier for LLM model (OpenRouter format)
- **temperature:** Number 0.0-2.0, controls output randomness
- **reasoningTokens:** Number, budget for extended thinking (model-dependent)
- **maxOutputTokens:** Number, maximum response length
- **topP:** Optional number 0.0-1.0, nucleus sampling parameter

#### TR-2: Configuration Hierarchy

Implement configuration resolution in the following precedence order (highest to lowest):

1. Task-level override (per-execution)
2. Agent-level configuration
3. Channel-level defaults
4. System-wide defaults

#### TR-3: Control Loop Integration

Modify the ORPAR control loop handler to:

- Resolve the active parameter profile before each phase execution
- Pass resolved parameters to the LLM provider abstraction layer
- Log parameter choices with phase execution metrics for analytics
- Handle provider-specific parameter mapping (reasoning tokens may not apply to all models)

#### TR-4: Provider Abstraction

Create a parameter normalization layer that maps `PhaseParameterProfile` fields to provider-specific API parameters. Handle graceful degradation when a parameter is not supported by the target model (e.g., reasoning tokens on non-thinking models).

---

## Feature 2: Inference Parameter Meta-Tool

### Overview

Provide an MCP-compatible tool that allows agents to request inference parameter modifications during task execution. This enables metacognitive control—agents can recognize when their current configuration is insufficient and petition for adjustment.

### Product Requirements

#### PR-4: Agent-Initiated Parameter Requests

Agents shall be able to invoke a tool requesting parameter changes, providing a reason for the request and suggested parameter values. The system (or SystemLLM) evaluates and approves, modifies, or denies the request.

#### PR-5: Request Governance

Parameter change requests shall be subject to governance constraints:

- **Budget limits:** Requests exceeding cost thresholds require approval or are denied
- **Security constraints:** Classified tasks may prohibit model downgrades
- **Rate limits:** Prevent excessive parameter churn within a single task
- **Agent permissions:** Some agents may have restricted parameter adjustment capabilities

#### PR-6: Feedback Integration

The reflection phase shall evaluate whether parameter adjustments improved task outcomes. This feedback feeds into the pattern learning system, building empirical data on which adjustments help for which task types.

### Technical Requirements

#### TR-5: Tool Definition

Implement `request_inference_params` as an MCP tool with the following input schema:

- **reason:** String, required. Explanation of why adjustment is needed.
- **suggested.model:** Optional string. Requested model identifier.
- **suggested.temperature:** Optional number. Requested temperature.
- **suggested.reasoningTokens:** Optional number. Requested reasoning budget.
- **suggested.maxOutputTokens:** Optional number. Requested output limit.
- **scope:** Optional enum (`"next_call"` | `"current_phase"` | `"remaining_task"`). Defaults to `"next_call"`.

#### TR-6: Request Evaluation Pipeline

When a parameter request is received:

1. Validate request against agent permissions and channel constraints
2. Calculate cost implications of the requested change
3. Check against budget limits and rate limits
4. Optionally route to SystemLLM for approval decision on ambiguous cases
5. Return approval status with actual parameters to be used (may differ from requested)
6. Log request, decision, and rationale for analytics

#### TR-7: Response Schema

Tool response shall include:

- **status:** `"approved"` | `"modified"` | `"denied"`
- **activeParams:** The parameter profile that will be used
- **rationale:** Explanation for modified or denied requests
- **costDelta:** Estimated cost change from this adjustment

#### TR-8: State Management

Parameter overrides must be scoped correctly. `"next_call"` applies to only the immediately following LLM invocation. `"current_phase"` persists through the phase. `"remaining_task"` persists until task completion. Implement override state cleanup to prevent leakage across task boundaries.

---

## Integration Requirements

### Pattern Learning Integration

#### TR-9: Outcome Correlation

Extend pattern learning to correlate parameter configurations with task outcomes. Track success rate, latency, token usage, and cost per parameter profile per task type. Use this data to inform SystemLLM task assignment recommendations.

#### TR-10: Adaptive Defaults

Over time, the system should learn optimal default profiles for recurring task patterns. Provide a mechanism for promoting learned configurations to channel or agent defaults with operator approval.

### Analytics Integration

#### TR-11: Parameter Metrics

Add analytics dimensions for:

- Parameter profile per phase execution
- Parameter adjustment requests (count, approval rate, types)
- Cost attribution per parameter choice
- Outcome correlation scores

### SystemLLM Integration

#### TR-12: Task Assignment Enhancement

When SystemLLM assigns tasks to agents, it may optionally include suggested parameter profiles based on task analysis. These suggestions influence but do not override agent or channel defaults—they provide hints for the parameter resolution logic.

---

## Non-Functional Requirements

### Performance

- Parameter resolution adds no more than 5ms latency to phase execution
- Meta-tool evaluation completes within 50ms for standard requests

### Backward Compatibility

- Existing agents without phase profiles continue to function using current model-only selection
- `ORPAR_MODEL_CONFIGS` format remains valid, automatically expanded to full profiles

### Observability

- All parameter decisions logged with full context for debugging
- Dashboard displays active parameter profiles per agent in real-time

---

## Future Considerations

The following items are out of scope for initial implementation but should inform architectural decisions:

- **Automatic parameter tuning:** Reinforcement learning to optimize profiles without human intervention
- **Cross-agent parameter sharing:** Learned profiles shared across agents with similar roles
- **Real-time budget optimization:** Dynamic model switching based on remaining task budget
- **Multi-model ensemble:** Running multiple models in parallel for consensus on critical decisions

---

## Appendix: Suggested Default Profiles

The following default profiles represent a reasonable starting point based on phase characteristics. Values should be validated empirically and adjusted based on analytics feedback.

### Observation Phase
- Model: `google/gemini-2.5-flash`
- Temperature: 0.2
- Reasoning Tokens: 0 (disabled)
- Max Output: 2000

### Reasoning Phase
- Model: `anthropic/claude-sonnet-4-5`
- Temperature: 0.5
- Reasoning Tokens: 8000
- Max Output: 4000

### Planning Phase
- Model: `google/gemini-2.5-pro`
- Temperature: 0.3
- Reasoning Tokens: 4000
- Max Output: 4000

### Action Phase
- Model: `openai/gpt-4.1-mini`
- Temperature: 0.1
- Reasoning Tokens: 0 (disabled)
- Max Output: 2000

### Reflection Phase
- Model: `anthropic/claude-sonnet-4-5`
- Temperature: 0.4
- Reasoning Tokens: 4000
- Max Output: 2000
